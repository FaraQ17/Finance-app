import { i as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as toneOf, S as rankSentiment, c as formatPct, t as MarketShell } from "./format-UWdJjcXe.mjs";
import { i as Star, o as RefreshCw } from "../_libs/lucide-react.mjs";
import { t as useWatchlist } from "./watchlist-CxDpRLcD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sentiment-DPugvhoM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TERMS = [
	{
		id: "court",
		label: "Court",
		hint: "prochains jours"
	},
	{
		id: "moyen",
		label: "Moyen",
		hint: "1 à 3 mois"
	},
	{
		id: "long",
		label: "Long",
		hint: "6 à 18 mois"
	}
];
var SCOPES = [
	{
		id: "mix",
		label: "Mixte"
	},
	{
		id: "stock",
		label: "Actions"
	},
	{
		id: "crypto",
		label: "Crypto"
	},
	{
		id: "favoris",
		label: "Favoris"
	}
];
function toneClass(change) {
	const tone = toneOf(change);
	if (tone === "up") return "text-up";
	if (tone === "down") return "text-down";
	return "text-muted";
}
function scoreClass(score) {
	if (score >= 15) return "text-up";
	if (score <= -15) return "text-down";
	return "text-muted";
}
function SentimentBoard() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [term, setTerm] = (0, import_react.useState)("court");
	const [scope, setScope] = (0, import_react.useState)("mix");
	const favorites = useWatchlist((state) => state.items);
	const toggle = useWatchlist((state) => state.toggle);
	(0, import_react.useEffect)(() => {
		setMounted(true);
		useWatchlist.persist.rehydrate();
	}, []);
	const rank = useMutation({ mutationFn: (force) => rankSentiment({ data: {
		term,
		scope,
		force,
		favorites: favorites.map((item) => ({
			symbol: item.symbol,
			name: item.name,
			kind: item.kind
		}))
	} }) });
	(0, import_react.useEffect)(() => {
		rank.reset();
	}, [term, scope]);
	const board = rank.data && "ok" in rank.data && rank.data.ok ? rank.data.board : null;
	const error = rank.data && "ok" in rank.data && !rank.data.ok ? rank.data.error : null;
	const hint = TERMS.find((item) => item.id === term)?.hint ?? "prochains jours";
	const watchSet = new Set(mounted ? favorites.map((item) => item.symbol) : []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl space-y-4 px-4 py-4 pb-24 lg:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: "Sentiment des news"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-pretty text-muted",
				children: [
					"Les 20 lectures les plus haussières et les mieux étayées. Le rang croise le sentiment des news et la confiance, sur ",
					hint,
					"."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-1 rounded-xl bg-panel p-1 shadow-card",
				role: "tablist",
				"aria-label": "Horizon",
				children: TERMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": term === item.id,
					onClick: () => setTerm(item.id),
					className: `h-10 rounded-lg text-sm ${term === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`,
					children: item.label
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-1 rounded-xl bg-panel p-1 shadow-card",
				role: "tablist",
				"aria-label": "Univers",
				children: SCOPES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": scope === item.id,
					onClick: () => setScope(item.id),
					className: `h-10 rounded-lg text-sm ${scope === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`,
					children: item.label
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: rank.isPending || scope === "favoris" && favorites.length === 0,
				onClick: () => rank.mutate(Boolean(board)),
				className: "inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-brass px-4 text-sm font-medium text-ink disabled:opacity-60",
				children: [rank.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4 animate-spin" }) : null, board ? "Actualiser le classement" : "Classer le sentiment"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-pretty text-muted",
				children: "Rien ne part tout seul. Grok lit le cours du jour et un titre d'actualité par valeur, puis note le sentiment et la confiance. Ce n'est pas un conseil."
			}),
			scope === "favoris" && mounted && favorites.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Ajoutez des favoris pour classer seulement vos titres."
			}) : null,
			rank.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Lecture des cours et des titres…"
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-down",
				role: "alert",
				children: error
			}) : null,
			board ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [
					board.rows.length,
					" retenus sur ",
					board.scanned,
					" lus",
					rank.data && "cached" in rank.data && rank.data.cached ? " · lecture conservée" : ""
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "overflow-hidden rounded-2xl bg-panel shadow-card",
				children: board.rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SentimentItem, {
					row,
					index,
					watched: watchSet.has(row.symbol),
					onToggle: () => toggle({
						symbol: row.symbol,
						name: row.name,
						kind: row.kind
					})
				}, row.symbol))
			})] }) : null
		]
	}) });
}
function SentimentItem({ row, index, watched, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-start border-b border-line last:border-b-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1 px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						search: { s: row.symbol },
						className: "min-w-0 truncate text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 font-mono text-xs text-muted",
							children: index + 1
						}), row.name]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: `shrink-0 font-mono text-sm tabular-nums ${scoreClass(row.sentimentScore)}`,
						children: [row.sentimentScore > 0 ? "+" : "", row.sentimentScore]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 font-mono text-xs text-muted",
					children: [
						row.symbol.replace("-USD", ""),
						" · confiance ",
						row.confidence,
						" % · jour ",
						formatPct(row.changePercent)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 h-1.5 overflow-hidden rounded-full bg-ink",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-brass",
						style: { width: `${row.confidence}%` }
					})
				}),
				row.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-pretty",
					children: row.note
				}) : null,
				row.headline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-pretty text-muted",
					children: row.headline
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `mt-1 text-xs ${toneClass(row.changePercent)}`,
					children: row.kind === "crypto" ? "Crypto" : "Action"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onToggle,
			"aria-pressed": watched,
			"aria-label": watched ? `Retirer ${row.name} des favoris` : `Ajouter ${row.name} aux favoris`,
			className: "mt-2 grid size-11 shrink-0 place-items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `size-4 ${watched ? "fill-brass text-brass" : "text-muted"}` })
		})]
	});
}
var SplitComponent = SentimentBoard;
//#endregion
export { SplitComponent as component };
