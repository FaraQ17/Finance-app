type Clock = { hour: number; minute: number };

type Place = {
  place: string;
  timeZone: string;
  open: Clock;
  close: Clock;
  lunch?: { start: Clock; end: Clock };
  always?: boolean;
};

const PLACES: { test: (symbol: string) => boolean; place: Place }[] = [
  { test: (symbol) => symbol.endsWith("-USD"), place: { place: "Crypto", timeZone: "UTC", open: { hour: 0, minute: 0 }, close: { hour: 24, minute: 0 }, always: true } },
  { test: (symbol) => symbol.endsWith(".PA"), place: { place: "Paris", timeZone: "Europe/Paris", open: { hour: 9, minute: 0 }, close: { hour: 17, minute: 30 } } },
  { test: (symbol) => symbol.endsWith(".AS"), place: { place: "Amsterdam", timeZone: "Europe/Amsterdam", open: { hour: 9, minute: 0 }, close: { hour: 17, minute: 30 } } },
  { test: (symbol) => symbol.endsWith(".DE"), place: { place: "Francfort", timeZone: "Europe/Berlin", open: { hour: 9, minute: 0 }, close: { hour: 17, minute: 30 } } },
  { test: (symbol) => symbol.endsWith(".MI"), place: { place: "Milan", timeZone: "Europe/Rome", open: { hour: 9, minute: 0 }, close: { hour: 17, minute: 30 } } },
  { test: (symbol) => symbol.endsWith(".MC"), place: { place: "Madrid", timeZone: "Europe/Madrid", open: { hour: 9, minute: 0 }, close: { hour: 17, minute: 30 } } },
  { test: (symbol) => symbol.endsWith(".L"), place: { place: "Londres", timeZone: "Europe/London", open: { hour: 8, minute: 0 }, close: { hour: 16, minute: 30 } } },
  { test: (symbol) => symbol.endsWith(".SW"), place: { place: "Zurich", timeZone: "Europe/Zurich", open: { hour: 9, minute: 0 }, close: { hour: 17, minute: 30 } } },
  { test: (symbol) => symbol.endsWith(".T"), place: { place: "Tokyo", timeZone: "Asia/Tokyo", open: { hour: 9, minute: 0 }, close: { hour: 15, minute: 0 }, lunch: { start: { hour: 11, minute: 30 }, end: { hour: 12, minute: 30 } } } },
  { test: (symbol) => symbol.endsWith(".HK"), place: { place: "Hong Kong", timeZone: "Asia/Hong_Kong", open: { hour: 9, minute: 30 }, close: { hour: 16, minute: 0 }, lunch: { start: { hour: 12, minute: 0 }, end: { hour: 13, minute: 0 } } } },
  { test: (symbol) => symbol.endsWith(".TO"), place: { place: "Toronto", timeZone: "America/Toronto", open: { hour: 9, minute: 30 }, close: { hour: 16, minute: 0 } } },
];

const NEW_YORK: Place = { place: "New York", timeZone: "America/New_York", open: { hour: 9, minute: 30 }, close: { hour: 16, minute: 0 } };

function placeOf(symbol: string): Place {
  return PLACES.find((item) => item.test(symbol))?.place ?? NEW_YORK;
}

function pad(value: number): string {
  return String(value).padStart(2, "0");
}

function clockLabel(clock: Clock): string {
  return `${pad(clock.hour)}:${pad(clock.minute)}`;
}

function minutes(clock: Clock): number {
  return clock.hour * 60 + clock.minute;
}

type ZoneParts = { year: number; month: number; day: number; hour: number; minute: number; weekday: string };

function zoneParts(date: Date, timeZone: string): ZoneParts {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    weekday: "short",
    hourCycle: "h23",
  }).formatToParts(date);
  const bag = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return {
    year: Number(bag.year),
    month: Number(bag.month),
    day: Number(bag.day),
    hour: Number(bag.hour),
    minute: Number(bag.minute),
    weekday: bag.weekday ?? "",
  };
}

function atLocal(timeZone: string, day: ZoneParts, clock: Clock): Date {
  const guess = Date.UTC(day.year, day.month - 1, day.day, clock.hour, clock.minute);
  const shown = zoneParts(new Date(guess), timeZone);
  const shownMs = Date.UTC(shown.year, shown.month - 1, shown.day, shown.hour, shown.minute);
  return new Date(guess - (shownMs - guess));
}

function parisLabel(date: Date): string {
  const parts = zoneParts(date, "Europe/Paris");
  return `${pad(parts.hour)}:${pad(parts.minute)}`;
}

export type MarketSession = {
  place: string;
  hours: string;
  paris: string | null;
  status: "Ouvert" | "Fermé" | "Pause déjeuner";
  open: boolean;
};

export function sessionOf(symbol: string, now = new Date()): MarketSession {
  const place = placeOf(symbol);
  const local = zoneParts(now, place.timeZone);
  const weekend = place.always ? false : local.weekday === "Sat" || local.weekday === "Sun";
  const nowMin = local.hour * 60 + local.minute;
  const lunch = place.lunch != null && nowMin >= minutes(place.lunch.start) && nowMin < minutes(place.lunch.end);
  const inside = place.always || (nowMin >= minutes(place.open) && nowMin < minutes(place.close) && !lunch);
  const status = weekend ? "Fermé" : lunch ? "Pause déjeuner" : inside ? "Ouvert" : "Fermé";
  const hours = place.always
    ? "24 h/24"
    : place.lunch
      ? `${clockLabel(place.open)}–${clockLabel(place.lunch.start)}, ${clockLabel(place.lunch.end)}–${clockLabel(place.close)}`
      : `${clockLabel(place.open)}–${clockLabel(place.close)}`;
  let paris: string | null = null;
  if (!place.always && place.timeZone !== "Europe/Paris") {
    const openAt = parisLabel(atLocal(place.timeZone, local, place.open));
    const closeAt = parisLabel(atLocal(place.timeZone, local, place.close));
    paris = `${openAt}–${closeAt}`;
  }
  return { place: place.place, hours, paris, status, open: status === "Ouvert" };
}
