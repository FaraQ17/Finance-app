import { i as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as readTrendBoard, E as toneOf, c as formatPct, t as MarketShell, u as formatPrice, y as getTrends } from "./format-UWdJjcXe.mjs";
import { i as Star, l as ArrowUpRight, o as RefreshCw } from "../_libs/lucide-react.mjs";
import { t as useWatchlist } from "./watchlist-CxDpRLcD.mjs";
import { n as Route } from "./router-Cjz9k9o2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tendances-Dgf3F6Vb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KINDS = [{
	id: "stock",
	label: "Actions"
}, {
	id: "crypto",
	label: "Crypto"
}];
var HORIZONS = [
	{
		id: 1,
		label: "1 j"
	},
	{
		id: 5,
		label: "5 j"
	},
	{
		id: 10,
		label: "10 j"
	}
];
function toneClass(change) {
	const tone = toneOf(change);
	if (tone === "up") return "text-up";
	if (tone === "down") return "text-down";
	return "text-muted";
}
function RankList({ title, rows, down, watched, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-panel p-4 shadow-card sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: `text-xs font-medium tracking-widest uppercase ${down ? "text-down" : "text-up"}`,
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-2",
			children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "border-b border-line py-3 last:border-b-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-5 pt-0.5 font-mono text-xs text-muted",
							children: index + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/",
									search: { s: row.symbol },
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate text-sm",
										children: row.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `shrink-0 font-mono text-sm tabular-nums ${toneClass(row.changePercent)}`,
										children: formatPct(row.changePercent)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-xs text-muted",
									children: [
										row.symbol.replace("-USD", ""),
										" · ",
										formatPrice(row.price, row.currency)
									]
								}),
								row.headline && row.headlineUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: row.headlineUrl,
									target: "_blank",
									rel: "noreferrer noopener",
									className: "mt-1 flex items-start gap-1 text-xs text-pretty text-muted hover:text-brass",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-0",
										children: row.headline
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "mt-0.5 size-3 shrink-0" })]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted",
									children: "Pas de titre récent rattaché."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onToggle(row),
							"aria-pressed": watched(row.symbol),
							"aria-label": watched(row.symbol) ? `Retirer ${row.name} des favoris` : `Ajouter ${row.name} aux favoris`,
							className: "grid size-11 shrink-0 place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `size-4 ${watched(row.symbol) ? "fill-brass text-brass" : "text-muted"}` })
						})
					]
				})
			}, row.symbol))
		})]
	});
}
function Trends({ kind, horizon, onKind, onHorizon }) {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const favorites = useWatchlist((state) => state.items);
	const toggle = useWatchlist((state) => state.toggle);
	(0, import_react.useEffect)(() => {
		setMounted(true);
		useWatchlist.persist.rehydrate();
	}, []);
	const watchSet = new Set(mounted ? favorites.map((item) => item.symbol) : []);
	const board = useQuery({
		queryKey: [
			"trends",
			kind,
			horizon
		],
		enabled: mounted,
		queryFn: () => getTrends({ data: {
			kind,
			horizon
		} }),
		staleTime: 6e4
	});
	const read = useMutation({ mutationFn: (force) => readTrendBoard({ data: {
		kind,
		horizon,
		force
	} }) });
	(0, import_react.useEffect)(() => {
		read.reset();
	}, [kind, horizon]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl space-y-4 px-4 py-4 pb-24 lg:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: "Tendances"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-pretty text-muted",
				children: kind === "stock" ? "Classement parmi les grandes valeurs liquides (États-Unis et Europe). 5 j et 10 j = séances de bourse." : "Classement parmi les cryptos majeures. 5 j et 10 j = jours calendaires."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-1 rounded-xl bg-panel p-1 shadow-card",
					role: "tablist",
					"aria-label": "Univers",
					children: KINDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": kind === item.id,
						onClick: () => onKind(item.id),
						className: `h-10 rounded-lg px-4 text-sm ${kind === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`,
						children: item.label
					}, item.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-1 rounded-xl bg-panel p-1 shadow-card",
					role: "tablist",
					"aria-label": "Horizon",
					children: HORIZONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": horizon === item.id,
						onClick: () => onHorizon(item.id),
						className: `h-10 rounded-lg px-3 text-sm ${horizon === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`,
						children: item.label
					}, item.id))
				})]
			}),
			board.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Classement et titres d'actualité…"
			}) : null,
			board.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => board.refetch(),
				className: "h-11 text-sm text-brass",
				children: "Réessayer le classement"
			}) : null,
			board.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [board.data.scanned, " actifs comparés · toucher un nom ouvre le desk"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankList, {
						title: "10 meilleures",
						rows: board.data.best,
						watched: (symbol) => watchSet.has(symbol),
						onToggle: (row) => toggle({
							symbol: row.symbol,
							name: row.name,
							kind
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankList, {
						title: "10 moins bonnes",
						rows: board.data.worst,
						down: true,
						watched: (symbol) => watchSet.has(symbol),
						onToggle: (row) => toggle({
							symbol: row.symbol,
							name: row.name,
							kind
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-panel p-4 shadow-card sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xs font-medium tracking-widest text-muted uppercase",
								children: "Par rapport à l'actualité"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "Grok relie ce classement aux titres affichés. Rien ne part tout seul."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: read.isPending,
								onClick: () => read.mutate(Boolean(read.data?.ok)),
								className: "inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-brass px-4 text-sm font-medium text-ink disabled:opacity-60",
								children: [read.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4 animate-spin" }) : null, read.data?.ok ? "Actualiser la lecture" : "Relier à l'actualité"]
							})]
						}),
						read.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "Lecture des titres du classement…"
						}) : null,
						read.data && !read.data.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-down",
							role: "alert",
							children: read.data.error
						}) : null,
						read.data?.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-3 text-sm text-pretty",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: read.data.lead }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl bg-up-soft p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium tracking-widest text-up uppercase",
										children: "Haut du tableau"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1",
										children: read.data.winnersNote
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl bg-down-soft p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium tracking-widest text-down uppercase",
										children: "Bas du tableau"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1",
										children: read.data.losersNote
									})]
								}),
								read.data.cached ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: "Lecture conservée."
								}) : null
							]
						}) : null
					]
				})
			] }) : null
		]
	}) });
}
function TendancesPage() {
	const search = Route.useSearch();
	const kind = search.k ?? "stock";
	const horizon = search.h ?? 1;
	const navigate = Route.useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trends, {
		kind,
		horizon,
		onKind: (next) => {
			navigate({
				search: {
					k: next,
					h: horizon
				},
				resetScroll: false
			});
		},
		onHorizon: (next) => {
			navigate({
				search: {
					k: kind,
					h: next
				},
				resetScroll: false
			});
		}
	});
}
//#endregion
export { TendancesPage as component };
