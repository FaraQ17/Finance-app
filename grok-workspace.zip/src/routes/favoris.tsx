import { createFileRoute } from "@tanstack/react-router";
import { Favorites } from "@/components/market/favorites";

export const Route = createFileRoute("/favoris")({
  component: Favorites,
});
