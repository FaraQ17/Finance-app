import { createFileRoute } from "@tanstack/react-router";
import { ChangelogPage } from "@/components/market/changelog-page";

export const Route = createFileRoute("/suivi")({
  component: ChangelogPage,
});
