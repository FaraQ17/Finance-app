import type { BotQuote, Kind } from "@/lib/universe";

function marketOf(symbol: string): string {
  if (symbol.endsWith("-USD")) return "Crypto";
  if (/\.(PA|DE|AS|MI|MC|L|SW)$/.test(symbol)) return "Europe";
  if (symbol.endsWith(".T")) return "Japon";
  if (symbol.endsWith(".HK")) return "Hong Kong";
  if (symbol.endsWith(".TO")) return "Canada";
  return "États-Unis";
}

export const PAPER_CAPITAL = 1000;
const BUY_GAP_MS = 70 * 1000;
const NOTE_GAP_MS = 15 * 60 * 1000;

export type RiskProfile = "faible" | "modere" | "eleve";

export type RiskSettings = {
  profile: RiskProfile;
  stockSlots: number;
  cryptoSlots: number;
  stockSizePct: number;
  cryptoSizePct: number;
  maxInvestedPct: number;
  targetPct: number;
};

export const RISK_PRESETS: Record<RiskProfile, RiskSettings> = {
  faible: { profile: "faible", stockSlots: 3, cryptoSlots: 1, stockSizePct: 5, cryptoSizePct: 4, maxInvestedPct: 35, targetPct: 6 },
  modere: { profile: "modere", stockSlots: 5, cryptoSlots: 2, stockSizePct: 8, cryptoSizePct: 6, maxInvestedPct: 55, targetPct: 8 },
  eleve: { profile: "eleve", stockSlots: 8, cryptoSlots: 4, stockSizePct: 12, cryptoSizePct: 10, maxInvestedPct: 80, targetPct: 12 },
};

export const DEFAULT_RISK: RiskSettings = { ...RISK_PRESETS.faible };

export type EquityPoint = { t: number; v: number };

export type ScanRow = {
  symbol: string;
  name: string;
  market: string;
  trend: "haussiere" | "baissiere" | "neutre";
  rsi: number | null;
  changePercent: number;
  verdict: "achat" | "short" | "rien";
  reason: string;
};

export type TradeActor = "bot" | "manuel";

export type PositionSide = "long" | "short";

export type PaperPosition = {
  symbol: string;
  name: string;
  kind: Kind;
  qty: number;
  entry: number;
  stop: number;
  target: number;
  openedAt: number;
  actor: TradeActor;
  side: PositionSide;
};

export type PaperTrade = {
  id: string;
  at: number;
  side: "achat" | "vente";
  symbol: string;
  name: string;
  qty: number;
  price: number;
  pnl: number | null;
  reason: string;
  actor: TradeActor;
  positionSide?: PositionSide;
};

export type PaperNote = {
  id: string;
  at: number;
  action: "achat" | "vente" | "attente";
  text: string;
};

export type PaperState = {
  cash: number;
  positions: PaperPosition[];
  trades: PaperTrade[];
  journal: PaperNote[];
  paused: boolean;
  activated: boolean;
  armed: boolean;
  startedAt: number;
  lastDecisionAt: number;
  lastNoteAt: number;
  marks: Record<string, number>;
  added: number;
  risk: RiskSettings;
  history: EquityPoint[];
  scans: ScanRow[];
};

export function freshPaper(now = Date.now()): PaperState {
  return {
    cash: PAPER_CAPITAL,
    positions: [],
    trades: [],
    journal: [],
    paused: true,
    activated: false,
    armed: false,
    startedAt: now,
    lastDecisionAt: 0,
    lastNoteAt: 0,
    marks: {},
    added: 0,
    risk: { ...DEFAULT_RISK },
    history: [],
    scans: [],
  };
}

export function actorOf(value: { actor?: string } | null | undefined): TradeActor {
  return value?.actor === "manuel" ? "manuel" : "bot";
}

export function sideOf(value: { side?: string } | null | undefined): PositionSide {
  return value?.side === "short" ? "short" : "long";
}

export function pnlAt(position: PaperPosition, price: number): number {
  const move = sideOf(position) === "short" ? position.entry - price : price - position.entry;
  return move * position.qty;
}

export function contribution(position: PaperPosition, price: number): number {
  return sideOf(position) === "short" ? position.qty * (2 * position.entry - price) : position.qty * price;
}

function hitStop(position: PaperPosition, price: number): boolean {
  return sideOf(position) === "short" ? price >= position.stop : price <= position.stop;
}

function hitTarget(position: PaperPosition, price: number): boolean {
  return sideOf(position) === "short" ? price <= position.target : price >= position.target;
}

export function markOf(state: PaperState, symbol: string, fallback: number): number {
  return state.marks[symbol] ?? fallback;
}

export function positionValue(state: PaperState, position: PaperPosition): number {
  return position.qty * markOf(state, position.symbol, position.entry);
}

export function investedValue(state: PaperState): number {
  return state.positions.reduce((sum, position) => sum + positionValue(state, position), 0);
}

export function basisOf(state: PaperState): number {
  return PAPER_CAPITAL + (state.added || 0);
}

function clampInt(value: number | undefined, min: number, max: number, fallback: number): number {
  const next = Math.round(Number(value));
  if (!Number.isFinite(next)) return fallback;
  return Math.min(max, Math.max(min, next));
}

function profileOf(value: unknown): RiskProfile {
  return value === "modere" || value === "eleve" ? value : "faible";
}

export function settingsOf(state: { risk?: Partial<RiskSettings> | null }): RiskSettings {
  const risk = state.risk ?? {};
  return {
    profile: profileOf(risk.profile),
    stockSlots: clampInt(risk.stockSlots, 1, 10, DEFAULT_RISK.stockSlots),
    cryptoSlots: clampInt(risk.cryptoSlots, 0, 6, DEFAULT_RISK.cryptoSlots),
    stockSizePct: clampInt(risk.stockSizePct, 1, 15, DEFAULT_RISK.stockSizePct),
    cryptoSizePct: clampInt(risk.cryptoSizePct, 1, 15, DEFAULT_RISK.cryptoSizePct),
    maxInvestedPct: clampInt(risk.maxInvestedPct, 15, 90, DEFAULT_RISK.maxInvestedPct),
    targetPct: clampInt(risk.targetPct, 3, 25, DEFAULT_RISK.targetPct),
  };
}

export function pushHistory(
  history: EquityPoint[] | undefined,
  startedAt: number,
  now: number,
  value: number,
): EquityPoint[] {
  const points = Array.isArray(history) ? history.slice() : [];
  if (points.length === 0) points.push({ t: startedAt, v: PAPER_CAPITAL });
  const last = points[points.length - 1];
  if (!last || now - last.t >= 60_000) points.push({ t: now, v: value });
  else points[points.length - 1] = { t: now, v: value };
  if (points.length <= 2000) return points;
  const older = points.slice(0, -500).filter((_, index) => index % 3 === 0);
  return [...older, ...points.slice(-500)].slice(-2000);
}

export function equityOf(state: PaperState): number {
  return state.cash + state.positions.reduce((sum, position) => sum + contribution(position, markOf(state, position.symbol, position.entry)), 0);
}

export function riskOf(state: PaperState): { level: RiskProfile; note: string } {
  const settings = settingsOf(state);
  const nearStop = state.positions.some((position) => {
    const price = markOf(state, position.symbol, position.entry);
    if (!(price > 0)) return false;
    const gap = sideOf(position) === "short" ? (position.stop - price) / price : (price - position.stop) / price;
    return gap >= 0 && gap < 0.012;
  });
  const note =
    settings.profile === "eleve"
      ? "Cadre élevé : plus de lignes, des entrées plus larges et davantage de capital engagé."
      : settings.profile === "modere"
        ? "Cadre moyen : plus de lignes et des entrées un peu moins strictes."
        : "Cadre faible : peu de lignes et des signaux stricts.";
  return {
    level: settings.profile,
    note: nearStop ? `${note} Une position est proche de son stop.` : note,
  };
}

type EntryRules = {
  rsiMin: number;
  rsiMax: number;
  volCrypto: number;
  volStock: number;
  day: number;
  stretch: number;
  volume: number;
  score: number;
  allowNeutral: boolean;
  buys: number;
};

function entryRules(profile: RiskProfile): EntryRules {
  if (profile === "eleve") {
    return { rsiMin: 30, rsiMax: 80, volCrypto: 14, volStock: 8, day: 8, stretch: 1.12, volume: 0.05, score: 0, allowNeutral: true, buys: 3 };
  }
  if (profile === "modere") {
    return { rsiMin: 38, rsiMax: 76, volCrypto: 9, volStock: 5, day: 5, stretch: 1.08, volume: 0.12, score: 2, allowNeutral: false, buys: 2 };
  }
  return { rsiMin: 42, rsiMax: 72, volCrypto: 6, volStock: 3.5, day: 3, stretch: 1.05, volume: 0.2, score: 4, allowNeutral: false, buys: 2 };
}

function trendOk(quote: BotQuote, rules: EntryRules): boolean {
  if (quote.trend === "haussiere") return true;
  return rules.allowNeutral && quote.trend === "neutre" && quote.sentiment >= 0;
}

function roundQty(value: number): number {
  return Math.floor(value * 10_000) / 10_000;
}

function rsiLabel(value: number | null): string {
  return value == null ? "RSI indisponible" : `RSI ${Math.round(value)}`;
}

function newsIsAbout(quote: BotQuote): boolean {
  if (!quote.headline) return false;
  const title = quote.headline.toLowerCase();
  const name = quote.name.toLowerCase();
  const symbol = quote.symbol.replace(/-USD$/i, "").toLowerCase();
  return title.includes(name) || title.includes(symbol.toLowerCase());
}

function canBuy(quote: BotQuote, state: PaperState): boolean {
  const risk = settingsOf(state);
  const managed = state.positions.filter((position) => actorOf(position) === "bot");
  const stocks = managed.filter((position) => position.kind === "stock").length;
  const cryptos = managed.filter((position) => position.kind === "crypto").length;
  if (quote.kind === "stock" && stocks >= risk.stockSlots) return false;
  if (quote.kind === "crypto" && cryptos >= risk.cryptoSlots) return false;
  return entryBuy(quote, state);
}

function entryBuy(quote: BotQuote, state: PaperState): boolean {
  const risk = settingsOf(state);
  if (state.positions.some((position) => position.symbol === quote.symbol)) return false;
  const cooled = state.trades.some(
    (trade) =>
      trade.symbol === quote.symbol &&
      trade.side === "vente" &&
      trade.actor === "manuel" &&
      Date.now() - trade.at < 12 * 3_600_000,
  );
  if (cooled) return false;
  const rules = entryRules(risk.profile);
  if (!trendOk(quote, rules)) return false;
  if (quote.rsi == null || quote.rsi < rules.rsiMin || quote.rsi > rules.rsiMax) return false;
  if (quote.sentiment <= -30 && newsIsAbout(quote)) return false;
  if (quote.volatility == null) return false;
  if (quote.kind === "crypto" && quote.volatility > rules.volCrypto) return false;
  if (quote.kind === "stock" && quote.volatility > rules.volStock) return false;
  if (quote.changePercent > rules.day || quote.changePercent < -rules.day) return false;
  if (quote.sma20 != null && quote.price > quote.sma20 * rules.stretch) return false;
  if (quote.volumeRatio != null && quote.volumeRatio < rules.volume) return false;
  return true;
}

function trendShortOk(quote: BotQuote, rules: EntryRules): boolean {
  if (quote.trend === "baissiere") return true;
  return rules.allowNeutral && quote.trend === "neutre" && quote.sentiment <= 0;
}

function canShort(quote: BotQuote, state: PaperState): boolean {
  const risk = settingsOf(state);
  const managed = state.positions.filter((position) => actorOf(position) === "bot");
  const stocks = managed.filter((position) => position.kind === "stock").length;
  const cryptos = managed.filter((position) => position.kind === "crypto").length;
  if (state.positions.some((position) => position.symbol === quote.symbol)) return false;
  const cooled = state.trades.some(
    (trade) =>
      trade.symbol === quote.symbol &&
      trade.side === "vente" &&
      trade.actor === "manuel" &&
      Date.now() - trade.at < 12 * 3_600_000,
  );
  if (cooled) return false;
  if (quote.kind === "stock" && stocks >= risk.stockSlots) return false;
  if (quote.kind === "crypto" && cryptos >= risk.cryptoSlots) return false;
  const rules = entryRules(risk.profile);
  if (!trendShortOk(quote, rules)) return false;
  const rsiMin = 100 - rules.rsiMax;
  const rsiMax = 100 - rules.rsiMin;
  if (quote.rsi == null || quote.rsi < rsiMin || quote.rsi > rsiMax) return false;
  if (quote.sentiment >= 30 && newsIsAbout(quote)) return false;
  if (quote.volatility == null) return false;
  if (quote.kind === "crypto" && quote.volatility > rules.volCrypto) return false;
  if (quote.kind === "stock" && quote.volatility > rules.volStock) return false;
  if (quote.changePercent > rules.day || quote.changePercent < -rules.day) return false;
  if (quote.sma20 != null && quote.price < quote.sma20 * (2 - rules.stretch)) return false;
  if (quote.volumeRatio != null && quote.volumeRatio < rules.volume) return false;
  return true;
}

function buyScore(quote: BotQuote): number {
  const rsi = quote.rsi ?? 50;
  const vol = quote.volatility ?? 3;
  return quote.sentiment * 0.35 + (68 - rsi) * 0.4 - vol * 3;
}

function shortScore(quote: BotQuote): number {
  const rsi = quote.rsi ?? 50;
  const vol = quote.volatility ?? 3;
  return -quote.sentiment * 0.35 + (rsi - 32) * 0.4 - vol * 3;
}

export type BotPreview = {
  action: "acheter" | "vendre" | "attendre" | "conserver";
  headline: string;
  lines: string[];
  sizeUsd: number | null;
};

export function previewBot(quote: BotQuote, state: PaperState): BotPreview {
  const risk = settingsOf(state);
  const held = state.positions.find((position) => position.symbol === quote.symbol);
  const lines: string[] = [];
  const trend =
    quote.trend === "haussiere" ? "tendance haussière" : quote.trend === "baissiere" ? "tendance baissière" : "tendance neutre";
  lines.push(
    `${trend}, ${rsiLabel(quote.rsi)}, variation du jour ${quote.changePercent.toFixed(1)} %. Objectif de gain réglé à ${risk.targetPct} %.`,
  );
  if (quote.headline) lines.push(`Actualité : ${quote.headline}`);
  if (state.paused) lines.push("Le bot est en pause : il ne passerait pas l'ordre tant qu'il n'est pas repris.");

  if (held && actorOf(held) === "manuel") {
    return {
      action: "attendre",
      headline: "Ligne manuelle : seuls le stop et l'objectif la ferment.",
      lines,
      sizeUsd: null,
    };
  }

  if (held) {
    const short = sideOf(held) === "short";
    if (hitStop(held, quote.price)) {
      return {
        action: short ? "acheter" : "vendre",
        headline: short ? "Il rachèterait pour couvrir : le stop est touché." : "Il vendrait : le stop est touché.",
        lines,
        sizeUsd: null,
      };
    }
    if (hitTarget(held, quote.price)) {
      return {
        action: short ? "acheter" : "vendre",
        headline: short
          ? `Il rachèterait pour couvrir : l'objectif ${held.target.toFixed(2)} $ est touché.`
          : `Il vendrait : l'objectif ${held.target.toFixed(2)} $ est touché.`,
        lines,
        sizeUsd: null,
      };
    }
    if (!short && quote.trend === "baissiere" && quote.rsi != null && quote.rsi < 45) {
      return { action: "vendre", headline: "Il vendrait : la tendance a tourné.", lines, sizeUsd: null };
    }
    if (!short && quote.sentiment <= -25 && quote.trend !== "haussiere" && newsIsAbout(quote)) {
      return { action: "vendre", headline: "Il vendrait : l'actualité est devenue négative.", lines, sizeUsd: null };
    }
    if (short && quote.trend === "haussiere" && quote.rsi != null && quote.rsi > 55) {
      return { action: "acheter", headline: "Il rachèterait pour couvrir : la tendance est repassée haussière.", lines, sizeUsd: null };
    }
    if (short && quote.sentiment >= 25 && quote.trend !== "baissiere" && newsIsAbout(quote)) {
      return { action: "acheter", headline: "Il rachèterait pour couvrir : l'actualité est devenue positive.", lines, sizeUsd: null };
    }
    return {
      action: "conserver",
      headline: short ? "Il garderait la vente à découvert." : "Il garderait la ligne. Rien ne déclenche une vente.",
      lines,
      sizeUsd: null,
    };
  }

  const blocks: string[] = [];
  const managed = state.positions.filter((position) => actorOf(position) === "bot");
  const stocks = managed.filter((position) => position.kind === "stock").length;
  const cryptos = managed.filter((position) => position.kind === "crypto").length;
  if (state.positions.some((position) => position.symbol === quote.symbol)) blocks.push("La ligne est déjà ouverte.");
  const cooled = state.trades.some(
    (trade) =>
      trade.symbol === quote.symbol &&
      trade.side === "vente" &&
      trade.actor === "manuel" &&
      Date.now() - trade.at < 12 * 3_600_000,
  );
  if (cooled) blocks.push("Fermée à la main : le bot la laisse pendant 12 h.");
  if (quote.kind === "stock" && stocks >= risk.stockSlots) blocks.push("Nombre maximum d'actions déjà ouvert.");
  if (quote.kind === "crypto" && cryptos >= risk.cryptoSlots) blocks.push("Nombre maximum de cryptos déjà ouvert.");
  const rules = entryRules(risk.profile);
  if (!trendOk(quote, rules)) blocks.push(rules.allowNeutral ? "La tendance n'est pas assez porteuse." : "La tendance n'est pas haussière.");
  if (quote.rsi == null || quote.rsi < rules.rsiMin || quote.rsi > rules.rsiMax) blocks.push("Le RSI n'est pas dans la zone d'achat.");
  if (quote.sentiment <= -30 && newsIsAbout(quote)) blocks.push("L'actualité du titre est négative.");
  if (quote.volatility == null) blocks.push("La volatilité n'est pas lisible.");
  if (quote.kind === "crypto" && quote.volatility != null && quote.volatility > rules.volCrypto) blocks.push("Trop volatile pour le cadre actuel.");
  if (quote.kind === "stock" && quote.volatility != null && quote.volatility > rules.volStock) blocks.push("Trop volatile pour le cadre actuel.");
  if (quote.changePercent > rules.day || quote.changePercent < -rules.day) blocks.push("La séance est trop agitée.");
  if (quote.sma20 != null && quote.price > quote.sma20 * rules.stretch) blocks.push("Le cours est déjà étendu au-dessus de la moyenne.");
  if (quote.volumeRatio != null && quote.volumeRatio < rules.volume) blocks.push("Le volume est trop faible.");
  const equity = equityOf({ ...state, marks: { ...state.marks, [quote.symbol]: quote.price } });
  const invested = investedValue(state);
  const room = equity * (risk.maxInvestedPct / 100) - invested;
  const fraction = (quote.kind === "crypto" ? risk.cryptoSizePct : risk.stockSizePct) / 100;
  const budget = Math.min(equity * fraction, room, state.cash - equity * (1 - risk.maxInvestedPct / 100));
  if (budget < 10) blocks.push("Plus assez de place dans le plafond de risque ou le cash.");
  if (buyScore(quote) < rules.score) blocks.push("Le signal d'achat n'est pas assez net.");

  const shortBlocks: string[] = [];
  if (!trendShortOk(quote, rules)) shortBlocks.push(rules.allowNeutral ? "La tendance n'est pas assez baissière." : "La tendance n'est pas baissière.");
  const shortRsiMin = 100 - rules.rsiMax;
  const shortRsiMax = 100 - rules.rsiMin;
  if (quote.rsi == null || quote.rsi < shortRsiMin || quote.rsi > shortRsiMax) shortBlocks.push("Le RSI n'est pas dans la zone de vente à découvert.");
  if (quote.sentiment >= 30 && newsIsAbout(quote)) shortBlocks.push("L'actualité du titre est positive.");
  if (quote.sma20 != null && quote.price < quote.sma20 * (2 - rules.stretch)) shortBlocks.push("Le cours est déjà trop bas sous la moyenne.");
  if (shortScore(quote) < rules.score) shortBlocks.push("Le signal de baisse n'est pas assez net.");

  if (blocks.length === 0 && buyScore(quote) >= (canShort(quote, state) ? shortScore(quote) : -Infinity)) {
    return {
      action: "acheter",
      headline: `Il achèterait environ ${Math.round(budget)} $, avec un objectif de ${risk.targetPct} %.`,
      lines,
      sizeUsd: Math.round(budget),
    };
  }
  if (shortBlocks.length === 0 && budget >= 10 && canShort(quote, state)) {
    return {
      action: "vendre",
      headline: `Il ouvrirait une vente à découvert d'environ ${Math.round(budget)} $, objectif ${risk.targetPct} % sous le cours.`,
      lines,
      sizeUsd: Math.round(budget),
    };
  }
  return {
    action: "attendre",
    headline: "Il n'ouvrirait ni achat ni vente à découvert.",
    lines: [...lines, ...blocks, ...shortBlocks],
    sizeUsd: null,
  };
}

export function step(state: PaperState, quotes: BotQuote[], now: number): PaperState {
  if (quotes.length === 0) return state;
  const marks = { ...state.marks };
  const tradable: BotQuote[] = [];
  for (const quote of quotes) {
    const last = marks[quote.symbol];
    const price = quote.price;
    const corrupt =
      !Number.isFinite(price) ||
      price <= 0 ||
      (last != null && last > 0 && (price > last * 8 || price < last / 8));
    if (corrupt) continue;
    marks[quote.symbol] = price;
    tradable.push(quote);
  }
  const bySymbol = new Map(tradable.map((quote) => [quote.symbol, quote]));
  let cash = state.cash;
  let positions = state.positions.map((position) => ({ ...position }));
  const trades = [...state.trades];
  const journal = [...state.journal];
  let lastDecisionAt = state.lastDecisionAt;
  let lastNoteAt = state.lastNoteAt;
  let traded = false;
  const closed = new Set<string>();

  const pushNote = (action: PaperNote["action"], text: string) => {
    journal.unshift({ id: `${now}-${action}-${journal.length}`, at: now, action, text });
  };
  const close = (position: PaperPosition, price: number, reason: string) => {
    const pnl = pnlAt(position, price);
    const short = sideOf(position) === "short";
    cash += contribution(position, price);
    closed.add(position.symbol);
    trades.unshift({
      id: `${now}-${short ? "couvrir" : "vente"}-${position.symbol}`,
      at: now,
      side: short ? "achat" : "vente",
      symbol: position.symbol,
      name: position.name,
      qty: position.qty,
      price,
      pnl,
      reason,
      actor: actorOf(position),
      positionSide: sideOf(position),
    });
    pushNote(
      short ? "achat" : "vente",
      short ? `Rachat simulé pour couvrir ${position.name}. ${reason}` : `Vente simulée de ${position.name}. ${reason}`,
    );
    traded = true;
  };

  if (!state.paused) {
    const risk = settingsOf(state);
    const rsiExit = risk.profile === "eleve" ? 38 : risk.profile === "modere" ? 42 : 45;
    const newsExit = risk.profile === "eleve" ? -50 : risk.profile === "modere" ? -35 : -25;
    const kept: PaperPosition[] = [];
    for (const position of positions) {
      const quote = bySymbol.get(position.symbol);
      const price = quote?.price ?? marks[position.symbol] ?? position.entry;
      if (actorOf(position) === "manuel") {
        const live = quote?.price ?? marks[position.symbol];
        if (live == null) {
          kept.push(position);
          continue;
        }
        if (hitStop(position, live)) {
          close(position, live, `Stop-loss manuel touché à ${live.toFixed(2)} $.`);
          continue;
        }
        if (hitTarget(position, live)) {
          close(position, live, `Objectif manuel atteint à ${live.toFixed(2)} $.`);
          continue;
        }
        kept.push(position);
        continue;
      }
      if (!quote) {
        kept.push(position);
        continue;
      }
      const short = sideOf(position) === "short";
      if (hitStop(position, price)) {
        close(
          position,
          price,
          short
            ? `Stop de la vente à découvert touché à ${price.toFixed(2)} $ (entrée ${position.entry.toFixed(2)} $).`
            : `Stop-loss touché à ${price.toFixed(2)} $ (entrée ${position.entry.toFixed(2)} $).`,
        );
        continue;
      }
      if (hitTarget(position, price)) {
        close(position, price, `Objectif ${position.target.toFixed(2)} $ touché (entrée ${position.entry.toFixed(2)} $).`);
        continue;
      }
      if (!short && quote.trend === "baissiere" && quote.rsi != null && quote.rsi < rsiExit) {
        close(position, price, `Tendance passée baissière, ${rsiLabel(quote.rsi)}. Sortie avant d'élargir la perte.`);
        continue;
      }
      if (!short && quote.sentiment <= newsExit && quote.trend !== "haussiere" && newsIsAbout(quote)) {
        close(
          position,
          price,
          `Actualité du titre devenue négative${quote.headline ? ` (« ${quote.headline} »)` : ""}. Sortie de prudence.`,
        );
        continue;
      }
      if (short && quote.trend === "haussiere" && quote.rsi != null && quote.rsi > 100 - rsiExit) {
        close(position, price, `Tendance repassée haussière, ${rsiLabel(quote.rsi)}. Rachat de la vente à découvert.`);
        continue;
      }
      if (short && quote.sentiment >= -newsExit && quote.trend !== "baissiere" && newsIsAbout(quote)) {
        close(
          position,
          price,
          `Actualité devenue positive${quote.headline ? ` (« ${quote.headline} »)` : ""}. Rachat de la vente à découvert.`,
        );
        continue;
      }
      kept.push(position);
    }
    positions = kept;

    let equity = cash + positions.reduce((sum, position) => sum + contribution(position, marks[position.symbol] ?? position.entry), 0);
    let invested = positions.reduce((sum, position) => sum + position.qty * (marks[position.symbol] ?? position.entry), 0);
    const allowEntry = lastDecisionAt === 0 || now - lastDecisionAt >= BUY_GAP_MS;
    const cap = risk.maxInvestedPct / 100;
    const rules = entryRules(risk.profile);
    if (allowEntry) {
      const view = { ...state, cash, positions, risk };
      const foreign = tradable
        .filter(
          (quote) =>
            quote.kind === "stock" &&
            marketOf(quote.symbol) !== "États-Unis" &&
            !positions.some((position) => marketOf(position.symbol) === marketOf(quote.symbol)) &&
            !closed.has(quote.symbol) &&
            entryBuy(quote, view),
        )
        .sort((a, b) => buyScore(b) - buyScore(a))[0];
      const roomNow = equity * cap - invested;
      const stocksNow = positions.filter((position) => actorOf(position) === "bot" && position.kind === "stock").length;
      if (foreign && buyScore(foreign) >= rules.score && (roomNow < 10 || stocksNow >= risk.stockSlots)) {
        const victim = positions
          .filter((position) => actorOf(position) === "bot" && sideOf(position) === "long" && marketOf(position.symbol) === "États-Unis")
          .map((position) => {
            const price = marks[position.symbol] ?? position.entry;
            return { position, price, pnlPct: (price - position.entry) / position.entry, value: position.qty * price };
          })
          .filter((row) => row.pnlPct > -0.03)
          .sort((a, b) => a.value - b.value)[0];
        if (victim) {
          close(
            victim.position,
            victim.price,
            `Rotation vers ${marketOf(foreign.symbol)} : vente de ${victim.position.name} pour ouvrir ${foreign.name}.`,
          );
          positions = positions.filter((position) => position.symbol !== victim.position.symbol);
          equity = cash + positions.reduce((sum, position) => sum + contribution(position, marks[position.symbol] ?? position.entry), 0);
          invested = positions.reduce((sum, position) => sum + position.qty * (marks[position.symbol] ?? position.entry), 0);
        }
      }
    }
    if (allowEntry) {
      for (let n = 0; n < rules.buys; n += 1) {
        const managed = positions.filter((position) => actorOf(position) === "bot");
        if (managed.length >= risk.stockSlots + risk.cryptoSlots) break;
        const room = equity * cap - invested;
        if (room < 10) break;
        const view = { ...state, cash, positions, risk };
        const uncovered = (quote: BotQuote) => {
          const market = marketOf(quote.symbol);
          return market !== "États-Unis" && market !== "Crypto" && !positions.some((position) => marketOf(position.symbol) === market);
        };
        const ideas = [
          ...tradable.filter((quote) => !closed.has(quote.symbol) && canBuy(quote, view)).map((quote) => ({ quote, side: "long" as const, score: buyScore(quote), rank: buyScore(quote) + (uncovered(quote) ? 40 : 0) })),
          ...tradable.filter((quote) => !closed.has(quote.symbol) && canShort(quote, view)).map((quote) => ({ quote, side: "short" as const, score: shortScore(quote), rank: shortScore(quote) })),
        ].sort((a, b) => b.rank - a.rank);
        const pick = ideas[0];
        if (!pick || pick.score < rules.score) break;
        const fraction = (pick.quote.kind === "crypto" ? risk.cryptoSizePct : risk.stockSizePct) / 100;
        const budget = Math.min(equity * fraction, room, cash - equity * (1 - cap));
        const qty = roundQty(budget / pick.quote.price);
        if (!(qty > 0 && qty * pick.quote.price >= 10 && qty * pick.quote.price <= cash)) break;
        const vol = pick.quote.volatility ?? (pick.quote.kind === "crypto" ? 4 : 1.5);
        const stopPct =
          pick.quote.kind === "crypto" ? Math.min(0.08, Math.max(0.05, (vol * 1.6) / 100)) : Math.min(0.07, Math.max(0.04, (vol * 1.6) / 100));
        const short = pick.side === "short";
        const stop = pick.quote.price * (short ? 1 + stopPct : 1 - stopPct);
        const target = pick.quote.price * (short ? 1 - risk.targetPct / 100 : 1 + risk.targetPct / 100);
        if (!(target > 0)) break;
        cash -= qty * pick.quote.price;
        positions.unshift({
          symbol: pick.quote.symbol,
          name: pick.quote.name,
          kind: pick.quote.kind,
          qty,
          entry: pick.quote.price,
          stop,
          target,
          openedAt: now,
          actor: "bot",
          side: pick.side,
        });
        const weight = Math.round(fraction * 100);
        const reason = short
          ? `Vente à découvert. Tendance baissière, ${rsiLabel(pick.quote.rsi)}. Taille ${weight} % du capital, stop au-dessus de l'entrée, objectif ${risk.targetPct} % plus bas.`
          : `Tendance haussière, ${rsiLabel(pick.quote.rsi)}, news ${pick.quote.sentiment > 15 ? "positives" : "sans alerte négative"}. ${marketOf(pick.quote.symbol)}. Taille ${weight} % du capital, stop sous l'entrée, objectif ${risk.targetPct} %.`;
        trades.unshift({
          id: `${now}-${short ? "short" : "achat"}-${pick.quote.symbol}-${n}`,
          at: now,
          side: short ? "vente" : "achat",
          symbol: pick.quote.symbol,
          name: pick.quote.name,
          qty,
          price: pick.quote.price,
          pnl: null,
          reason,
          actor: "bot",
          positionSide: pick.side,
        });
        pushNote(
          short ? "vente" : "achat",
          `${short ? "Vente à découvert simulée" : "Achat automatique"} de ${pick.quote.name}. ${reason}${pick.quote.headline ? ` Titre retenu : ${pick.quote.headline}` : ""}`,
        );
        traded = true;
        lastDecisionAt = now;
        equity = cash + positions.reduce((sum, position) => sum + contribution(position, marks[position.symbol] ?? position.entry), 0);
        invested = positions.reduce((sum, position) => sum + position.qty * (marks[position.symbol] ?? position.entry), 0);
      }
    }

    if (!traded && (lastNoteAt === 0 || now - lastNoteAt >= NOTE_GAP_MS)) {
      const places = [...new Set(tradable.map((quote) => quote.market))].join(", ");
      const roomLeft = equity * cap - invested;
      const blocked = roomLeft < 10 ? " Le plafond investi est atteint, aucune nouvelle ligne tant qu'une vente ne libère pas de place." : "";
      pushNote(
        "attente",
        `Analyse automatique de ${tradable.length} valeurs (${places}). Aucun ordre : le signal n'est pas assez propre pour risquer du capital.${blocked}`,
      );
      lastNoteAt = now;
    }
  }

  const scans: ScanRow[] = tradable.map((quote) => {
    const preview = previewBot(quote, { ...state, cash, positions, marks });
    const verdict: ScanRow["verdict"] = preview.headline.includes("découvert")
      ? "short"
      : preview.action === "acheter" && !preview.headline.includes("rachèt")
        ? "achat"
        : "rien";
    return {
      symbol: quote.symbol,
      name: quote.name,
      market: quote.market,
      trend: quote.trend,
      rsi: quote.rsi,
      changePercent: quote.changePercent,
      verdict,
      reason: preview.headline,
    };
  });

  const equityNow =
    cash + positions.reduce((sum, position) => sum + contribution(position, marks[position.symbol] ?? position.entry), 0);

  return {
    ...state,
    cash,
    positions,
    trades: trades.slice(0, 80),
    journal: journal.slice(0, 40),
    lastDecisionAt,
    lastNoteAt,
    marks,
    scans: scans.length > 0 ? scans : (state.scans ?? []),
    history: pushHistory(state.history, state.startedAt, now, equityNow),
  };
}

export const BACKUP_KEY = "vesper-paper-backup";

export type PaperSnapshot = {
  version: 1;
  savedAt: number;
  book: PaperState;
};

export function accountDestroyed(before: PaperState, after: PaperState): boolean {
  const rich =
    before.positions.length > 0 || before.trades.length > 0 || (before.added || 0) > 0 || before.cash > PAPER_CAPITAL + 1;
  const poor =
    after.positions.length === 0 && after.trades.length === 0 && (after.added || 0) === 0 && after.cash <= PAPER_CAPITAL + 1;
  return rich && poor;
}

export function isBlankBook(state: PaperState): boolean {
  return (
    state.positions.length === 0 &&
    state.trades.length === 0 &&
    state.journal.length === 0 &&
    (state.added || 0) === 0 &&
    Math.abs(state.cash - PAPER_CAPITAL) < 0.01 &&
    (state.history?.length ?? 0) <= 1
  );
}

export function snapshotOf(state: PaperState, now = Date.now()): PaperSnapshot {
  return {
    version: 1,
    savedAt: now,
    book: {
      cash: state.cash,
      positions: state.positions,
      trades: state.trades,
      journal: state.journal,
      paused: state.paused,
      activated: state.activated === true,
      armed: state.armed,
      startedAt: state.startedAt,
      lastDecisionAt: state.lastDecisionAt,
      lastNoteAt: state.lastNoteAt,
      marks: state.marks,
      added: state.added || 0,
      risk: settingsOf(state),
      history: state.history ?? [],
      scans: state.scans ?? [],
    },
  };
}

function parseScans(value: unknown): ScanRow[] {
  if (!Array.isArray(value)) return [];
  const rows: ScanRow[] = [];
  for (const item of value) {
    if (!item || typeof item !== "object") continue;
    const row = item as Record<string, unknown>;
    if (typeof row.symbol !== "string" || typeof row.name !== "string" || typeof row.reason !== "string") continue;
    const trend = row.trend === "haussiere" || row.trend === "baissiere" ? row.trend : "neutre";
    const verdict = row.verdict === "achat" || row.verdict === "short" ? row.verdict : "rien";
    rows.push({
      symbol: row.symbol,
      name: row.name,
      market: typeof row.market === "string" ? row.market : "États-Unis",
      trend,
      rsi: finite(row.rsi),
      changePercent: finite(row.changePercent) ?? 0,
      verdict,
      reason: row.reason.slice(0, 180),
    });
  }
  return rows.slice(0, 60);
}

function finite(value: unknown): number | null {
  const next = typeof value === "number" ? value : Number(value);
  return Number.isFinite(next) ? next : null;
}

export function parseSnapshot(raw: unknown): PaperState | null {
  if (!raw || typeof raw !== "object") return null;
  const root = raw as { book?: unknown };
  const book = (root.book ?? raw) as Record<string, unknown>;
  const cash = finite(book.cash);
  if (cash == null || cash < 0 || cash > 10_000_000) return null;
  if (!Array.isArray(book.positions) || !Array.isArray(book.journal)) return null;

  const positions: PaperPosition[] = [];
  for (const item of book.positions) {
    if (!item || typeof item !== "object") continue;
    const row = item as Record<string, unknown>;
    const qty = finite(row.qty);
    const entry = finite(row.entry);
    const stop = finite(row.stop);
    const target = finite(row.target);
    const openedAt = finite(row.openedAt);
    const symbol = typeof row.symbol === "string" ? row.symbol : "";
    const name = typeof row.name === "string" ? row.name : symbol;
    if (!symbol || !qty || qty <= 0 || !entry || entry <= 0 || stop == null || target == null || openedAt == null) continue;
    positions.push({
      symbol,
      name,
      kind: row.kind === "crypto" ? "crypto" : "stock",
      qty,
      entry,
      stop,
      target,
      openedAt,
      actor: row.actor === "manuel" ? "manuel" : "bot",
      side: row.side === "short" ? "short" : "long",
    });
  }

  const trades: PaperTrade[] = [];
  if (Array.isArray(book.trades)) {
    for (const item of book.trades) {
      if (!item || typeof item !== "object") continue;
      const row = item as Record<string, unknown>;
      const qty = finite(row.qty);
      const price = finite(row.price);
      const at = finite(row.at);
      if (typeof row.symbol !== "string" || qty == null || price == null || at == null) continue;
      if (row.side !== "achat" && row.side !== "vente") continue;
      trades.push({
        id: typeof row.id === "string" ? row.id : `trade-${at}`,
        at,
        side: row.side,
        symbol: row.symbol,
        name: typeof row.name === "string" ? row.name : row.symbol,
        qty,
        price,
        pnl: finite(row.pnl),
        reason: typeof row.reason === "string" ? row.reason : "",
        actor: row.actor === "manuel" ? "manuel" : "bot",
        positionSide: row.positionSide === "short" ? "short" : row.positionSide === "long" ? "long" : undefined,
      });
    }
  }

  const journal: PaperNote[] = [];
  for (const item of book.journal) {
    if (!item || typeof item !== "object") continue;
    const row = item as Record<string, unknown>;
    const at = finite(row.at);
    if (typeof row.text !== "string" || at == null) continue;
    const action = row.action === "achat" || row.action === "vente" ? row.action : "attente";
    journal.push({
      id: typeof row.id === "string" ? row.id : `note-${at}`,
      at,
      action,
      text: row.text,
    });
  }

  const marks: Record<string, number> = {};
  if (book.marks && typeof book.marks === "object") {
    for (const [key, value] of Object.entries(book.marks as Record<string, unknown>)) {
      const price = finite(value);
      if (price != null && price > 0) marks[key] = price;
    }
  }

  const history: EquityPoint[] = [];
  if (Array.isArray(book.history)) {
    for (const item of book.history) {
      if (!item || typeof item !== "object") continue;
      const row = item as Record<string, unknown>;
      const t = finite(row.t);
      const v = finite(row.v);
      if (t == null || v == null) continue;
      history.push({ t, v });
    }
  }

  const startedAt = finite(book.startedAt) ?? Date.now();
  const activated = book.activated === true;
  return {
    cash,
    positions: positions.slice(0, 24),
    trades: trades.slice(0, 80),
    journal: journal.slice(0, 40),
    paused: activated ? book.paused === true : true,
    activated,
    armed: true,
    startedAt,
    lastDecisionAt: finite(book.lastDecisionAt) ?? 0,
    lastNoteAt: finite(book.lastNoteAt) ?? 0,
    marks,
    added: Math.max(0, finite(book.added) ?? 0),
    risk: settingsOf({ risk: (book.risk ?? {}) as Partial<RiskSettings> }),
    history: history.slice(-2000),
    scans: parseScans(book.scans),
  };
}

export function manualOpen(
  state: PaperState,
  order: { symbol: string; name: string; kind: Kind; price: number; amount: number; stop: number; target: number; side?: PositionSide },
  now = Date.now(),
): PaperState | null {
  const price = order.price;
  const amount = Math.round(order.amount * 100) / 100;
  const side: PositionSide = order.side === "short" ? "short" : "long";
  if (!order.symbol || !Number.isFinite(price) || price <= 0) return null;
  if (!Number.isFinite(amount) || amount < 10 || amount > state.cash) return null;
  if (state.positions.some((position) => position.symbol === order.symbol)) return null;
  if (!Number.isFinite(order.stop) || !Number.isFinite(order.target)) return null;
  const bracketOk = side === "short" ? order.stop > price && order.target > 0 && order.target < price : order.stop > 0 && order.stop < price && order.target > price;
  if (!bracketOk) return null;
  const qty = Math.floor((amount / price) * 10_000) / 10_000;
  const spent = qty * price;
  if (qty <= 0 || spent < 10 || spent > state.cash + 0.001) return null;
  const cash = state.cash - spent;
  const positions = [
    {
      symbol: order.symbol,
      name: order.name || order.symbol,
      kind: order.kind,
      qty,
      entry: price,
      stop: order.stop,
      target: order.target,
      openedAt: now,
      actor: "manuel" as const,
      side,
    },
    ...state.positions,
  ];
  const marks = { ...state.marks, [order.symbol]: price };
  const equity = cash + positions.reduce((sum, position) => sum + contribution(position, marks[position.symbol] ?? position.entry), 0);
  const short = side === "short";
  return {
    ...state,
    cash,
    positions,
    marks,
    trades: [
      {
        id: `${now}-manuel-${short ? "short" : "achat"}-${order.symbol}`,
        at: now,
        side: short ? ("vente" as const) : ("achat" as const),
        symbol: order.symbol,
        name: order.name || order.symbol,
        qty,
        price,
        pnl: null,
        reason: short
          ? `Vente à découvert manuelle. Stop ${order.stop.toFixed(2)} $, objectif ${order.target.toFixed(2)} $.`
          : `Ordre manuel. Stop ${order.stop.toFixed(2)} $, objectif ${order.target.toFixed(2)} $.`,
        actor: "manuel" as const,
        positionSide: side,
      },
      ...state.trades,
    ].slice(0, 80),
    journal: [
      {
        id: `${now}-manuel-note`,
        at: now,
        action: short ? ("vente" as const) : ("achat" as const),
        text: short
          ? `Vente à découvert manuelle de ${order.name || order.symbol} pour ${spent.toFixed(2)} $. Stop ${order.stop.toFixed(2)} $, objectif ${order.target.toFixed(2)} $.`
          : `Achat manuel de ${order.name || order.symbol} pour ${spent.toFixed(2)} $. Stop ${order.stop.toFixed(2)} $, objectif ${order.target.toFixed(2)} $.`,
      },
      ...state.journal,
    ].slice(0, 40),
    history: pushHistory(state.history, state.startedAt, now, equity),
  };
}

export function manualClose(state: PaperState, symbol: string, price: number, now = Date.now()): PaperState | null {
  const position = state.positions.find((item) => item.symbol === symbol);
  if (!position || !Number.isFinite(price) || price <= 0) return null;
  const pnl = pnlAt(position, price);
  const cash = state.cash + contribution(position, price);
  const positions = state.positions.filter((item) => item.symbol !== symbol);
  const marks = { ...state.marks, [symbol]: price };
  const equity = cash + positions.reduce((sum, item) => sum + contribution(item, marks[item.symbol] ?? item.entry), 0);
  const short = sideOf(position) === "short";
  return {
    ...state,
    cash,
    positions,
    marks,
    trades: [
      {
        id: `${now}-manuel-${short ? "couvrir" : "vente"}-${symbol}`,
        at: now,
        side: short ? ("achat" as const) : ("vente" as const),
        symbol,
        name: position.name,
        qty: position.qty,
        price,
        pnl,
        reason: short ? "Rachat manuel de la vente à découvert." : "Vente manuelle.",
        actor: "manuel" as const,
        positionSide: sideOf(position),
      },
      ...state.trades,
    ].slice(0, 80),
    journal: [
      {
        id: `${now}-manuel-vente-note`,
        at: now,
        action: short ? ("achat" as const) : ("vente" as const),
        text: short
          ? `Rachat manuel pour couvrir ${position.name} à ${price.toFixed(2)} $.`
          : `Vente manuelle de ${position.name} à ${price.toFixed(2)} $.`,
      },
      ...state.journal,
    ].slice(0, 40),
    history: pushHistory(state.history, state.startedAt, now, equity),
  };
}


