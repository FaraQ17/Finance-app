import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Star } from "lucide-react";
import { MarketShell } from "@/components/market/shell";
import { formatPct, formatPrice, toneOf } from "@/lib/format";
import { getQuotes } from "@/lib/market-api";
import type { Filter } from "@/lib/universe";
import { useWatchlist } from "@/lib/watchlist";

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "Tous" },
  { id: "stock", label: "Actions" },
  { id: "crypto", label: "Crypto" },
];

function toneClass(change: number): string {
  const tone = toneOf(change);
  if (tone === "up") return "text-up";
  if (tone === "down") return "text-down";
  return "text-muted";
}

export function Favorites() {
  const [mounted, setMounted] = useState(false);
  const [filter, setFilter] = useState<Filter>("all");
  const items = useWatchlist((state) => state.items);
  const toggle = useWatchlist((state) => state.toggle);

  useEffect(() => {
    setMounted(true);
    void useWatchlist.persist.rehydrate();
  }, []);

  const symbols = useMemo(() => items.map((item) => item.symbol), [items]);
  const quotes = useQuery({
    queryKey: ["favorites", symbols.join(",")],
    enabled: mounted && symbols.length > 0,
    queryFn: () => getQuotes({ data: { symbols } }),
    staleTime: 10_000,
    refetchInterval: 15_000,
    refetchIntervalInBackground: true,
  });
  const quoteMap = new Map((quotes.data?.quotes ?? []).map((quote) => [quote.symbol, quote]));
  const visible = mounted ? items.filter((item) => filter === "all" || item.kind === filter) : [];

  return (
    <MarketShell>
      <main className="mx-auto max-w-3xl space-y-4 px-4 py-4 pb-24 lg:px-6">
        <div>
          <h1 className="text-2xl font-medium">Favoris</h1>
          <p className="mt-1 text-sm text-pretty text-muted">
            L'étoile garde une action ou une crypto ici. Touchez le nom pour ouvrir le desk.
          </p>
        </div>
        <div className="grid grid-cols-3 gap-1 rounded-xl bg-panel p-1 shadow-card" role="tablist" aria-label="Filtre">
          {FILTERS.map((item) => (
            <button
              key={item.id}
              type="button"
              role="tab"
              aria-selected={filter === item.id}
              onClick={() => setFilter(item.id)}
              className={`h-10 rounded-lg text-sm ${filter === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {!mounted ? <p className="text-sm text-muted">Chargement des favoris…</p> : null}
        {mounted && items.length === 0 ? (
          <section className="rounded-2xl bg-panel p-5 shadow-card">
            <p className="text-sm text-pretty text-muted">
              Aucun favori. Sur le desk, les tendances ou une recherche, touchez l'étoile pour retrouver le titre ici.
            </p>
            <Link to="/" className="mt-3 inline-flex h-11 items-center text-sm text-brass">
              Ouvrir le desk
            </Link>
          </section>
        ) : null}
        {mounted && items.length > 0 && visible.length === 0 ? (
          <p className="text-sm text-muted">Aucun favori dans ce filtre.</p>
        ) : null}

        {visible.length > 0 ? (
          <ul className="overflow-hidden rounded-2xl bg-panel shadow-card">
            {visible.map((item) => {
              const quote = quoteMap.get(item.symbol);
              return (
                <li key={item.symbol} className="flex items-center border-b border-line last:border-b-0">
                  <Link to="/" search={{ s: item.symbol }} className="min-w-0 flex-1 px-4 py-3">
                    <span className="flex items-center justify-between gap-3">
                      <span className="truncate text-sm">{item.name}</span>
                      {quote ? (
                        <span className={`shrink-0 font-mono text-sm tabular-nums ${toneClass(quote.changePercent)}`}>
                          {formatPct(quote.changePercent)}
                        </span>
                      ) : (
                        <span className="text-xs text-muted">Cours…</span>
                      )}
                    </span>
                    <span className="mt-1 block font-mono text-xs text-muted">
                      {item.symbol.replace("-USD", "")}
                      {item.kind === "crypto" ? " · Crypto" : " · Action"}
                      {quote ? ` · ${formatPrice(quote.price, quote.currency)}` : ""}
                    </span>
                  </Link>
                  <button
                    type="button"
                    onClick={() => toggle(item)}
                    aria-pressed
                    aria-label={`Retirer ${item.name} des favoris`}
                    className="grid size-11 shrink-0 place-items-center"
                  >
                    <Star className="size-4 fill-brass text-brass" />
                  </button>
                </li>
              );
            })}
          </ul>
        ) : null}
      </main>
    </MarketShell>
  );
}
