import { create } from "zustand";
import { persist } from "zustand/middleware";
import { freshPaper, settingsOf, snapshotOf, parseSnapshot, isBlankBook, accountDestroyed, BACKUP_KEY, type PaperState, type RiskSettings } from "@/lib/paper-bot";
import { getPaperBook, paperCommand } from "@/lib/paper-api";
import type { PaperCommand, PaperView } from "@/lib/bot-runner";
import type { Kind } from "@/lib/universe";

type PaperStore = PaperState & {
  rev: number;
  lastRunAt: number;
  marksAt: number;
  hosted: boolean;
  nudge: () => Promise<void>;
  patchMarks: (marks: Record<string, number>) => void;
  pause: (paused: boolean) => void;
  reset: () => void;
  arm: () => void;
  deposit: (amount: number) => void;
  saveRisk: (risk: RiskSettings) => Promise<boolean>;
  restore: (book: PaperState) => Promise<boolean>;
  adopt: (view: PaperView) => void;
  openManual: (order: { symbol: string; name: string; kind: Kind; price: number; amount: number; stop: number; target: number; side?: "long" | "short" }) => Promise<boolean>;
  closeManual: (symbol: string, price: number) => Promise<boolean>;
};

function adopt(view: PaperView) {
  const current = usePaperStore.getState();
  if (view.ok === false) return;
  if (!view.reset && accountDestroyed(current, view.book)) return;
  if (view.rev < current.rev) return;
  const marks = { ...view.book.marks };
  if (Date.now() - (current.marksAt || 0) < 20_000) {
    for (const [symbol, price] of Object.entries(current.marks)) {
      if (price > 0) marks[symbol] = price;
    }
  }
  usePaperStore.setState({
    ...view.book,
    marks,
    armed: true,
    rev: view.rev,
    lastRunAt: view.lastRunAt,
    hosted: view.hosted === true,
  });
}

function send(data: PaperCommand, state: PaperState) {
  return paperCommand({ data: { ...data, clientBook: snapshotOf(state) } });
}

export const usePaperStore = create<PaperStore>()(
  persist(
    (set, get) => ({
      ...freshPaper(),
      rev: 0,
      lastRunAt: 0,
      marksAt: 0,
      hosted: false,
      nudge: async () => {
        const state = get();
        if (!state.hosted || state.paused || state.activated !== true) return;
        if (state.lastRunAt > 0 && Date.now() - state.lastRunAt < 75_000) return;
        const view = await send({ type: "tick" }, state);
        if (view.ok === false || accountDestroyed(state, view.book)) return;
        adopt(view);
      },
      patchMarks: (marks) =>
        set((state) => {
          const next = { ...state.marks };
          for (const [symbol, price] of Object.entries(marks)) {
            const last = next[symbol];
            if (!(price > 0)) continue;
            if (last != null && last > 0 && (price > last * 8 || price < last / 8)) continue;
            next[symbol] = price;
          }
          return { marks: next, marksAt: Date.now() };
        }),
      pause: (paused) => {
        void send({ type: "pause", paused, activated: true }, get()).then(adopt);
      },
      reset: () => {
        const next = freshPaper(Date.now());
        set({ ...next, armed: true });
        void send({ type: "reset" }, get()).then((view) => adopt({ ...view, reset: true }));
      },
      arm: () => set({ armed: true }),
      deposit: (amount) => {
        void send({ type: "deposit", amount }, get()).then(adopt);
      },
      saveRisk: async (risk) => {
        const clean = settingsOf({ risk });
        const previous = settingsOf(usePaperStore.getState());
        set({ risk: clean });
        const matches = (saved: RiskSettings) =>
          saved.profile === clean.profile &&
          saved.stockSlots === clean.stockSlots &&
          saved.cryptoSlots === clean.cryptoSlots &&
          saved.stockSizePct === clean.stockSizePct &&
          saved.cryptoSizePct === clean.cryptoSizePct &&
          saved.maxInvestedPct === clean.maxInvestedPct &&
          saved.targetPct === clean.targetPct;
        try {
          const view = await send({ type: "risk", risk: clean }, get());
          adopt(view);
          if (view.ok === false) {
            set({ risk: previous });
            return false;
          }
          return true;
        } catch {
          try {
            const view = await getPaperBook();
            if (matches(settingsOf(view.book))) {
              adopt(view);
              return true;
            }
          } catch {
            // Le serveur n'a pas répondu : on annule l'affichage optimiste.
          }
          set({ risk: previous });
          return false;
        }
      },
      restore: async (book) => {
        const clean = parseSnapshot(snapshotOf(book));
        if (!clean) return false;
        set({ ...clean, armed: true });
        try {
          const view = await send({ type: "replace", book: snapshotOf(clean) }, clean);
          if (view.ok === false || accountDestroyed(clean, view.book)) return false;
          adopt(view);
          return true;
        } catch {
          return false;
        }
      },
      adopt,
      openManual: async (order) => {
        const view = await send({ type: "manualOpen", order }, get());
        adopt(view);
        return view.ok;
      },
      closeManual: async (symbol, price) => {
        const view = await send({ type: "manualClose", symbol, price }, get());
        adopt(view);
        return view.ok;
      },
    }),
    {
      name: "vesper-paper-bot",
      skipHydration: true,
      partialize: (state) => ({
        cash: state.cash,
        positions: state.positions,
        trades: state.trades,
        journal: state.journal,
        paused: state.paused,
        activated: state.activated === true,
        armed: state.armed,
        startedAt: state.startedAt,
        lastDecisionAt: state.lastDecisionAt,
        lastNoteAt: state.lastNoteAt,
        marks: state.marks,
        added: state.added,
        risk: state.risk,
        history: state.history,
      }),
    },
  ),
);

function readBackup(): PaperState | null {
  if (typeof localStorage === "undefined") return null;
  try {
    return parseSnapshot(JSON.parse(localStorage.getItem(BACKUP_KEY) || ""));
  } catch {
    return null;
  }
}

let backupHooked = false;

function hookBackup() {
  if (backupHooked || typeof localStorage === "undefined") return;
  backupHooked = true;
  usePaperStore.subscribe((state) => {
    localStorage.setItem(BACKUP_KEY, JSON.stringify(snapshotOf(state)));
  });
}

export async function bootPaper(): Promise<"restored" | "ready"> {
  await usePaperStore.persist.rehydrate();
  hookBackup();
  const local = usePaperStore.getState();
  try {
    const remote = await getPaperBook();
    if (isBlankBook(remote.book) && !isBlankBook(local)) {
      const view = await send({ type: "replace", book: snapshotOf(local) }, local);
      adopt(view);
      return "restored";
    }
    adopt(remote);
  } catch {
    const saved = readBackup();
    if (saved && isBlankBook(usePaperStore.getState()) && !isBlankBook(saved)) {
      usePaperStore.setState({ ...saved, armed: true });
    }
  }
  return "ready";
}
