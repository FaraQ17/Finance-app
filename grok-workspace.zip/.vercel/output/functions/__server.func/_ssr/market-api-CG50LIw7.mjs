import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { c as universeBySymbol, i as CRYPTO_ALIASES, n as BOARD_STOCKS, o as UNIVERSE, r as BOT_UNIVERSE, s as cleanSymbol, t as BOARD_CRYPTOS } from "./universe-7NGhBY7T.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market-api-CG50LIw7.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var UA = "Mozilla/5.0 (compatible; VesperDesk/1.0; +https://grok.com)";
var memory = /* @__PURE__ */ new Map();
var inflight = /* @__PURE__ */ new Map();
var trendInflight = /* @__PURE__ */ new Map();
var sentimentInflight = /* @__PURE__ */ new Map();
var aiWindowStart = Date.now();
var aiCalls = 0;
function remember(key, ttlMs, value) {
	memory.set(key, {
		exp: Date.now() + ttlMs,
		value
	});
	return value;
}
function recall(key) {
	const hit = memory.get(key);
	if (!hit) return null;
	if (hit.exp < Date.now()) {
		memory.delete(key);
		return null;
	}
	return hit.value;
}
async function yahooJson(url) {
	const response = await fetch(url, {
		headers: {
			Accept: "application/json",
			"User-Agent": UA
		},
		signal: AbortSignal.timeout(12e3)
	});
	if (!response.ok) throw new Error("Cours momentanément indisponible");
	return response.json();
}
function num(value) {
	return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function str(value) {
	return typeof value === "string" ? value : "";
}
function parseChart(payload) {
	const result = payload.chart?.result?.[0];
	const meta = result?.meta;
	if (!result || !meta) throw new Error("Ticker introuvable");
	const price = num(meta.regularMarketPrice);
	if (price == null) throw new Error("Cours indisponible pour ce ticker");
	const previous = num(meta.chartPreviousClose) ?? num(meta.previousClose);
	const quote = result.indicators?.quote?.[0] ?? {};
	const timestamps = result.timestamp ?? [];
	const candles = [];
	for (let i = 0; i < timestamps.length; i += 1) {
		const t = timestamps[i];
		const o = quote.open?.[i];
		const h = quote.high?.[i];
		const l = quote.low?.[i];
		const c = quote.close?.[i];
		const v = quote.volume?.[i];
		if (t == null || o == null || h == null || l == null || c == null) continue;
		if (![
			o,
			h,
			l,
			c
		].every((n) => typeof n === "number" && Number.isFinite(n))) continue;
		candles.push({
			t,
			o,
			h,
			l,
			c,
			v: typeof v === "number" && Number.isFinite(v) ? v : 0
		});
	}
	return {
		name: str(meta.longName) || str(meta.shortName) || str(meta.symbol),
		currency: str(meta.currency) || "USD",
		exchange: str(meta.fullExchangeName) || str(meta.exchangeName),
		instrument: str(meta.instrumentType),
		price,
		previousClose: previous,
		dayHigh: num(meta.regularMarketDayHigh),
		dayLow: num(meta.regularMarketDayLow),
		volume: num(meta.regularMarketVolume),
		week52High: num(meta.fiftyTwoWeekHigh),
		week52Low: num(meta.fiftyTwoWeekLow),
		candles
	};
}
function kindOf(instrument) {
	return instrument === "CRYPTOCURRENCY" ? "crypto" : "stock";
}
function badgeOf(instrument, kind) {
	if (kind === "crypto") return "Crypto";
	if (instrument === "ETF") return "ETF";
	return "Action";
}
function changeFrom(price, previous, fallbackPct) {
	if (previous != null && previous !== 0) {
		const changeAbs = price - previous;
		return {
			changeAbs,
			changePercent: changeAbs / previous * 100
		};
	}
	return {
		changeAbs: 0,
		changePercent: fallbackPct ?? 0
	};
}
function sparkOf(candles) {
	const closes = candles.map((candle) => candle.c);
	if (closes.length <= 24) return closes;
	const out = [];
	for (let i = 0; i < 24; i += 1) out.push(closes[Math.round(i * (closes.length - 1) / 23)] ?? closes[closes.length - 1] ?? 0);
	return out;
}
async function loadChart(symbol, query) {
	const key = `chart:${symbol}:${query}`;
	const cached = recall(key);
	if (cached) return cached;
	return remember(key, 45e3, parseChart(await yahooJson(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?${query}`)));
}
function snapshotFrom(symbol, preferredName, chart) {
	const kind = kindOf(chart.instrument);
	const { changeAbs, changePercent } = changeFrom(chart.price, chart.previousClose, null);
	return {
		symbol,
		name: preferredName || chart.name || symbol,
		kind,
		badge: badgeOf(chart.instrument, kind),
		currency: chart.currency,
		exchange: chart.exchange,
		price: chart.price,
		changePercent,
		changeAbs,
		spark: sparkOf(chart.candles)
	};
}
function rangeQuery(range) {
	if (range === "1d") return "interval=5m&range=1d&includePrePost=false";
	const now = Math.floor(Date.now() / 1e3 / 300) * 300;
	if (range === "7d") return `period1=${now - 604800}&period2=${now}&interval=1h`;
	return `period1=${now - 2592e3}&period2=${now}&interval=1d`;
}
async function mapPool(items, limit, fn) {
	const out = new Array(items.length);
	let index = 0;
	async function worker() {
		while (index < items.length) {
			const current = index;
			index += 1;
			out[current] = await fn(items[current]);
		}
	}
	const workers = Math.min(limit, items.length);
	await Promise.all(Array.from({ length: workers }, () => worker()));
	return out;
}
function safeHttp(url) {
	try {
		const parsed = new URL(url);
		if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return null;
		return parsed.toString();
	} catch {
		return null;
	}
}
function hostOf(url) {
	try {
		return new URL(url).hostname.replace(/^www\./, "");
	} catch {
		return "";
	}
}
async function loadNews(query, symbol) {
	const key = `news:${symbol}:${query}`;
	const cached = recall(key);
	if (cached) return cached;
	const payload = await yahooJson(`https://query2.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(query)}&quotesCount=0&newsCount=12`);
	const base = symbol.replace(/-USD$/i, "");
	const mapped = [];
	const related = [];
	for (const item of payload.news ?? []) {
		const url = safeHttp(str(item.link));
		const title = str(item.title).trim();
		if (!url || !title) continue;
		const tickers = Array.isArray(item.relatedTickers) ? item.relatedTickers.map((ticker) => String(ticker)) : [];
		const entry = {
			id: str(item.uuid) || url,
			title: title.slice(0, 180),
			publisher: str(item.publisher) || hostOf(url),
			url,
			publishedAt: num(item.providerPublishTime) ?? 0
		};
		mapped.push(entry);
		const hits = tickers.some((ticker) => ticker === symbol || ticker.replace(/-USD$/i, "") === base);
		if (tickers.length === 0 || hits) related.push(entry);
	}
	return remember(key, 12e4, (related.length >= 3 ? related : mapped).slice(0, 6));
}
var getOverview_createServerFn_handler = createServerRpc({
	id: "edc778dcedfd9ea4bd0e18e414a68be2338d42c3064393336d6a69bbfde6d2b1",
	name: "getOverview",
	filename: "src/lib/market-api.ts"
}, (opts) => getOverview.__executeServer(opts));
var getOverview = createServerFn({ method: "GET" }).handler(getOverview_createServerFn_handler, async () => {
	const cached = recall("overview");
	if (cached) return { quotes: cached };
	const quotes = (await mapPool(UNIVERSE, 6, async (item) => {
		try {
			const chart = await loadChart(item.symbol, "interval=15m&range=1d&includePrePost=false");
			return snapshotFrom(item.symbol, item.name, chart);
		} catch {
			return null;
		}
	})).filter((row) => row !== null);
	if (quotes.length === 0) throw new Error("Les cours sont momentanément indisponibles");
	return { quotes: remember("overview", 45e3, quotes) };
});
var getQuotes_createServerFn_handler = createServerRpc({
	id: "cfc7846a37993771363968d82d9b1455ee61371ec4113308f663c30325fd8ddf",
	name: "getQuotes",
	filename: "src/lib/market-api.ts"
}, (opts) => getQuotes.__executeServer(opts));
var getQuotes = createServerFn({ method: "POST" }).validator((input) => {
	const raw = input.symbols;
	return { symbols: Array.isArray(raw) ? [...new Set(raw.map((item) => cleanSymbol(String(item))).filter((item) => !!item))].slice(0, 30) : [] };
}).handler(getQuotes_createServerFn_handler, async ({ data }) => {
	return { quotes: (await mapPool(data.symbols, 4, async (symbol) => {
		try {
			const known = universeBySymbol(symbol);
			const chart = await loadChart(symbol, "interval=15m&range=1d&includePrePost=false");
			return snapshotFrom(symbol, known?.name, chart);
		} catch {
			return null;
		}
	})).filter((row) => row !== null) };
});
async function loadAsset(symbol) {
	const known = universeBySymbol(symbol);
	const chart = await loadChart(symbol, "interval=15m&range=1d&includePrePost=false");
	const kind = kindOf(chart.instrument);
	const { changeAbs, changePercent } = changeFrom(chart.price, chart.previousClose, null);
	const newsQuery = kind === "crypto" ? (known?.name ?? chart.name).replace(/ USD$/i, "") : symbol;
	let news = [];
	try {
		news = await loadNews(newsQuery, symbol);
	} catch {
		news = [];
	}
	return {
		symbol,
		name: known?.name || chart.name || symbol,
		kind,
		badge: badgeOf(chart.instrument, kind),
		currency: chart.currency,
		exchange: chart.exchange,
		price: chart.price,
		changePercent,
		changeAbs,
		dayHigh: chart.dayHigh,
		dayLow: chart.dayLow,
		volume: chart.volume,
		previousClose: chart.previousClose,
		week52High: chart.week52High,
		week52Low: chart.week52Low,
		news
	};
}
var getAsset_createServerFn_handler = createServerRpc({
	id: "a5d1c73f1ebbed46d39e04052b4e2bcb016c60729d169ff5718ad57c6b15c54e",
	name: "getAsset",
	filename: "src/lib/market-api.ts"
}, (opts) => getAsset.__executeServer(opts));
var getAsset = createServerFn({ method: "POST" }).validator((input) => {
	const symbol = cleanSymbol(str(input.symbol));
	if (!symbol) throw new Error("Ticker invalide");
	return { symbol };
}).handler(getAsset_createServerFn_handler, async ({ data }) => loadAsset(data.symbol));
var getChart_createServerFn_handler = createServerRpc({
	id: "0c4db58fb156003b96b8117fa0846ab845716f3ad8ff551332c3e05474d989b8",
	name: "getChart",
	filename: "src/lib/market-api.ts"
}, (opts) => getChart.__executeServer(opts));
var getChart = createServerFn({ method: "POST" }).validator((input) => {
	const symbol = cleanSymbol(str(input.symbol));
	const rangeRaw = str(input.range);
	const range = rangeRaw === "7d" || rangeRaw === "30d" ? rangeRaw : "1d";
	if (!symbol) throw new Error("Ticker invalide");
	return {
		symbol,
		range
	};
}).handler(getChart_createServerFn_handler, async ({ data }) => {
	const chart = await loadChart(data.symbol, rangeQuery(data.range));
	return {
		symbol: data.symbol,
		range: data.range,
		candles: chart.candles
	};
});
var searchAssets_createServerFn_handler = createServerRpc({
	id: "dcc0b9a339daee0d25883b2b642ba128fe6c619d08774229f2cad11cc68ce5e4",
	name: "searchAssets",
	filename: "src/lib/market-api.ts"
}, (opts) => searchAssets.__executeServer(opts));
var searchAssets = createServerFn({ method: "POST" }).validator((input) => {
	return { q: str(input.q).trim().slice(0, 40) };
}).handler(searchAssets_createServerFn_handler, async ({ data }) => {
	if (data.q.length < 1) return { results: [] };
	const key = `search:${data.q.toLowerCase()}`;
	const cached = recall(key);
	if (cached) return { results: cached };
	const payload = await yahooJson(`https://query2.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(data.q)}&quotesCount=8&newsCount=0`);
	const results = [];
	const seen = /* @__PURE__ */ new Set();
	const alias = CRYPTO_ALIASES[data.q.toUpperCase()];
	if (alias) {
		seen.add(alias.symbol);
		results.push({
			symbol: alias.symbol,
			name: alias.name,
			kind: "crypto",
			badge: "Crypto",
			exchange: "CCC"
		});
	}
	for (const quote of payload.quotes ?? []) {
		const quoteType = str(quote.quoteType);
		if (quoteType !== "EQUITY" && quoteType !== "ETF" && quoteType !== "CRYPTOCURRENCY") continue;
		const symbol = cleanSymbol(str(quote.symbol));
		if (!symbol || seen.has(symbol)) continue;
		seen.add(symbol);
		const kind = quoteType === "CRYPTOCURRENCY" ? "crypto" : "stock";
		results.push({
			symbol,
			name: str(quote.shortname) || str(quote.longname) || symbol,
			kind,
			badge: badgeOf(quoteType, kind),
			exchange: str(quote.exchDisp)
		});
		if (results.length >= 8) break;
	}
	return { results: remember(key, 6e4, results) };
});
function clamp(value, min, max) {
	if (!Number.isFinite(value)) return min;
	return Math.min(max, Math.max(min, value));
}
function asStrings(value, limit) {
	if (!Array.isArray(value)) return [];
	return value.map((item) => typeof item === "string" ? item.trim().slice(0, 220) : "").filter(Boolean).slice(0, limit);
}
function biasOf(value) {
	const text = str(value).toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "");
	if (text.includes("baiss")) return "baissiere";
	if (text.includes("hauss")) return "haussiere";
	return "neutre";
}
function riskOf(value) {
	const text = str(value).toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "");
	if (text.includes("elev") || text.includes("haut")) return "eleve";
	if (text.includes("faibl") || text.includes("bas")) return "faible";
	return "modere";
}
function sentimentOf(value, score) {
	const text = str(value).toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "");
	if (text.startsWith("pos")) return "positif";
	if (text.startsWith("neg")) return "negatif";
	if (text.startsWith("neu")) return "neutre";
	if (score > 15) return "positif";
	if (score < -15) return "negatif";
	return "neutre";
}
function sourceKind(url, hinted) {
	const hint = str(hinted).toLowerCase();
	if (hint === "x" || hint === "twitter") return "x";
	if (hint === "marche" || hint === "marché") return "marche";
	const host = hostOf(url);
	if (host === "x.com" || host.endsWith(".x.com") || host === "twitter.com" || host.endsWith(".twitter.com")) return "x";
	return "web";
}
function readModel(payload) {
	const root = payload;
	let text = "";
	const citations = [];
	const seen = /* @__PURE__ */ new Set();
	for (const item of root.output ?? []) {
		if (item.type !== "message") continue;
		for (const part of item.content ?? []) {
			if (part.type === "output_text" && part.text) text += part.text;
			for (const ann of part.annotations ?? []) {
				if (ann.type !== "url_citation") continue;
				const url = safeHttp(str(ann.url));
				if (!url || seen.has(url)) continue;
				seen.add(url);
				const title = str(ann.title).trim();
				citations.push({
					title: title && !title.startsWith("http") ? title.slice(0, 160) : hostOf(url),
					url,
					publisher: hostOf(url),
					kind: sourceKind(url, "")
				});
			}
		}
	}
	return {
		text,
		citations
	};
}
function buildAnalysis(symbol, raw, citations, headlines, cached, term) {
	const data = raw;
	const sentimentScore = Math.round(clamp(num(data.sentimentScore) ?? 0, -100, 100));
	const confidence = Math.round(clamp(num(data.confidence) ?? 50, 0, 100));
	const bias = biasOf(data.bias);
	const canned = `Tendance plutôt ${bias === "haussiere" ? "haussière" : bias === "baissiere" ? "baissière" : "neutre"} à ${confidence} % de confiance sur ${term === "court" ? "les prochains jours" : term === "moyen" ? "un à trois mois" : "six à dix-huit mois"}, selon les news et le cours.`;
	const outlook = str(data.outlook).trim();
	const sources = [];
	const seen = /* @__PURE__ */ new Set();
	const push = (source) => {
		if (!source.url || seen.has(source.url)) return;
		seen.add(source.url);
		sources.push(source);
	};
	if (Array.isArray(data.sources)) for (const item of data.sources) {
		if (!item || typeof item !== "object") continue;
		const record = item;
		const url = safeHttp(str(record.url));
		if (!url) continue;
		push({
			title: str(record.title).trim().slice(0, 160) || hostOf(url),
			url,
			publisher: str(record.publisher).trim().slice(0, 80) || hostOf(url),
			kind: sourceKind(url, record.kind)
		});
	}
	for (const citation of citations) push(citation);
	for (const item of headlines) {
		push({
			title: item.title,
			url: item.url,
			publisher: item.publisher,
			kind: "marche"
		});
		if (sources.length >= 6) break;
	}
	return {
		symbol,
		summary: str(data.summary).trim().slice(0, 700),
		sentiment: sentimentOf(data.sentiment, sentimentScore),
		sentimentScore,
		bullish: asStrings(data.bullish, 4),
		bearish: asStrings(data.bearish, 4),
		risk: riskOf(data.risk),
		riskNote: str(data.riskNote).trim().slice(0, 240),
		confidence,
		bias,
		outlook: outlook.length >= 20 ? outlook.slice(0, 320) : canned,
		sources: sources.slice(0, 6),
		term,
		generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		cached
	};
}
function extractJson(text) {
	const start = text.indexOf("{");
	const end = text.lastIndexOf("}");
	if (start < 0 || end <= start) throw new Error("Réponse illisible");
	return JSON.parse(text.slice(start, end + 1));
}
async function callGrok(prompt, withTools, maxTokens = 1400) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) throw new Error("NO_KEY");
	const from = (/* @__PURE__ */ new Date(Date.now() - 10368e5)).toISOString().slice(0, 10);
	const body = {
		model: "grok-4.5",
		store: false,
		temperature: .2,
		reasoning: { effort: "low" },
		max_output_tokens: maxTokens,
		input: [{
			role: "system",
			content: "Tu es l'analyste du desk Vesper. Tu écris en français, de façon précise et prudente. Tu ne donnes jamais d'ordre d'achat ou de vente. Tu réponds uniquement par un objet JSON valide, sans markdown."
		}, {
			role: "user",
			content: prompt
		}]
	};
	if (withTools) {
		body.tools = [{ type: "web_search" }, {
			type: "x_search",
			from_date: from
		}];
		body.max_tool_calls = 2;
	}
	const response = await fetch("https://api.x.ai/v1/responses", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify(body),
		signal: AbortSignal.timeout(55e3)
	});
	if (!response.ok) throw new Error(`Analyse indisponible (${response.status})`);
	return readModel(await response.json());
}
function promptFor(detail, withTools, term) {
	const headlines = detail.news.slice(0, 6).map((item) => `- ${item.title} (${item.publisher})`).join("\n");
	const today = new Intl.DateTimeFormat("fr-FR", { dateStyle: "long" }).format(/* @__PURE__ */ new Date());
	const span = term === "court" ? "court terme (prochains jours)" : term === "moyen" ? "moyen terme (1 à 3 mois)" : "long terme (6 à 18 mois)";
	return [
		`Actif: ${detail.name} (${detail.symbol}), type ${detail.kind === "crypto" ? "crypto" : "action"}.`,
		`Date: ${today}. Horizon demandé: ${span}.`,
		`Cours: ${detail.price} ${detail.currency}. Variation du jour: ${detail.changePercent.toFixed(2)} %.`,
		"Croise toujours le cours et les news. Ne contredis pas ces chiffres et n'invente aucun cours ni aucun titre.",
		headlines ? `Titres déjà collectés:\n${headlines}` : "Peu de titres locaux.",
		withTools ? "Fais au plus une recherche web et une recherche sur X pour les faits récents, puis réponds." : "Appuie-toi uniquement sur ce contexte, sans outil.",
		"Le sentiment décrit les news sur cet horizon. La confiance dit à quel point les news étayent vraiment cette lecture.",
		`JSON exact:
{"summary":"3 phrases max","sentiment":"positif|neutre|negatif","sentimentScore":0,"bullish":["",""],"bearish":["",""],"risk":"faible|modere|eleve","riskNote":"","confidence":0,"bias":"haussiere|baissiere|neutre","outlook":"Tendance plutôt … à NN % de confiance sur cet horizon, selon les news et le cours.","sources":[{"title":"","url":"https://","publisher":"","kind":"web|x"}]}`,
		"sentimentScore de -100 à 100. confidence de 0 à 100. 2 à 3 arguments de chaque côté. 2 à 4 sources avec de vraies URL. Si une info vient de X, mets kind=x et une URL x.com."
	].join("\n");
}
function takeAiSlot() {
	const now = Date.now();
	if (now - aiWindowStart > 36e5) {
		aiWindowStart = now;
		aiCalls = 0;
	}
	if (aiCalls >= 10) return false;
	aiCalls += 1;
	return true;
}
async function runAnalysis(symbol, force, term) {
	const cacheKey = `ai:${symbol}:${term}`;
	if (!force) {
		const cached = recall(cacheKey);
		if (cached) return {
			ok: true,
			...cached,
			cached: true
		};
	}
	if (!process.env.XAI_API_KEY) return {
		ok: false,
		error: "L'analyse IA n'est pas disponible dans cet environnement."
	};
	if (!takeAiSlot()) return {
		ok: false,
		error: "Trop d'analyses sur une courte période. Réessayez un peu plus tard, ou rouvrez un actif déjà lu."
	};
	let detail;
	try {
		detail = await loadAsset(symbol);
	} catch (error) {
		return {
			ok: false,
			error: error instanceof Error ? error.message : "Actif introuvable"
		};
	}
	try {
		const first = await callGrok(promptFor(detail, true, term), true);
		const analysis = buildAnalysis(symbol, extractJson(first.text), first.citations, detail.news, false, term);
		remember(cacheKey, 18e5, analysis);
		return {
			ok: true,
			...analysis
		};
	} catch {
		try {
			const second = await callGrok(promptFor(detail, false, term), false);
			const analysis = buildAnalysis(symbol, extractJson(second.text), second.citations, detail.news, false, term);
			remember(cacheKey, 18e5, analysis);
			return {
				ok: true,
				...analysis
			};
		} catch (error) {
			if ((error instanceof Error ? error.message : "Analyse impossible") === "NO_KEY") return {
				ok: false,
				error: "L'analyse IA n'est pas disponible dans cet environnement."
			};
			return {
				ok: false,
				error: "L'analyse n'a pas abouti. Réessayez dans un instant."
			};
		}
	}
}
function parseTerm(value) {
	return value === "moyen" || value === "long" ? value : "court";
}
var analyzeAsset_createServerFn_handler = createServerRpc({
	id: "836371e49d70a30075d8e928b6ae7ddd160ab56510cb8ce53c7fa8f60a0d1ad5",
	name: "analyzeAsset",
	filename: "src/lib/market-api.ts"
}, (opts) => analyzeAsset.__executeServer(opts));
var analyzeAsset = createServerFn({ method: "POST" }).validator((input) => {
	const symbol = cleanSymbol(str(input.symbol));
	if (!symbol) throw new Error("Ticker invalide");
	return {
		symbol,
		force: Boolean(input.force),
		term: parseTerm(input.term)
	};
}).handler(analyzeAsset_createServerFn_handler, async ({ data }) => {
	const key = `${data.symbol}:${data.term}`;
	const existing = inflight.get(key);
	if (existing && !data.force) return existing;
	const job = runAnalysis(data.symbol, data.force, data.term).finally(() => {
		inflight.delete(key);
	});
	inflight.set(key, job);
	return job;
});
function returnOver(closes, sessions) {
	if (closes.length <= sessions) return null;
	const last = closes[closes.length - 1];
	const base = closes[closes.length - 1 - sessions];
	if (last == null || base == null || base === 0) return null;
	return (last - base) / base * 100;
}
async function loadPerfs(kind) {
	const key = `perfs:${kind}`;
	const cached = recall(key);
	if (cached) return cached;
	const perfs = (await mapPool(kind === "stock" ? BOARD_STOCKS : BOARD_CRYPTOS, 8, async (item) => {
		try {
			const chart = await loadChart(item.symbol, "interval=1d&range=1mo");
			const closes = chart.candles.map((candle) => candle.c);
			const r1 = returnOver(closes, 1);
			if (r1 == null) return null;
			const price = closes[closes.length - 1] ?? chart.price;
			return {
				symbol: item.symbol,
				name: item.name,
				currency: chart.currency,
				price,
				r1,
				r5: returnOver(closes, 5),
				r10: returnOver(closes, 10)
			};
		} catch {
			return null;
		}
	})).filter((row) => row !== null);
	if (perfs.length < 8) throw new Error("Classement momentanément indisponible");
	return remember(key, 18e4, perfs);
}
async function headlineFor(symbol, name, kind) {
	const key = `hl:${symbol}`;
	const cached = recall(key);
	if (cached) return cached;
	const query = kind === "crypto" ? name : symbol;
	let headline = null;
	let headlineUrl = null;
	let publisher = null;
	try {
		const first = (await loadNews(query, symbol))[0];
		if (first) {
			headline = first.title;
			headlineUrl = first.url;
			publisher = first.publisher;
		}
	} catch {
		headline = null;
	}
	return remember(key, 6e5, {
		headline,
		headlineUrl,
		publisher
	});
}
async function buildBoard(kind, horizon) {
	const perfs = await loadPerfs(kind);
	const field = horizon === 1 ? "r1" : horizon === 5 ? "r5" : "r10";
	const ranked = perfs.filter((row) => row[field] != null).sort((a, b) => (b[field] ?? 0) - (a[field] ?? 0));
	const bestPerf = ranked.slice(0, 10);
	const seen = new Set(bestPerf.map((row) => row.symbol));
	const worstPerf = [...ranked].reverse().filter((row) => !seen.has(row.symbol)).slice(0, 10);
	const headlines = await mapPool([...bestPerf, ...worstPerf], 6, (row) => headlineFor(row.symbol, row.name, kind));
	const toRow = (row, index) => {
		const news = headlines[index];
		return {
			symbol: row.symbol,
			name: row.name,
			currency: row.currency,
			price: row.price,
			changePercent: row[field] ?? 0,
			headline: news?.headline ?? null,
			headlineUrl: news?.headlineUrl ?? null,
			publisher: news?.publisher ?? null
		};
	};
	return {
		kind,
		horizon,
		best: bestPerf.map((row, index) => toRow(row, index)),
		worst: worstPerf.map((row, index) => toRow(row, bestPerf.length + index)),
		scanned: perfs.length
	};
}
function parseHorizon(value) {
	return value === 5 || value === "5" || value === 10 || value === "10" ? value === 10 || value === "10" ? 10 : 5 : 1;
}
var getTrends_createServerFn_handler = createServerRpc({
	id: "0da63a37d7597eb7d481041ee44a46a6e000562a2b7e999b4d389eb97edb923c",
	name: "getTrends",
	filename: "src/lib/market-api.ts"
}, (opts) => getTrends.__executeServer(opts));
var getTrends = createServerFn({ method: "POST" }).validator((input) => {
	return {
		kind: input.kind === "crypto" ? "crypto" : "stock",
		horizon: parseHorizon(input.horizon)
	};
}).handler(getTrends_createServerFn_handler, async ({ data }) => buildBoard(data.kind, data.horizon));
function linesOf(rows) {
	return rows.map((row) => {
		const pct = `${row.changePercent >= 0 ? "+" : ""}${row.changePercent.toFixed(2)}%`;
		const news = row.headline ? ` — ${row.headline} (${row.publisher ?? "source"})` : " — pas de titre récent";
		return `${row.name} (${row.symbol}) ${pct}${news}`;
	}).join("\n");
}
var readTrendBoard_createServerFn_handler = createServerRpc({
	id: "5b20a4127e43f05b3e3dfe6de6a21644e95d79b26d0a18c4ac7b75422f01a403",
	name: "readTrendBoard",
	filename: "src/lib/market-api.ts"
}, (opts) => readTrendBoard.__executeServer(opts));
var readTrendBoard = createServerFn({ method: "POST" }).validator((input) => {
	const kind = input.kind === "crypto" ? "crypto" : "stock";
	const force = Boolean(input.force);
	return {
		kind,
		horizon: parseHorizon(input.horizon),
		force
	};
}).handler(readTrendBoard_createServerFn_handler, async ({ data }) => {
	const key = `trend-ai:${data.kind}:${data.horizon}`;
	if (!data.force) {
		const cached = recall(key);
		if (cached) return {
			...cached,
			cached: true
		};
		const pending = trendInflight.get(key);
		if (pending) return pending;
	}
	const job = (async () => {
		if (!process.env.XAI_API_KEY) return {
			ok: false,
			error: "L'analyse IA n'est pas disponible dans cet environnement."
		};
		if (!takeAiSlot()) return {
			ok: false,
			error: "Trop d'analyses sur une courte période. Réessayez un peu plus tard."
		};
		try {
			const board = await buildBoard(data.kind, data.horizon);
			const label = data.horizon === 1 ? "1 jour" : data.horizon === 5 ? "5 jours" : "10 jours";
			const raw = extractJson((await callGrok([
				`Classement ${data.kind === "crypto" ? "cryptos majeures" : "grandes actions"} sur ${label}. N'invente aucun pourcentage ni aucun titre absent de la liste.`,
				"Relie les mouvements aux titres d'actualité fournis. Si un titre ne colle pas au mouvement, dis-le.",
				"Pas d'ordre d'achat ou de vente.",
				`Meilleures:\n${linesOf(board.best)}`,
				`Moins bonnes:\n${linesOf(board.worst)}`,
				`JSON exact: {"lead":"2 phrases","winnersNote":"pourquoi le haut du tableau","losersNote":"pourquoi le bas du tableau"}`
			].join("\n"), false)).text);
			const result = {
				ok: true,
				lead: str(raw.lead).trim().slice(0, 500),
				winnersNote: str(raw.winnersNote).trim().slice(0, 500),
				losersNote: str(raw.losersNote).trim().slice(0, 500),
				cached: false
			};
			if (!result.lead) return {
				ok: false,
				error: "Lecture vide. Réessayez."
			};
			remember(key, 12e5, result);
			return result;
		} catch (error) {
			if ((error instanceof Error ? error.message : "Lecture impossible") === "NO_KEY") return {
				ok: false,
				error: "L'analyse IA n'est pas disponible dans cet environnement."
			};
			return {
				ok: false,
				error: "La lecture n'a pas abouti. Réessayez dans un instant."
			};
		}
	})().finally(() => {
		trendInflight.delete(key);
	});
	trendInflight.set(key, job);
	return job;
});
var STOCK_SIGNALS = [
	"NVDA",
	"AAPL",
	"MSFT",
	"AMZN",
	"GOOGL",
	"META",
	"TSLA",
	"AVGO",
	"AMD",
	"JPM",
	"LLY",
	"XOM",
	"ASML",
	"MC.PA",
	"AIR.PA",
	"TTE.PA",
	"OR.PA",
	"SAN.PA",
	"SAP.DE",
	"NESN.SW",
	"NOVN.SW",
	"BNP.PA",
	"RMS.PA",
	"SU.PA"
];
var CRYPTO_SIGNALS = BOARD_CRYPTOS.map((item) => item.symbol).slice(0, 24);
function profileOf(symbol, fallbackName, fallbackKind) {
	const known = [
		...UNIVERSE,
		...BOARD_STOCKS,
		...BOARD_CRYPTOS
	].find((item) => item.symbol === symbol);
	if (known) return {
		name: known.name,
		kind: known.kind
	};
	return {
		name: fallbackName?.trim() || symbol,
		kind: fallbackKind ?? (symbol.endsWith("-USD") ? "crypto" : "stock")
	};
}
function poolFor(scope, favorites) {
	if (scope === "favoris") return favorites.slice(0, 20);
	if (scope === "crypto") return CRYPTO_SIGNALS.map((symbol) => ({
		symbol,
		...profileOf(symbol)
	}));
	if (scope === "stock") return STOCK_SIGNALS.map((symbol) => ({
		symbol,
		...profileOf(symbol)
	}));
	const stocks = STOCK_SIGNALS.slice(0, 12).map((symbol) => ({
		symbol,
		...profileOf(symbol)
	}));
	const cryptos = CRYPTO_SIGNALS.slice(0, 12).map((symbol) => ({
		symbol,
		...profileOf(symbol)
	}));
	return [...stocks, ...cryptos];
}
var rankSentiment_createServerFn_handler = createServerRpc({
	id: "99944acc3c247bd79d522a0418376b78609d7ae202415e89cea06894e7e3cb9a",
	name: "rankSentiment",
	filename: "src/lib/market-api.ts"
}, (opts) => rankSentiment.__executeServer(opts));
var rankSentiment = createServerFn({ method: "POST" }).validator((input) => {
	const scopeRaw = input.scope;
	const scope = scopeRaw === "stock" || scopeRaw === "crypto" || scopeRaw === "favoris" || scopeRaw === "mix" ? scopeRaw : "mix";
	const force = Boolean(input.force);
	const raw = input.favorites;
	const favorites = Array.isArray(raw) ? raw.map((item) => {
		if (!item || typeof item !== "object") return null;
		const record = item;
		const symbol = cleanSymbol(str(record.symbol));
		if (!symbol) return null;
		const kind = record.kind === "crypto" ? "crypto" : "stock";
		return {
			symbol,
			name: str(record.name).slice(0, 80) || symbol,
			kind
		};
	}).filter((item) => item !== null).slice(0, 20) : [];
	return {
		term: parseTerm(input.term),
		scope,
		force,
		favorites
	};
}).handler(rankSentiment_createServerFn_handler, async ({ data }) => {
	const favKey = data.favorites.map((item) => item.symbol).join(",");
	const key = `sentiment:${data.term}:${data.scope}:${favKey}`;
	if (!data.force) {
		const cached = recall(key);
		if (cached) return {
			ok: true,
			board: cached,
			cached: true
		};
		const pending = sentimentInflight.get(key);
		if (pending) return pending;
	}
	const job = (async () => {
		const pool = poolFor(data.scope, data.favorites);
		if (pool.length === 0) return {
			ok: false,
			error: "Ajoutez des favoris pour classer leur sentiment."
		};
		if (!process.env.XAI_API_KEY) return {
			ok: false,
			error: "L'analyse IA n'est pas disponible dans cet environnement."
		};
		if (!takeAiSlot()) return {
			ok: false,
			error: "Trop d'analyses sur une courte période. Réessayez un peu plus tard."
		};
		try {
			const ready = (await mapPool(pool, 6, async (item) => {
				try {
					const chart = await loadChart(item.symbol, "interval=1d&range=5d");
					const closes = chart.candles.map((candle) => candle.c);
					const price = closes[closes.length - 1] ?? chart.price;
					const changePercent = returnOver(closes, 1) ?? 0;
					const news = await headlineFor(item.symbol, item.name, item.kind);
					return {
						...item,
						currency: chart.currency,
						price,
						changePercent,
						headline: news.headline
					};
				} catch {
					return null;
				}
			})).filter((row) => row !== null);
			if (ready.length < 4) return {
				ok: false,
				error: "Pas assez de cours pour classer le sentiment."
			};
			const span = data.term === "court" ? "court terme (prochains jours)" : data.term === "moyen" ? "moyen terme (1 à 3 mois)" : "long terme (6 à 18 mois)";
			const lines = ready.map((row) => {
				const pct = `${row.changePercent >= 0 ? "+" : ""}${row.changePercent.toFixed(2)}%`;
				const news = row.headline ? row.headline : "pas de titre récent";
				return `${row.symbol} | ${row.name} | ${row.kind === "crypto" ? "crypto" : "action"} | jour ${pct} | ${news}`;
			}).join("\n");
			const raw = extractJson((await callGrok([
				`Note chaque actif pour un horizon ${span}.`,
				"Croise le mouvement du jour et le titre de news. N'invente aucun titre absent de la ligne.",
				"sentimentScore de -100 à 100 = sentiment des news sur cet horizon.",
				"confidence de 0 à 100 = confiance que les news étayent vraiment cette lecture. Baisse-la si le titre est hors sujet ou absent.",
				"note: une phrase courte, sans conseil d'achat ou de vente.",
				lines,
				`JSON exact: {"rows":[{"symbol":"","sentimentScore":0,"confidence":0,"note":""}]}`,
				"Une entrée par symbole de la liste, pas plus."
			].join("\n"), false, 2600)).text);
			const scored = Array.isArray(raw.rows) ? raw.rows : [];
			const bySymbol = /* @__PURE__ */ new Map();
			for (const item of scored) {
				if (!item || typeof item !== "object") continue;
				const record = item;
				const symbol = cleanSymbol(str(record.symbol));
				if (!symbol) continue;
				bySymbol.set(symbol, {
					sentimentScore: Math.round(clamp(num(record.sentimentScore) ?? 0, -100, 100)),
					confidence: Math.round(clamp(num(record.confidence) ?? 0, 0, 100)),
					note: str(record.note).trim().slice(0, 180)
				});
			}
			const rows = ready.filter((row) => bySymbol.has(row.symbol)).map((row) => {
				const score = bySymbol.get(row.symbol);
				return {
					symbol: row.symbol,
					name: row.name,
					kind: row.kind,
					currency: row.currency,
					price: row.price,
					changePercent: row.changePercent,
					sentiment: sentimentOf(null, score.sentimentScore),
					sentimentScore: score.sentimentScore,
					confidence: score.confidence,
					note: score.note,
					headline: row.headline
				};
			}).sort((a, b) => b.sentimentScore * (b.confidence / 100) - a.sentimentScore * (a.confidence / 100)).slice(0, 20);
			if (rows.length < 4) return {
				ok: false,
				error: "Le classement est incomplet. Réessayez."
			};
			const board = {
				term: data.term,
				scope: data.scope,
				rows,
				scanned: ready.length
			};
			remember(key, 15e5, board);
			return {
				ok: true,
				board,
				cached: false
			};
		} catch (error) {
			if ((error instanceof Error ? error.message : "Classement impossible") === "NO_KEY") return {
				ok: false,
				error: "L'analyse IA n'est pas disponible dans cet environnement."
			};
			return {
				ok: false,
				error: "Le classement n'a pas abouti. Réessayez dans un instant."
			};
		}
	})().finally(() => {
		sentimentInflight.delete(key);
	});
	sentimentInflight.set(key, job);
	return job;
});
function average(values) {
	if (values.length === 0) return null;
	return values.reduce((sum, value) => sum + value, 0) / values.length;
}
function sma(values, period) {
	if (values.length < period) return null;
	return average(values.slice(-period));
}
function rsiOf(values, period = 14) {
	if (values.length < period + 1) return null;
	let gain = 0;
	let loss = 0;
	for (let i = values.length - period; i < values.length; i += 1) {
		const delta = values[i] - values[i - 1];
		if (delta >= 0) gain += delta;
		else loss -= delta;
	}
	if (loss === 0) return 100;
	return 100 - 100 / (1 + gain / loss);
}
function volatilityOf(values) {
	if (values.length < 12) return null;
	const returns = [];
	const window = values.slice(-15);
	for (let i = 1; i < window.length; i += 1) {
		const prev = window[i - 1];
		if (prev === 0) continue;
		returns.push((window[i] - prev) / prev * 100);
	}
	const mid = average(returns);
	if (mid == null || returns.length < 8) return null;
	const variance = average(returns.map((value) => (value - mid) ** 2));
	return variance == null ? null : Math.sqrt(variance);
}
function newsSentiment(title) {
	if (!title) return 0;
	const text = title.toLowerCase();
	const positive = [
		"surge",
		"soar",
		"jump",
		"beat",
		"upgrade",
		"rally",
		"record",
		"growth",
		"approval",
		"gain",
		"rise",
		"strong",
		"boost",
		"expands",
		"wins"
	];
	const negative = [
		"fall",
		"drop",
		"miss",
		"downgrade",
		"lawsuit",
		"crash",
		"plunge",
		"cut",
		"warning",
		"weak",
		"selloff",
		"fraud",
		"slump",
		"loss",
		"decline",
		"sink"
	];
	let score = 0;
	for (const word of positive) if (text.includes(word)) score += 28;
	for (const word of negative) if (text.includes(word)) score -= 34;
	return Math.max(-100, Math.min(100, score));
}
var getBotMarket_createServerFn_handler = createServerRpc({
	id: "ed8233aafd63336b62a4b11cb18864ab480349cbca470fc7b5763688e1f43545",
	name: "getBotMarket",
	filename: "src/lib/market-api.ts"
}, (opts) => getBotMarket.__executeServer(opts));
var getBotMarket = createServerFn({ method: "GET" }).handler(getBotMarket_createServerFn_handler, async () => {
	const cached = recall("bot-market");
	if (cached) return { quotes: cached };
	const quotes = (await mapPool(BOT_UNIVERSE, 6, async (item) => {
		try {
			const chart = await loadChart(item.symbol, "interval=1d&range=6mo");
			const closes = chart.candles.map((candle) => candle.c).filter((value) => Number.isFinite(value));
			const price = closes[closes.length - 1] ?? chart.price;
			const changePercent = returnOver(closes, 1) ?? 0;
			const sma20 = sma(closes, 20);
			const sma50 = sma(closes, 50);
			const trend = sma20 != null && sma50 != null && price > sma20 && sma20 > sma50 ? "haussiere" : sma20 != null && sma50 != null && price < sma20 && sma20 < sma50 ? "baissiere" : "neutre";
			const recent = chart.candles.slice(-20);
			const support = recent.length ? Math.min(...recent.map((candle) => candle.l)) : null;
			const resistance = recent.length ? Math.max(...recent.map((candle) => candle.h)) : null;
			const volumes = chart.candles.map((candle) => candle.v).filter((value) => Number.isFinite(value) && value > 0);
			const latestVolume = volumes[volumes.length - 1];
			const baseVolume = average(volumes.slice(-21, -1));
			const news = await headlineFor(item.symbol, item.name, item.kind);
			return {
				symbol: item.symbol,
				name: item.name,
				kind: item.kind,
				price,
				changePercent,
				rsi: rsiOf(closes),
				sma20,
				sma50,
				volumeRatio: latestVolume != null && baseVolume ? latestVolume / baseVolume : null,
				support,
				resistance,
				volatility: volatilityOf(closes),
				trend,
				sentiment: newsSentiment(news.headline),
				headline: news.headline
			};
		} catch {
			return null;
		}
	})).filter((row) => row !== null);
	if (quotes.length < 6) throw new Error("Marché du bot momentanément indisponible");
	return { quotes: remember("bot-market", 9e4, quotes) };
});
//#endregion
export { analyzeAsset_createServerFn_handler, getAsset_createServerFn_handler, getBotMarket_createServerFn_handler, getChart_createServerFn_handler, getOverview_createServerFn_handler, getQuotes_createServerFn_handler, getTrends_createServerFn_handler, rankSentiment_createServerFn_handler, readTrendBoard_createServerFn_handler, searchAssets_createServerFn_handler };
