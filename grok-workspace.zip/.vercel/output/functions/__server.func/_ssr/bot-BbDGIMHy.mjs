import { i as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { D as usePaperStore, b as investedValue, c as formatPct, d as formatSignedPrice, h as getBotMarket, i as equityOf, n as PAPER_CAPITAL, t as MarketShell, u as formatPrice, w as riskOf, x as positionValue } from "./format-UWdJjcXe.mjs";
import { o as RefreshCw } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bot-BbDGIMHy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function tone(value) {
	if (value > .005) return "text-up";
	if (value < -.005) return "text-down";
	return "text-muted";
}
function stamp(at) {
	return new Intl.DateTimeFormat("fr-FR", {
		day: "2-digit",
		month: "short",
		hour: "2-digit",
		minute: "2-digit"
	}).format(new Date(at));
}
function qtyLabel(value) {
	return new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 4 }).format(value);
}
function TradingBot() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	const cash = usePaperStore((state) => state.cash);
	const positions = usePaperStore((state) => state.positions);
	const trades = usePaperStore((state) => state.trades);
	const journal = usePaperStore((state) => state.journal);
	const paused = usePaperStore((state) => state.paused);
	const startedAt = usePaperStore((state) => state.startedAt);
	const book = usePaperStore();
	(0, import_react.useEffect)(() => {
		let cancel = false;
		(async () => {
			await usePaperStore.persist.rehydrate();
			if (cancel) return;
			usePaperStore.getState().arm();
			setReady(true);
		})();
		return () => {
			cancel = true;
		};
	}, []);
	const market = useQuery({
		queryKey: ["bot-market"],
		enabled: ready,
		queryFn: () => getBotMarket(),
		staleTime: 6e4,
		refetchInterval: 9e4
	});
	const equity = equityOf(book);
	const invested = investedValue(book);
	const pnl = equity - PAPER_CAPITAL;
	const pnlPct = pnl / PAPER_CAPITAL * 100;
	const risk = riskOf(book);
	const riskClass = risk.level === "eleve" ? "text-down" : risk.level === "modere" ? "text-brass" : "text-up";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl space-y-4 px-4 py-4 pb-24 lg:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: "Trading Bot"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-pretty text-muted",
				children: "Portefeuille virtuel. Le bot surveille des grandes valeurs et Bitcoin / Ethereum tant que Vesper est ouvert sur cet appareil."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-2xl bg-panel px-4 py-3 text-sm text-pretty text-muted shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-brass",
						children: "Compte fictif. "
					}),
					"Capital de départ ",
					formatPrice(PAPER_CAPITAL, "USD"),
					". Aucun ordre réel, aucun argent engagé. Ce n'est pas un conseil en investissement."
				]
			}),
			!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Chargement du compte…"
			}) : null,
			ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-panel p-4 shadow-card sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-muted uppercase",
							children: "Valeur du portefeuille"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-mono text-4xl tabular-nums tracking-tight",
							children: formatPrice(equity, "USD")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: `mt-2 font-mono text-sm tabular-nums ${tone(pnl)}`,
							children: [
								formatSignedPrice(pnl, "USD"),
								" · ",
								formatPct(pnlPct),
								" depuis le départ"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid grid-cols-2 gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-muted",
								children: "Cash"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-mono tabular-nums",
								children: formatPrice(cash, "USD")
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-muted",
								children: "Investi"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-mono tabular-nums",
								children: formatPrice(invested, "USD")
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-muted",
							children: [
								"Compte ouvert le ",
								stamp(startedAt),
								"."
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-panel p-4 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-muted uppercase",
							children: "Risque"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `mt-1 text-2xl ${riskClass}`,
							children: risk.level === "faible" ? "Faible" : risk.level === "modere" ? "Modéré" : "Élevé"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-pretty text-muted",
							children: risk.note
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-pretty text-muted",
							children: "Plafond 6 % par action, 5 % par crypto, une seule crypto, 40 % investi au maximum. Stop et objectif sur chaque ligne."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => usePaperStore.getState().pause(!paused),
							className: "h-11 rounded-xl bg-brass px-4 text-sm font-medium text-ink",
							children: paused ? "Reprendre" : "Pause"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => market.refetch(),
							disabled: market.isFetching,
							className: "inline-flex h-11 items-center gap-2 rounded-xl bg-panel px-4 text-sm text-fg shadow-card disabled:opacity-60",
							children: [market.isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4 animate-spin" }) : null, "Analyser"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setConfirmReset(true),
							className: "h-11 rounded-xl bg-panel px-4 text-sm text-muted shadow-card",
							children: "Réinitialiser"
						})
					]
				}),
				paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-brass",
					children: "Bot en pause. Les positions restent ouvertes, aucun nouvel ordre."
				}) : null,
				market.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Lecture des cours, des indicateurs et des titres…"
				}) : null,
				market.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => market.refetch(),
					className: "h-11 text-sm text-brass",
					children: "Réessayer l'analyse de marché"
				}) : null,
				confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-panel p-4 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-pretty",
						children: [
							"Remettre le compte fictif à ",
							formatPrice(PAPER_CAPITAL, "USD"),
							" et effacer positions, trades et journal ?"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								usePaperStore.getState().reset();
								setConfirmReset(false);
							},
							className: "h-11 rounded-xl bg-brass px-4 text-sm font-medium text-ink",
							children: "Confirmer"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setConfirmReset(false),
							className: "h-11 px-3 text-sm text-muted",
							children: "Annuler"
						})]
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-panel p-4 shadow-card sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-medium tracking-widest text-muted uppercase",
						children: "Positions ouvertes"
					}), positions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-pretty text-muted",
						children: "Aucune ligne. Le bot n'achète que si la tendance, le RSI, le volume et les news vont dans le même sens."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 divide-y divide-line",
						children: positions.map((position) => {
							const value = positionValue(book, position);
							const gain = value - position.qty * position.entry;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm",
											children: position.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `shrink-0 font-mono text-sm tabular-nums ${tone(gain)}`,
											children: formatSignedPrice(gain, "USD")
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 font-mono text-xs text-muted",
										children: [
											position.symbol.replace("-USD", ""),
											" · ",
											qtyLabel(position.qty),
											" · entrée",
											" ",
											formatPrice(position.entry, "USD")
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-xs text-muted",
										children: [
											"Valeur ",
											formatPrice(value, "USD"),
											" · stop ",
											formatPrice(position.stop, "USD"),
											" · objectif",
											" ",
											formatPrice(position.target, "USD")
										]
									})
								]
							}, position.symbol);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-panel p-4 shadow-card sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-medium tracking-widest text-muted uppercase",
						children: "Journal"
					}), journal.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Le premier passage s'écrit ici après l'analyse."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-3",
						children: journal.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								stamp(note.at),
								" · ",
								note.action === "achat" ? "Achat" : note.action === "vente" ? "Vente" : "Attente"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-pretty",
							children: note.text
						})] }, note.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-panel p-4 shadow-card sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-medium tracking-widest text-muted uppercase",
						children: "Historique"
					}), trades.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Pas encore de trade simulé."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 divide-y divide-line",
						children: trades.map((trade) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm",
										children: [
											trade.side === "achat" ? "Achat" : "Vente",
											" · ",
											trade.name
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `font-mono text-sm tabular-nums ${trade.pnl == null ? "text-muted" : tone(trade.pnl)}`,
										children: trade.pnl == null ? formatPrice(trade.price, "USD") : formatSignedPrice(trade.pnl, "USD")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-mono text-xs text-muted",
									children: [
										stamp(trade.at),
										" · ",
										qtyLabel(trade.qty),
										" · ",
										formatPrice(trade.price, "USD")
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-pretty text-muted",
									children: trade.reason
								})
							]
						}, trade.id))
					})]
				})
			] }) : null
		]
	}) });
}
var SplitComponent = TradingBot;
//#endregion
export { SplitComponent as component };
