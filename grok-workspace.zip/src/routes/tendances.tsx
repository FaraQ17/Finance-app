import { createFileRoute } from "@tanstack/react-router";
import { Trends } from "@/components/market/trends";
import type { Horizon, Kind } from "@/lib/universe";

export const Route = createFileRoute("/tendances")({
  validateSearch: (search: Record<string, unknown>) => {
    const next: { k?: Kind; h?: Horizon } = {};
    if (search.k === "stock" || search.k === "crypto") next.k = search.k;
    if (search.h === 1 || search.h === "1") next.h = 1;
    if (search.h === 5 || search.h === "5") next.h = 5;
    if (search.h === 10 || search.h === "10") next.h = 10;
    return next;
  },
  component: TendancesPage,
});

function TendancesPage() {
  const search = Route.useSearch();
  const kind: Kind = search.k ?? "stock";
  const horizon: Horizon = search.h ?? 1;
  const navigate = Route.useNavigate();
  return (
    <Trends
      kind={kind}
      horizon={horizon}
      onKind={(next) => {
        void navigate({ search: { k: next, h: horizon }, resetScroll: false });
      }}
      onHorizon={(next) => {
        void navigate({ search: { k: kind, h: next }, resetScroll: false });
      }}
    />
  );
}
