#!/bin/sh
# Restarts the preview if it stops. Kept out of startup.sh so this process
# is not matched by the vite command scan below.
set +e
cd /workspace
while true; do
  if ! curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
    for p in /proc/[0-9]*; do
      pid=$(basename "$p")
      if [ "$pid" = "$$" ]; then
        continue
      fi
      cmd=$(tr "\0" " " < "$p/cmdline" 2>/dev/null || true)
      case "$cmd" in
        *vite\ dev\ --host*|*with-app-env.mjs\ vite\ dev*)
          kill "$pid" 2>/dev/null || true
          ;;
      esac
    done
    sleep 1
    if ! curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
      nohup npm run dev >>/tmp/app-startup.log 2>&1 &
    fi
    i=0
    while [ "$i" -lt 30 ]; do
      if curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
        break
      fi
      i=$((i + 1))
      sleep 1
    done
  fi
  sleep 15
done
