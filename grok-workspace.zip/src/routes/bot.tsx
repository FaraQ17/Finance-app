import { createFileRoute } from "@tanstack/react-router";
import { TradingBot } from "@/components/market/trading-bot";

export const Route = createFileRoute("/bot")({
  component: TradingBot,
});
