import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import { PiggyBank, RefreshCw } from "lucide-react";
import { MarketShell } from "@/components/market/shell";
import { ValueChart, type ChartSpan } from "@/components/market/value-chart";
import { formatPct, formatPrice, formatSignedPrice } from "@/lib/format";
import { sessionOf } from "@/lib/market-hours";
import { getAsset, getOrderChart, getSinceChart, inspectForBot, searchAssets, type AnalysisPoint } from "@/lib/market-api";
import { getBotProgress } from "@/lib/paper-api";
import type { BotQuote } from "@/lib/universe";
import {
  PAPER_CAPITAL,
  actorOf,
  basisOf,
  equityOf,
  investedValue,
  positionValue,
  previewBot,
  riskOf,
  settingsOf,
  sideOf,
  pnlAt,
  RISK_PRESETS,
  BACKUP_KEY,
  accountDestroyed,
  parseSnapshot,
  snapshotOf,
  type PaperPosition,
  type RiskSettings,
} from "@/lib/paper-bot";
import { bootPaper, usePaperStore } from "@/lib/paper-store";
import { paperCommand } from "@/lib/paper-api";
import type { SearchHit } from "@/lib/universe";

function tone(value: number): string {
  if (value > 0.005) return "text-up";
  if (value < -0.005) return "text-down";
  return "text-muted";
}

function stamp(at: number): string {
  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(at));
}

function qtyLabel(value: number): string {
  return new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 4 }).format(value);
}

function AnalysisRing() {
  const progress = useQuery({
    queryKey: ["bot-progress"],
    queryFn: () => getBotProgress(),
    refetchInterval: 1000,
  });
  const done = progress.data?.done ?? 0;
  const total = progress.data?.total ?? 0;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  const radius = 18;
  const turn = 2 * Math.PI * radius;
  return (
    <svg viewBox="0 0 48 48" className="size-12 shrink-0" role="img" aria-label={`Analyse ${pct} %`}>
      <circle cx="24" cy="24" r={radius} fill="none" stroke="var(--color-line)" strokeWidth="4" />
      <circle
        cx="24"
        cy="24"
        r={radius}
        fill="none"
        stroke="var(--color-brass)"
        strokeWidth="4"
        strokeLinecap="round"
        strokeDasharray={turn}
        strokeDashoffset={turn * (1 - pct / 100)}
        transform="rotate(-90 24 24)"
      />
      <text x="24" y="25" textAnchor="middle" dominantBaseline="central" fill="currentColor" fontSize="11">
        {pct}
      </text>
    </svg>
  );
}

export function TradingBot() {
  const [ready, setReady] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [pigOn, setPigOn] = useState(false);
  const [riskOpen, setRiskOpen] = useState(false);
  const [cashOpen, setCashOpen] = useState(false);
  const [deposit, setDeposit] = useState("100");
  const [span, setSpan] = useState<ChartSpan>("h");
  const [selected, setSelected] = useState<string | null>(null);
  const [manualOpenPanel, setManualOpenPanel] = useState(false);
  const [notice, setNotice] = useState("");
  const [scanning, setScanning] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const cash = usePaperStore((state) => state.cash);
  const positions = usePaperStore((state) => state.positions);
  const trades = usePaperStore((state) => state.trades);
  const journal = usePaperStore((state) => state.journal);
  const scans = usePaperStore((state) => state.scans ?? []);
  const paused = usePaperStore((state) => state.paused);
  const activated = usePaperStore((state) => state.activated === true);
  const live = activated && !paused;
  const startedAt = usePaperStore((state) => state.startedAt);
  const marksAt = usePaperStore((state) => state.marksAt);
  const hosted = usePaperStore((state) => state.hosted);
  const book = usePaperStore();

  useEffect(() => {
    let cancel = false;
    void (async () => {
      await bootPaper();
      if (cancel) return;
      usePaperStore.getState().arm();
      setReady(true);
    })();
    return () => {
      cancel = true;
    };
  }, []);

  const equity = equityOf(book);
  const invested = investedValue(book);
  const basis = basisOf(book);
  const pnl = equity - basis;
  const pnlPct = basis > 0 ? (pnl / basis) * 100 : 0;
  const risk = riskOf(book);
  const settings = settingsOf(book);
  const riskClass = risk.level === "eleve" ? "text-down" : risk.level === "modere" ? "text-brass" : "text-up";
  const openPosition = positions.find((position) => position.symbol === selected) ?? null;
  const history = useMemo(() => {
    const raw =
      book.history && book.history.length > 0
        ? book.history
        : [
            { t: startedAt, v: PAPER_CAPITAL },
            { t: Date.now(), v: equity },
          ];
    const windows: Record<ChartSpan, number> = {
      min: 6 * 3_600_000,
      h: 24 * 3_600_000,
      d: 30 * 86_400_000,
      m: 365 * 86_400_000,
      y: 5 * 365 * 86_400_000,
    };
    const filtered = raw.filter((point) => point.t >= Date.now() - windows[span]);
    return filtered.length >= 2 ? filtered : raw.slice(-2);
  }, [book.history, equity, span, startedAt]);

  async function closePosition(position: PaperPosition) {
    const price = usePaperStore.getState().marks[position.symbol] ?? position.entry;
    const ok = await usePaperStore.getState().closeManual(position.symbol, price);
    setNotice(ok ? `${position.name} est fermé.` : "Fermeture impossible.");
  }

  return (
    <MarketShell>
      <main className="mx-auto max-w-3xl space-y-4 px-4 py-4 pb-24 lg:px-6">
        <div>
          <h1 className="text-2xl font-medium">Trading Bot</h1>
          <p className="mt-1 text-sm text-pretty text-muted">
            Il analyse, achète, vend et gère le risque seul. Aucun clic n'est nécessaire.
          </p>
        </div>

        <div className="flex items-center gap-3 rounded-2xl bg-panel px-4 py-3 shadow-card">
          <AnalysisRing />
          <span className={`size-2.5 shrink-0 rounded-full ${live ? "bg-up" : "bg-brass"}`} />
          <div>
            <p className="text-sm font-medium">{live ? "Actif" : "Inactif"}</p>
            <p className="text-xs text-pretty text-muted">
              {hosted && live
                ? "Actif tant que cette page est ouverte. Ferme l'onglet et il s'arrête, les lignes restent dans ce navigateur."
                : live
                  ? "Actif. Si l'application s'arrête, il reprend tout seul au redémarrage."
                  : activated
                    ? "En pause. Il ne trade plus tant que tu ne le réactives pas."
                    : "Inactif seulement la première fois. Après activation, un arrêt de l'application ne le coupe pas."}
              {book.lastRunAt ? ` Dernière analyse ${stamp(book.lastRunAt)}.` : ""}
              {marksAt ? ` Cours en direct ${stamp(marksAt)}.` : " Cours en direct dès que la page est ouverte."}
            </p>
          </div>
        </div>

        <p className="rounded-2xl bg-panel px-4 py-3 text-sm text-pretty text-muted shadow-card">
          <span className="font-medium text-brass">Compte fictif. </span>
          Capital de départ {formatPrice(PAPER_CAPITAL, "USD")}. Aucun ordre réel, aucun argent engagé. Ce n'est pas un
          conseil en investissement.
        </p>

        {!ready ? <p className="text-sm text-muted">Chargement du compte…</p> : null}

        {ready ? (
          <>
            <section className="rounded-2xl bg-panel p-4 shadow-card sm:p-5">
              <p className="text-xs font-medium tracking-widest text-muted uppercase">Valeur du portefeuille</p>
              <p className="mt-1 font-mono text-4xl tabular-nums tracking-tight">{formatPrice(equity, "USD")}</p>
              <p className={`mt-2 font-mono text-sm tabular-nums ${tone(pnl)}`}>
                {formatSignedPrice(pnl, "USD")} · {formatPct(pnlPct)} depuis le départ
              </p>
              <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <dt className="text-xs text-muted">Cash</dt>
                  <dd className="font-mono tabular-nums">{formatPrice(cash, "USD")}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted">Investi</dt>
                  <dd className="font-mono tabular-nums">{formatPrice(invested, "USD")}</dd>
                </div>
              </dl>
              <p className="mt-3 text-xs text-muted">
                Compte ouvert le {stamp(startedAt)}
                {book.added > 0 ? ` · dépôts ${formatPrice(book.added, "USD")} non comptés dans le gain` : ""}.
              </p>
              <div className="mt-4 grid grid-cols-4 gap-1 rounded-xl bg-ink p-1" role="tablist" aria-label="Période">
                {(
                  [
                    ["h", "Heures"],
                    ["d", "Jours"],
                    ["m", "Mois"],
                    ["y", "Années"],
                  ] as const
                ).map(([id, label]) => (
                  <button
                    key={id}
                    type="button"
                    role="tab"
                    aria-selected={span === id}
                    onClick={() => setSpan(id)}
                    className={`h-10 rounded-lg text-sm ${span === id ? "bg-brass font-medium text-ink" : "text-muted"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
              <div className="mt-3">
                <ValueChart points={history} currency="USD" span={span} />
              </div>
            </section>

            <section className="rounded-2xl bg-panel p-4 shadow-card">
              <p className="text-xs font-medium tracking-widest text-muted uppercase">Risque</p>
              <p className={`mt-1 text-2xl ${riskClass}`}>
                {risk.level === "faible" ? "Faible" : risk.level === "modere" ? "Moyen" : "Élevé"}
              </p>
              <p className="mt-1 text-sm text-pretty text-muted">{risk.note}</p>
              <p className="mt-2 text-xs text-pretty text-muted">
                {settings.stockSlots} actions en même temps, {settings.cryptoSlots} crypto. Taille {settings.stockSizePct} %
                et {settings.cryptoSizePct} %. Plafond investi {settings.maxInvestedPct} %. Performance visée {settings.targetPct} %.
              </p>
            </section>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => usePaperStore.getState().pause(live)}
                className="h-11 rounded-xl bg-brass px-4 text-sm font-medium text-ink"
              >
                {live ? "Pause" : "Activer"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setRiskOpen((open) => !open);
                  setCashOpen(false);
                }}
                className="h-11 rounded-xl bg-panel px-4 text-sm text-fg shadow-card"
              >
                Risque
              </button>
              <button
                type="button"
                onClick={() => {
                  setCashOpen((open) => !open);
                  setRiskOpen(false);
                }}
                className="h-11 rounded-xl bg-panel px-4 text-sm text-fg shadow-card"
              >
                Ajouter
              </button>
              <button
                type="button"
                onClick={() => {
                  const before = usePaperStore.getState();
                  setScanning(true);
                  void paperCommand({
                    data: { type: "tick", clientBook: snapshotOf(usePaperStore.getState()) },
                  })
                    .then((view) => {
                      if (view.ok === false || accountDestroyed(before, view.book)) {
                        setNotice("Analyse interrompue. Le compte importé n'a pas été modifié.");
                        return;
                      }
                      usePaperStore.getState().adopt(view);
                    })
                    .finally(() => setScanning(false));
                }}
                disabled={scanning}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-panel px-4 text-sm text-fg shadow-card disabled:opacity-60"
              >
                {scanning ? <RefreshCw className="size-4 animate-spin" /> : null}
                Analyser
              </button>
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="h-11 rounded-xl bg-panel px-4 text-sm text-muted shadow-card"
              >
                Réinitialiser
              </button>
              <button
                type="button"
                onClick={() => {
                  const snap = snapshotOf(usePaperStore.getState());
                  localStorage.setItem(BACKUP_KEY, JSON.stringify(snap));
                  const blob = new Blob([JSON.stringify(snap)], { type: "application/json" });
                  const url = URL.createObjectURL(blob);
                  const link = document.createElement("a");
                  link.href = url;
                  link.download = "vesper-bot.json";
                  link.click();
                  URL.revokeObjectURL(url);
                  setNotice("Compte enregistré. Au retour, le journal, les positions et la courbe reprennent ici.");
                }}
                className="h-11 rounded-xl bg-panel px-4 text-sm text-fg shadow-card"
              >
                Enregistrer
              </button>
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="h-11 rounded-xl bg-panel px-4 text-sm text-fg shadow-card"
              >
                Importer
              </button>
              <button
                type="button"
                aria-label="Cochon"
                onClick={() => setPigOn(true)}
                className="grid size-11 place-items-center rounded-xl bg-panel text-fg shadow-card"
              >
                <PiggyBank className="size-5" />
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="application/json,.json"
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  event.target.value = "";
                  if (!file) return;
                  void file.text().then((text) => {
                    try {
                      const book = parseSnapshot(JSON.parse(text));
                      if (!book) {
                        setNotice("Ce fichier ne contient pas un compte Vesper.");
                        return;
                      }
                      void usePaperStore.getState().restore(book).then((ok) => {
                        setNotice(
                          ok
                            ? "Compte importé. Le bot reprend les positions là où elles étaient."
                            : "Import incomplet. Les positions restent affichées, réessaie dans un instant.",
                        );
                      });
                    } catch {
                      setNotice("Fichier illisible.");
                    }
                  });
                }}
              />
            </div>
            {notice ? <p className="text-sm text-pretty text-brass">{notice}</p> : null}
            {live ? null : (
              <p className="text-sm text-brass">
                {activated
                  ? "Bot en pause. Les positions restent ouvertes, aucun ordre automatique."
                  : "Première ouverture : le bot attend que tu l'actives."}
              </p>
            )}
            <p className="text-xs text-pretty text-muted">
              Une coupure de quelques minutes laisse les lignes ouvertes. Le bot reprend au retour et ne rattrape pas un
              stop manqué pendant l'arrêt.
            </p>
            {pigOn ? (
              <div className="fixed inset-0 z-50 grid place-items-center bg-black/75 p-4" onClick={() => setPigOn(false)}>
                <video
                  src="/gopal.mp4"
                  autoPlay
                  controls
                  playsInline
                  className="max-h-[80vh] w-full max-w-lg rounded-2xl bg-black"
                  onClick={(event) => event.stopPropagation()}
                />
              </div>
            ) : null}
            {riskOpen ? <RiskEditor current={settings} onClose={() => setRiskOpen(false)} /> : null}
            {cashOpen ? (
              <section className="rounded-2xl bg-panel p-4 shadow-card">
                <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Ajouter au portefeuille</h2>
                <p className="mt-1 text-sm text-muted">Argent fictif. Le dépôt augmente le cash, pas la performance.</p>
                <div className="mt-3 flex gap-2">
                  {["100", "500", "1000"].map((value) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setDeposit(value)}
                      className={`h-11 flex-1 rounded-xl text-sm ${deposit === value ? "bg-brass font-medium text-ink" : "bg-ink text-muted"}`}
                    >
                      {value} $
                    </button>
                  ))}
                </div>
                <label className="mt-3 block text-xs text-muted" htmlFor="depot">
                  Montant
                </label>
                <input
                  id="depot"
                  inputMode="numeric"
                  value={deposit}
                  onChange={(event) => setDeposit(event.target.value.replace(/[^\d]/g, "").slice(0, 6))}
                  className="mt-1 h-11 w-full rounded-xl bg-ink px-3 font-mono text-base"
                />
                <button
                  type="button"
                  onClick={() => {
                    usePaperStore.getState().deposit(Number(deposit));
                    setCashOpen(false);
                  }}
                  className="mt-3 h-11 rounded-xl bg-brass px-4 text-sm font-medium text-ink"
                >
                  Confirmer le dépôt
                </button>
              </section>
            ) : null}

            {confirmReset ? (
              <section className="rounded-2xl bg-panel p-4 shadow-card">
                <p className="text-sm text-pretty">
                  Remettre le compte fictif à {formatPrice(PAPER_CAPITAL, "USD")} et effacer positions, trades et journal ?
                </p>
                <div className="mt-3 flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      usePaperStore.getState().reset();
                      setConfirmReset(false);
                    }}
                    className="h-11 rounded-xl bg-brass px-4 text-sm font-medium text-ink"
                  >
                    Confirmer
                  </button>
                  <button type="button" onClick={() => setConfirmReset(false)} className="h-11 px-3 text-sm text-muted">
                    Annuler
                  </button>
                </div>
              </section>
            ) : null}

            <BotAsk />

            <section className="rounded-2xl bg-panel p-4 shadow-card sm:p-5">
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Positions ouvertes</h2>
                <button
                  type="button"
                  onClick={() => setManualOpenPanel((open) => !open)}
                  className="h-11 rounded-xl bg-up px-4 text-sm font-medium text-ink"
                >
                  Ouvrir
                </button>
              </div>
              <p className="mt-2 text-xs text-muted">
                <span className="text-up">Vert</span> : ordre manuel · <span className="text-brass">Jaune</span> : bot
              </p>
              {manualOpenPanel ? (
                <ManualTicket
                  cash={cash}
                  onDone={() => setManualOpenPanel(false)}
                />
              ) : null}
              {positions.length === 0 ? (
                <p className="mt-3 text-sm text-pretty text-muted">
                  Aucune ligne. Le bot peut acheter ou vendre à découvert selon la tendance, le RSI, le volume et les news.
                </p>
              ) : (
                <ul className="mt-2 divide-y divide-line">
                  {positions.map((position) => {
                    const value = positionValue(book, position);
                    const gain = pnlAt(position, book.marks[position.symbol] ?? position.entry);
                    const basis = position.qty * position.entry;
                    const gainPct = basis > 0 ? (gain / basis) * 100 : 0;
                    const source = actorOf(position);
                    const short = sideOf(position) === "short";
                    const session = sessionOf(position.symbol);
                    return (
                      <li key={position.symbol} className={`border-l-4 ${source === "manuel" ? "border-up" : "border-brass"} pl-3`}>
                        <button
                          type="button"
                          onClick={() => setSelected(position.symbol === selected ? null : position.symbol)}
                          className="w-full py-3 text-left"
                        >
                          <span className="flex items-baseline justify-between gap-3">
                            <span className="truncate text-sm">
                              {position.name}
                              <span className={`ml-2 text-xs ${source === "manuel" ? "text-up" : "text-brass"}`}>
                                {source === "manuel" ? "Manuel" : "Bot"}
                              </span>
                              <span className={`ml-2 text-xs ${short ? "text-down" : "text-muted"}`}>{short ? "Short" : "Long"}</span>
                            </span>
                            <span className={`shrink-0 font-mono text-sm tabular-nums ${tone(gain)}`}>
                              {formatSignedPrice(gain, "USD")} · {formatPct(gainPct)}
                            </span>
                          </span>
                          <span className="mt-1 block font-mono text-xs text-muted">
                            {position.symbol.replace("-USD", "")} · {position.kind === "crypto" ? "Crypto" : "Action"} ·{" "}
                            {qtyLabel(position.qty)} · entrée {formatPrice(position.entry, "USD")}
                          </span>
                          <span className="mt-1 block text-xs text-muted">
                            {session.place}
                            {" · "}
                            <span className={session.open ? "text-up" : "text-brass"}>{session.status}</span>
                          </span>
                          <span className="mt-1 block text-xs text-muted">
                            {short ? "À racheter" : "Valeur"} {formatPrice(value, "USD")} · stop {formatPrice(position.stop, "USD")} · objectif{" "}
                            {formatPrice(position.target, "USD")}
                            {source === "manuel" ? " · seul le stop et l'objectif ferment la ligne" : ""}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => closePosition(position)}
                          className="mb-3 h-11 w-full rounded-xl bg-ink text-sm font-medium text-fg"
                        >
                          {short ? "Couvrir la ligne" : "Fermer la ligne"}
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
              {openPosition ? <PositionCurve position={openPosition} /> : null}
            </section>

            <section className="rounded-2xl bg-panel p-4 shadow-card sm:p-5">
              <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Analyse par titre</h2>
              <p className="mt-1 text-sm text-muted">Chaque passage note les places suivies. Les prix sont convertis en dollars.</p>
              {scans.length === 0 ? (
                <p className="mt-3 text-sm text-muted">Le détail apparaît après la première analyse.</p>
              ) : (
                <div className="mt-3 space-y-4">
                  {[...new Set(scans.map((row) => row.market))].map((market) => (
                    <div key={market}>
                      <p className="text-xs font-medium tracking-widest text-muted uppercase">{market}</p>
                      <ul className="mt-1 divide-y divide-line">
                        {scans
                          .filter((row) => row.market === market)
                          .map((row) => (
                            <li key={row.symbol} className="py-2">
                              <p className="flex items-baseline justify-between gap-3 text-sm">
                                <span className="truncate">
                                  {row.name}
                                  <span className="ml-2 font-mono text-xs text-muted">{row.symbol.replace("-USD", "")}</span>
                                </span>
                                <span
                                  className={`shrink-0 text-xs ${row.verdict === "achat" ? "text-up" : row.verdict === "short" ? "text-down" : "text-muted"}`}
                                >
                                  {row.verdict === "achat" ? "Achat possible" : row.verdict === "short" ? "Short possible" : "Rien"}
                                </span>
                              </p>
                              <p className="mt-1 text-xs text-pretty text-muted">
                                {row.trend === "haussiere" ? "Hausse" : row.trend === "baissiere" ? "Baisse" : "Neutre"}
                                {row.rsi == null ? "" : ` · RSI ${Math.round(row.rsi)}`}
                                {` · ${row.changePercent >= 0 ? "+" : ""}${row.changePercent.toFixed(1)} %`}
                                {` · ${row.reason}`}
                              </p>
                            </li>
                          ))}
                      </ul>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <section className="rounded-2xl bg-panel p-4 shadow-card sm:p-5">
              <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Décisions automatiques</h2>
              {journal.length === 0 ? (
                <p className="mt-3 text-sm text-muted">Le journal s'écrit ici dès la première analyse, sans action de ta part.</p>
              ) : (
                <ul className="mt-2 space-y-3">
                  {journal.map((note) => (
                    <li key={note.id}>
                      <p className="text-xs text-muted">
                        {stamp(note.at)} · {note.action === "achat" ? "Achat" : note.action === "vente" ? "Vente" : "Attente"}
                      </p>
                      <p className="text-sm text-pretty">{note.text}</p>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section className="rounded-2xl bg-panel p-4 shadow-card sm:p-5">
              <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Historique</h2>
              {trades.length === 0 ? (
                <p className="mt-3 text-sm text-muted">Pas encore de trade simulé.</p>
              ) : (
                <ul className="mt-2 divide-y divide-line">
                  {trades.map((trade) => {
                    const source = actorOf(trade);
                    return (
                    <li key={trade.id} className={`border-l-4 py-3 pl-3 ${source === "manuel" ? "border-up" : "border-brass"}`}>
                      <div className="flex items-baseline justify-between gap-3">
                        <p className="text-sm">
                          {trade.positionSide === "short" ? "Short" : "Long"} · {trade.side === "achat" ? "Achat" : "Vente"} · {trade.name}
                          <span className={`ml-2 text-xs ${source === "manuel" ? "text-up" : "text-brass"}`}>
                            {source === "manuel" ? "Manuel" : "Bot"}
                          </span>
                        </p>
                        <p className={`font-mono text-sm tabular-nums ${trade.pnl == null ? "text-muted" : tone(trade.pnl)}`}>
                          {trade.pnl == null ? formatPrice(trade.price, "USD") : formatSignedPrice(trade.pnl, "USD")}
                        </p>
                      </div>
                      <p className="mt-1 font-mono text-xs text-muted">
                        {stamp(trade.at)} · {qtyLabel(trade.qty)} · {formatPrice(trade.price, "USD")}
                      </p>
                      <p className="mt-1 text-xs text-pretty text-muted">{trade.reason}</p>
                    </li>
                    );
                  })}
                </ul>
              )}
            </section>
          </>
        ) : null}
      </main>
    </MarketShell>
  );
}

function pathFrom(points: { x: number; y: number | null }[]): string {
  let path = "";
  let drawing = false;
  for (const point of points) {
    if (point.y == null) {
      drawing = false;
      continue;
    }
    path += `${drawing ? "L" : "M"}${point.x.toFixed(1)} ${point.y.toFixed(1)} `;
    drawing = true;
  }
  return path;
}

function AnalysisReadout({ quote, series }: { quote: BotQuote; series: AnalysisPoint[] }) {
  const trend = quote.trend === "haussiere" ? "Haussière" : quote.trend === "baissiere" ? "Baissière" : "Neutre";
  const trendClass = quote.trend === "haussiere" ? "text-up" : quote.trend === "baissiere" ? "text-down" : "text-brass";
  const rsi = quote.rsi == null ? "—" : quote.rsi.toFixed(0);
  const rsiNote = quote.rsi == null ? "" : quote.rsi >= 70 ? "élevé" : quote.rsi <= 30 ? "bas" : "milieu";
  const model = useMemo(() => {
    if (series.length < 2) return null;
    const width = 640;
    const height = 300;
    const left = 8;
    const right = 8;
    const prices = series.flatMap((point) => [point.price, point.sma20, point.sma50].filter((value): value is number => value != null));
    let min = Math.min(...prices);
    let max = Math.max(...prices);
    if (min === max) {
      min -= 1;
      max += 1;
    }
    const pad = (max - min) * 0.08;
    min -= pad;
    max += pad;
    const top = 12;
    const priceBottom = 176;
    const rsiTop = 206;
    const rsiBottom = 286;
    const innerW = width - left - right;
    const x = (index: number) => left + (index / (series.length - 1)) * innerW;
    const yPrice = (value: number) => top + ((max - value) / (max - min)) * (priceBottom - top);
    const yRsi = (value: number) => rsiTop + ((100 - value) / 100) * (rsiBottom - rsiTop);
    const price = series.map((point, index) => ({ x: x(index), y: yPrice(point.price) }));
    const sma20 = series.map((point, index) => ({ x: x(index), y: point.sma20 == null ? null : yPrice(point.sma20) }));
    const sma50 = series.map((point, index) => ({ x: x(index), y: point.sma50 == null ? null : yPrice(point.sma50) }));
    const rsiLine = series.map((point, index) => ({ x: x(index), y: point.rsi == null ? null : yRsi(point.rsi) }));
    const rising = series[series.length - 1]!.price >= series[0]!.price;
    return { width, height, priceBottom, rsiTop, rsiBottom, yRsi, price, sma20, sma50, rsiLine, rising, left, right };
  }, [series]);

  const facts = [
    ["Tendance", trend],
    ["RSI 14", rsiNote ? `${rsi} · ${rsiNote}` : rsi],
    ["Moyenne 20 j", quote.sma20 == null ? "—" : formatPrice(quote.sma20, "USD")],
    ["Moyenne 50 j", quote.sma50 == null ? "—" : formatPrice(quote.sma50, "USD")],
    ["Volatilité", quote.volatility == null ? "—" : `${quote.volatility.toFixed(1)} %`],
    ["Volume", quote.volumeRatio == null ? "—" : `${quote.volumeRatio.toFixed(2)}×`],
    ["Support", quote.support == null ? "—" : formatPrice(quote.support, "USD")],
    ["Résistance", quote.resistance == null ? "—" : formatPrice(quote.resistance, "USD")],
    ["Sentiment", `${quote.sentiment > 0 ? "+" : ""}${quote.sentiment}`],
  ];

  return (
    <div className="mt-4 border-t border-line pt-3">
      <p className="text-xs text-muted">Courbe utilisée par le bot · 6 mois</p>
      <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-2">
        {facts.map(([label, value]) => (
          <div key={label}>
            <dt className="text-xs text-muted">{label}</dt>
            <dd className={`font-mono text-sm tabular-nums ${label === "Tendance" ? trendClass : ""}`}>{value}</dd>
          </div>
        ))}
      </dl>
      {model ? (
        <svg viewBox={`0 0 ${model.width} ${model.height}`} className="mt-3 h-64 w-full" role="img" aria-label="Courbe d'analyse">
          <path d={pathFrom(model.price)} fill="none" stroke={model.rising ? "var(--color-up)" : "var(--color-down)"} strokeWidth="2.5" />
          <path d={pathFrom(model.sma20)} fill="none" stroke="var(--color-brass)" strokeWidth="1.5" strokeDasharray="5 4" />
          <path d={pathFrom(model.sma50)} fill="none" stroke="var(--color-muted)" strokeWidth="1.5" strokeDasharray="2 4" />
          <line x1={model.left} x2={model.width - model.right} y1={model.priceBottom + 14} y2={model.priceBottom + 14} stroke="var(--color-line)" />
          <line x1={model.left} x2={model.width - model.right} y1={model.yRsi(70)} y2={model.yRsi(70)} stroke="var(--color-line)" strokeDasharray="3 3" />
          <line x1={model.left} x2={model.width - model.right} y1={model.yRsi(30)} y2={model.yRsi(30)} stroke="var(--color-line)" strokeDasharray="3 3" />
          <path d={pathFrom(model.rsiLine)} fill="none" stroke="var(--color-brass)" strokeWidth="2" />
          <text x={model.left} y={model.rsiTop - 4} fill="var(--color-muted)" fontSize="11">
            RSI
          </text>
          <text x={model.width - model.right} y={model.yRsi(70) - 2} textAnchor="end" fill="var(--color-muted)" fontSize="11">
            70
          </text>
          <text x={model.width - model.right} y={model.yRsi(30) + 12} textAnchor="end" fill="var(--color-muted)" fontSize="11">
            30
          </text>
        </svg>
      ) : (
        <p className="mt-3 text-sm text-muted">Pas assez de séances pour tracer la courbe.</p>
      )}
      <p className="text-xs text-muted">Trait plein : cours. Doré : moyenne 20 jours. Gris : moyenne 50 jours. Bas : RSI.</p>
    </div>
  );
}

function BotAsk() {
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [pick, setPick] = useState<SearchHit | null>(null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<ReturnType<typeof previewBot> | null>(null);
  const [quote, setQuote] = useState<BotQuote | null>(null);
  const [series, setSeries] = useState<AnalysisPoint[]>([]);
  const book = usePaperStore();

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(query.trim()), 250);
    return () => clearTimeout(timer);
  }, [query]);

  const search = useQuery({
    queryKey: ["bot-ask", debounced],
    enabled: debounced.length >= 1 && pick == null,
    queryFn: () => searchAssets({ data: { q: debounced } }),
  });

  const tone =
    result?.action === "acheter" ? "text-up" : result?.action === "vendre" ? "text-down" : "text-brass";

  return (
    <section className="rounded-2xl bg-panel p-4 shadow-card sm:p-5">
      <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Que ferait le bot</h2>
      <p className="mt-1 text-sm text-muted">Une action ou une crypto. Aucun ordre n'est passé.</p>
      <label className="mt-3 block text-xs text-muted" htmlFor="bot-ask">
        Ticker
      </label>
      <input
        id="bot-ask"
        value={pick ? `${pick.symbol.replace("-USD", "")} · ${pick.name}` : query}
        onChange={(event) => {
          setPick(null);
          setResult(null);
          setQuote(null);
          setSeries([]);
          setQuery(event.target.value);
          setError("");
        }}
        placeholder="NVDA, ETH…"
        className="mt-1 h-11 w-full rounded-xl bg-ink px-3 text-base"
      />
      {pick == null && search.data && search.data.results.length > 0 ? (
        <ul className="mt-2 max-h-40 overflow-y-auto">
          {search.data.results.slice(0, 6).map((hit) => (
            <li key={hit.symbol}>
              <button
                type="button"
                onClick={() => {
                  setPick(hit);
                  setResult(null);
                  setQuote(null);
                  setSeries([]);
                }}
                className="flex h-11 w-full items-center justify-between gap-3 text-left text-sm"
              >
                <span className="truncate">{hit.name}</span>
                <span className="shrink-0 font-mono text-xs text-muted">{hit.symbol.replace("-USD", "")}</span>
              </button>
            </li>
          ))}
        </ul>
      ) : null}
      <button
        type="button"
        disabled={!pick || pending}
        onClick={() => {
          if (!pick) return;
          setPending(true);
          setError("");
          void inspectForBot({ data: { symbol: pick.symbol } })
            .then(({ quote: next, series: points }) => {
              setQuote(next);
              setSeries(points);
              setResult(previewBot(next, usePaperStore.getState()));
            })
            .catch(() => setError("Analyse impossible pour ce titre."))
            .finally(() => setPending(false));
        }}
        className="mt-3 h-11 rounded-xl bg-brass px-4 text-sm font-medium text-ink disabled:opacity-50"
      >
        {pending ? "Lecture…" : "Analyser"}
      </button>
      {error ? <p className="mt-2 text-sm text-down">{error}</p> : null}
      {result ? (
        <div className="mt-3">
          <p className={`text-lg ${tone}`}>
            {result.action === "acheter"
              ? "Il achèterait"
              : result.action === "vendre"
                ? "Il vendrait"
                : result.action === "conserver"
                  ? "Il garderait"
                  : "Il attendrait"}
          </p>
          <p className="mt-1 text-sm text-pretty">{result.headline}</p>
          <ul className="mt-2 space-y-1">
            {result.lines.map((line) => (
              <li key={line} className="text-sm text-pretty text-muted">
                {line}
              </li>
            ))}
          </ul>
          {quote ? <AnalysisReadout quote={quote} series={series} /> : null}
        </div>
      ) : null}
      {book.paused && result ? <p className="mt-2 text-xs text-brass">Rappel : le bot est en pause.</p> : null}
    </section>
  );
}

function ManualTicket({ cash, onDone }: { cash: number; onDone: () => void }) {
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [pick, setPick] = useState<SearchHit | null>(null);
  const [amount, setAmount] = useState("50");
  const [stop, setStop] = useState("");
  const [target, setTarget] = useState("");
  const [price, setPrice] = useState<number | null>(null);
  const [bookSide, setBookSide] = useState<"long" | "short">("long");
  const [chartSpan, setChartSpan] = useState<"min" | "h" | "d" | "m">("h");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(query.trim()), 250);
    return () => clearTimeout(timer);
  }, [query]);

  useEffect(() => {
    if (!pick) return;
    let cancel = false;
    setPending(true);
    setError("");
    void getAsset({ data: { symbol: pick.symbol } })
      .then((asset) => {
        if (cancel) return;
        setPrice(asset.price);
        setPick({ symbol: asset.symbol, name: asset.name, kind: asset.kind, badge: asset.badge, exchange: asset.exchange });
      })
      .catch(() => {
        if (!cancel) setError("Cours indisponible.");
      })
      .finally(() => {
        if (!cancel) setPending(false);
      });
    return () => {
      cancel = true;
    };
  }, [pick?.symbol]);

  useEffect(() => {
    if (price == null || !pick) return;
    const goal = settingsOf(usePaperStore.getState()).targetPct;
    const width = pick.kind === "crypto" ? 0.05 : 0.04;
    const stopPx = bookSide === "short" ? price * (1 + width) : price * (1 - width);
    const targetPx = bookSide === "short" ? price * (1 - goal / 100) : price * (1 + goal / 100);
    const fmt = (value: number) => (value >= 1 ? value.toFixed(2) : value.toFixed(4));
    setStop(fmt(stopPx));
    setTarget(fmt(Math.max(targetPx, 0)));
  }, [price, pick?.kind, bookSide]);

  const search = useQuery({
    queryKey: ["manual-search", debounced],
    enabled: debounced.length >= 1 && pick == null,
    queryFn: () => searchAssets({ data: { q: debounced } }),
  });
  const orderChart = useQuery({
    queryKey: ["order-chart", pick?.symbol, chartSpan],
    enabled: pick != null,
    queryFn: () => getOrderChart({ data: { symbol: pick!.symbol, span: chartSpan } }),
  });

  const level = (value: string) => Number(value.replace(",", "."));
  const gap = (value: string) => {
    const next = level(value);
    if (price == null || !Number.isFinite(next) || price <= 0) return "";
    return `${(((next - price) / price) * 100).toFixed(1)} %`;
  };
  const guides = useMemo(() => {
    const rows: { value: number; color: string; label: string }[] = [];
    const stopLevel = level(stop);
    const targetLevel = level(target);
    if (Number.isFinite(stopLevel) && stopLevel > 0) rows.push({ value: stopLevel, color: "var(--color-down)", label: "Stop" });
    if (Number.isFinite(targetLevel) && targetLevel > 0) rows.push({ value: targetLevel, color: "var(--color-up)", label: "Objectif" });
    return rows;
  }, [stop, target]);
  const orderPoints = useMemo(
    () => (orderChart.data?.candles ?? []).map((candle) => ({ t: candle.t * 1000, v: candle.c })),
    [orderChart.data],
  );

  return (
    <div className="mt-3 rounded-xl bg-ink p-3">
      <label className="text-xs text-muted" htmlFor="manual-ticker">
        Ticker
      </label>
      <input
        id="manual-ticker"
        value={pick ? `${pick.symbol.replace("-USD", "")} · ${pick.name}` : query}
        onChange={(event) => {
          setPick(null);
          setPrice(null);
          setQuery(event.target.value);
          setError("");
        }}
        placeholder="AAPL, BTC…"
        className="mt-1 h-11 w-full rounded-xl bg-panel px-3 text-base"
      />
      {pick == null && search.data && search.data.results.length > 0 ? (
        <ul className="mt-2 max-h-40 overflow-y-auto">
          {search.data.results.slice(0, 6).map((hit) => (
            <li key={hit.symbol}>
              <button
                type="button"
                onClick={() => setPick(hit)}
                className="flex h-11 w-full items-center justify-between gap-3 text-left text-sm"
              >
                <span className="truncate">{hit.name}</span>
                <span className="shrink-0 font-mono text-xs text-muted">{hit.symbol.replace("-USD", "")}</span>
              </button>
            </li>
          ))}
        </ul>
      ) : null}
      {price != null ? <p className="mt-2 font-mono text-xs text-muted">Cours {formatPrice(price, "USD")}</p> : null}
      <div className="mt-3 grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => setBookSide("long")}
          className={`h-11 rounded-xl text-sm ${bookSide === "long" ? "bg-up font-medium text-ink" : "bg-ink text-muted"}`}
        >
          Long
        </button>
        <button
          type="button"
          onClick={() => setBookSide("short")}
          className={`h-11 rounded-xl text-sm ${bookSide === "short" ? "bg-down font-medium text-ink" : "bg-ink text-muted"}`}
        >
          Short
        </button>
      </div>
      <p className="mt-2 text-xs text-pretty text-muted">
        {bookSide === "short"
          ? "Vente à découvert : tu gagnes si le cours baisse. Le stop est au-dessus, l'objectif en dessous."
          : "Achat : tu gagnes si le cours monte. Le stop est en dessous, l'objectif au-dessus."}
      </p>
      {pick ? (
        <div className="mt-3">
          <div className="grid grid-cols-4 gap-1 rounded-xl bg-panel p-1" role="tablist" aria-label="Période du cours">
            {(
              [
                ["min", "Min"],
                ["h", "Hrs"],
                ["d", "Jours"],
                ["m", "Mois"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={chartSpan === id}
                onClick={() => setChartSpan(id)}
                className={`h-10 rounded-lg text-sm ${chartSpan === id ? "bg-brass font-medium text-ink" : "text-muted"}`}
              >
                {label}
              </button>
            ))}
          </div>
          {orderChart.isPending ? <p className="mt-3 text-sm text-muted">Chargement de la courbe…</p> : null}
          {orderChart.isError ? <p className="mt-3 text-sm text-down">Courbe indisponible.</p> : null}
          <ValueChart points={orderPoints} guides={guides} currency="USD" span={chartSpan} />
        </div>
      ) : null}
      <label className="mt-3 block text-xs text-muted" htmlFor="manual-amount">
        Montant, max {formatPrice(cash, "USD")}
      </label>
      <input
        id="manual-amount"
        inputMode="decimal"
        value={amount}
        onChange={(event) => setAmount(event.target.value.replace(/[^\d.,]/g, "").slice(0, 8))}
        className="mt-1 h-11 w-full rounded-xl bg-panel px-3 font-mono text-base"
      />
      <label className="mt-3 block text-xs text-muted" htmlFor="manual-stop">
        Stop-loss {gap(stop)}
      </label>
      <input
        id="manual-stop"
        inputMode="decimal"
        value={stop}
        onChange={(event) => setStop(event.target.value.replace(/[^\d.,]/g, "").slice(0, 12))}
        className="mt-1 h-11 w-full rounded-xl bg-panel px-3 font-mono text-base"
      />
      <label className="mt-3 block text-xs text-muted" htmlFor="manual-target">
        Objectif {gap(target)}
      </label>
      <input
        id="manual-target"
        inputMode="decimal"
        value={target}
        onChange={(event) => setTarget(event.target.value.replace(/[^\d.,]/g, "").slice(0, 12))}
        className="mt-1 h-11 w-full rounded-xl bg-panel px-3 font-mono text-base"
      />
      {error ? <p className="mt-2 text-sm text-down">{error}</p> : null}
      <div className="mt-3 flex gap-2">
        <button
          type="button"
          disabled={pending || !pick || price == null}
          onClick={async () => {
            if (!pick || price == null) return;
            const budget = level(amount);
            const stopPrice = level(stop);
            const targetPrice = level(target);
            if (!Number.isFinite(budget) || budget < 10) {
              setError("Minimum 10 $.");
              return;
            }
            if (budget > cash) {
              setError("Pas assez de cash.");
              return;
            }
            if (bookSide === "short") {
              if (!Number.isFinite(stopPrice) || stopPrice <= price) {
                setError("Le stop d'un short doit être au-dessus du cours.");
                return;
              }
              if (!Number.isFinite(targetPrice) || targetPrice <= 0 || targetPrice >= price) {
                setError("L'objectif d'un short doit être sous le cours.");
                return;
              }
            } else if (!Number.isFinite(stopPrice) || stopPrice <= 0 || stopPrice >= price) {
              setError("Le stop doit être sous le cours.");
              return;
            } else if (!Number.isFinite(targetPrice) || targetPrice <= price) {
              setError("L'objectif doit être au-dessus du cours.");
              return;
            }
            setPending(true);
            const ok = await usePaperStore.getState().openManual({
              symbol: pick.symbol,
              name: pick.name,
              kind: pick.kind,
              price,
              amount: budget,
              stop: stopPrice,
              target: targetPrice,
              side: bookSide,
            });
            setPending(false);
            if (!ok) setError("Ordre impossible. Ligne déjà ouverte ou ticket incomplet.");
            else onDone();
          }}
          className="h-11 rounded-xl bg-up px-4 text-sm font-medium text-ink disabled:opacity-50"
        >
          {pending ? "Cours…" : bookSide === "short" ? "Vendre à découvert" : "Acheter"}
        </button>
        <button type="button" onClick={onDone} className="h-11 px-3 text-sm text-muted">
          Annuler
        </button>
      </div>
    </div>
  );
}

function Stepper({
  label,
  value,
  min,
  max,
  suffix,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  suffix?: string;
  onChange: (value: number) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-line py-2 last:border-b-0">
      <span className="text-sm">{label}</span>
      <span className="flex items-center gap-2">
        <button
          type="button"
          aria-label={`Diminuer ${label}`}
          disabled={value <= min}
          onClick={() => onChange(value - 1)}
          className="grid size-11 place-items-center rounded-xl bg-ink text-lg disabled:opacity-40"
        >
          −
        </button>
        <span className="w-12 text-center font-mono text-sm tabular-nums">
          {value}
          {suffix}
        </span>
        <button
          type="button"
          aria-label={`Augmenter ${label}`}
          disabled={value >= max}
          onClick={() => onChange(value + 1)}
          className="grid size-11 place-items-center rounded-xl bg-ink text-lg disabled:opacity-40"
        >
          +
        </button>
      </span>
    </div>
  );
}

function RiskEditor({ current, onClose }: { current: RiskSettings; onClose: () => void }) {
  const [draft, setDraft] = useState(current);
  const [riskError, setRiskError] = useState("");
  const set = (key: keyof RiskSettings, value: number) => setDraft((prev) => ({ ...prev, [key]: value }));
  return (
    <section className="rounded-2xl bg-panel p-4 shadow-card">
      <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Paramètres de risque</h2>
      <p className="mt-1 text-sm text-muted">Choisis le cadre. Moyen et élevé ouvrent plus de lignes et acceptent des signaux plus larges.</p>
      <div className="mt-3 grid grid-cols-3 gap-2">
        {(
          [
            ["faible", "Faible"],
            ["modere", "Moyen"],
            ["eleve", "Élevé"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setDraft(RISK_PRESETS[id])}
            className={`h-11 rounded-xl text-sm ${draft.profile === id ? "bg-brass font-medium text-ink" : "bg-ink text-muted"}`}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="mt-2">
        <Stepper label="Actions en même temps" value={draft.stockSlots} min={1} max={10} onChange={(value) => set("stockSlots", value)} />
        <Stepper label="Cryptos en même temps" value={draft.cryptoSlots} min={0} max={6} onChange={(value) => set("cryptoSlots", value)} />
        <Stepper label="Taille d'une action" value={draft.stockSizePct} min={1} max={15} suffix=" %" onChange={(value) => set("stockSizePct", value)} />
        <Stepper label="Taille d'une crypto" value={draft.cryptoSizePct} min={1} max={15} suffix=" %" onChange={(value) => set("cryptoSizePct", value)} />
        <Stepper label="Plafond investi" value={draft.maxInvestedPct} min={15} max={90} suffix=" %" onChange={(value) => set("maxInvestedPct", value)} />
        <Stepper label="Performance visée" value={draft.targetPct} min={3} max={25} suffix=" %" onChange={(value) => set("targetPct", value)} />
      </div>
      <div className="mt-3 flex gap-2">
        <button
          type="button"
          onClick={() => {
            void usePaperStore.getState().saveRisk(draft).then((ok) => {
              if (ok) onClose();
              else setRiskError("Enregistrement impossible. Réessaie.");
            });
          }}
          className="h-11 rounded-xl bg-brass px-4 text-sm font-medium text-ink"
        >
          Enregistrer
        </button>
        <button type="button" onClick={onClose} className="h-11 px-3 text-sm text-muted">
          Annuler
        </button>
      </div>
      {riskError ? <p className="mt-2 text-sm text-down">{riskError}</p> : null}
    </section>
  );
}

function PositionCurve({ position }: { position: PaperPosition }) {
  const chart = useQuery({
    queryKey: ["bot-since", position.symbol, position.openedAt],
    queryFn: () => getSinceChart({ data: { symbol: position.symbol, since: position.openedAt } }),
  });
  const price = usePaperStore((state) => state.marks[position.symbol] ?? position.entry);
  const age = Date.now() - position.openedAt;
  const span: ChartSpan = age < 36 * 3_600_000 ? "h" : age < 40 * 86_400_000 ? "d" : age < 400 * 86_400_000 ? "m" : "y";
  const points = useMemo(() => {
    const rows = (chart.data?.candles ?? []).map((candle) => ({ t: candle.t * 1000, v: candle.c }));
    if (rows.length === 0 || rows[0]!.t > position.openedAt) rows.unshift({ t: position.openedAt, v: position.entry });
    const last = rows[rows.length - 1];
    if (!last || Date.now() - last.t > 30_000) rows.push({ t: Date.now(), v: price });
    return rows;
  }, [chart.data, position.entry, position.openedAt, price]);

  return (
    <div className="border-t border-line pt-3">
      <p className="text-sm">Depuis l'achat de {position.name}</p>
      <p className="mt-1 text-xs text-muted">
        Entrée {formatPrice(position.entry, "USD")} · cours {formatPrice(price, "USD")}
      </p>
      {chart.isPending ? <p className="mt-3 text-sm text-muted">Chargement de la courbe…</p> : null}
      {chart.isError ? <p className="mt-3 text-sm text-down">Courbe indisponible pour le moment.</p> : null}
      <ValueChart points={points} marker={position.entry} currency="USD" span={span} />
    </div>
  );
}
