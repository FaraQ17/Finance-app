import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowUpRight,
  ChartCandlestick,
  ChartLine,
  RefreshCw,
  Search,
  Star,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { PriceChart } from "@/components/market/price-chart";
import { MarketShell } from "@/components/market/shell";
import {
  formatClock,
  formatPlace,
  formatPrice,
  formatPct,
  formatSignedPrice,
  formatVolume,
  formatWhen,
  toneOf,
} from "@/lib/format";
import { analyzeAsset, getAsset, getChart, getOverview, getQuotes, searchAssets } from "@/lib/market-api";
import {
  DISCLAIMER,
  CRYPTO_ALIASES,
  cleanSymbol,
  type AnalysisOk,
  type ChartMode,
  type Filter,
  type Kind,
  type RangeKey,
  type Snapshot,
  type Term,
} from "@/lib/universe";
import { useWatchlist, type WatchItem } from "@/lib/watchlist";

const RANGES: { id: RangeKey; label: string }[] = [
  { id: "1d", label: "1 j" },
  { id: "7d", label: "7 j" },
  { id: "30d", label: "30 j" },
];

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "Tout" },
  { id: "stock", label: "Actions" },
  { id: "crypto", label: "Crypto" },
];

function toneClass(tone: "up" | "down" | "flat", soft = false): string {
  if (tone === "up") return soft ? "bg-up-soft text-up" : "text-up";
  if (tone === "down") return soft ? "bg-down-soft text-down" : "text-down";
  return soft ? "bg-panel-2 text-muted" : "text-muted";
}

function Sparkline({ values, up }: { values: number[]; up: boolean }) {
  if (values.length < 2) return <span className="h-6 w-16" />;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = max - min || 1;
  const d = values
    .map((value, index) => {
      const x = (index / (values.length - 1)) * 64;
      const y = 22 - ((value - min) / span) * 18;
      return `${index === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg viewBox="0 0 64 24" className={`h-6 w-16 ${up ? "text-up" : "text-down"}`} aria-hidden>
      <path d={d} fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function QuoteRow({
  quote,
  active,
  watched,
  onSelect,
  onToggle,
  layout,
}: {
  quote: Snapshot | (WatchItem & { pending: true });
  active: boolean;
  watched: boolean;
  onSelect: () => void;
  onToggle: () => void;
  layout: "chip" | "row";
}) {
  const pending = "pending" in quote;
  const tone = pending ? "flat" : toneOf(quote.changePercent);
  return (
    <div
      className={`flex items-stretch bg-panel shadow-card ${
        layout === "chip" ? "min-w-44 shrink-0 rounded-xl" : "rounded-xl"
      } ${active ? "ring-1 ring-brass" : ""}`}
    >
      <button
        type="button"
        onClick={onSelect}
        className={`min-w-0 flex-1 text-left ${layout === "chip" ? "px-3 py-2.5" : "px-3 py-3"}`}
      >
        <span className="flex items-center justify-between gap-2">
          <span className="truncate font-mono text-xs text-brass">
            {quote.symbol.replace("-USD", "")}
          </span>
          <span className="text-xs text-muted">{pending ? quote.kind === "crypto" ? "Crypto" : "Action" : quote.badge}</span>
        </span>
        <span className="mt-1 block truncate text-sm">{quote.name}</span>
        {pending ? (
          <span className="mt-1 block text-xs text-muted">Cours…</span>
        ) : (
          <span className="mt-1 flex items-end justify-between gap-2">
            <span className="font-mono text-sm tabular-nums">{formatPrice(quote.price, quote.currency)}</span>
            <span className={`font-mono text-xs tabular-nums ${toneClass(tone)}`}>{formatPct(quote.changePercent)}</span>
          </span>
        )}
        {!pending && layout === "row" ? (
          <span className="mt-2 flex justify-end">
            <Sparkline values={quote.spark} up={tone !== "down"} />
          </span>
        ) : null}
      </button>
      <button
        type="button"
        onClick={onToggle}
        aria-pressed={watched}
        aria-label={watched ? `Retirer ${quote.name} des favoris` : `Ajouter ${quote.name} aux favoris`}
        className="grid w-11 shrink-0 place-items-center"
      >
        <Star className={`size-4 ${watched ? "fill-brass text-brass" : "text-muted"}`} />
      </button>
    </div>
  );
}

function readSession(symbol: string, term: Term): AnalysisOk | null {
  try {
    const raw = sessionStorage.getItem(`vesper-ai:${symbol}:${term}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AnalysisOk & { savedAt?: number };
    if (!parsed.savedAt || Date.now() - parsed.savedAt > 30 * 60_000) return null;
    if (parsed.symbol !== symbol || (parsed.term ?? "court") !== term) return null;
    return parsed;
  } catch {
    return null;
  }
}

function writeSession(analysis: AnalysisOk) {
  const term = analysis.term ?? "court";
  sessionStorage.setItem(
    `vesper-ai:${analysis.symbol}:${term}`,
    JSON.stringify({ ...analysis, term, savedAt: Date.now() }),
  );
}

const TERMS: { id: Term; label: string; hint: string }[] = [
  { id: "court", label: "Court", hint: "prochains jours" },
  { id: "moyen", label: "Moyen", hint: "1 à 3 mois" },
  { id: "long", label: "Long", hint: "6 à 18 mois" },
];

const SENTIMENT_LABEL = { positif: "Positif", neutre: "Neutre", negatif: "Négatif" } as const;
const RISK_LABEL = { faible: "Faible", modere: "Modéré", eleve: "Élevé" } as const;
const KIND_LABEL = { web: "Web", x: "X", marche: "Fil de marché" } as const;

function AnalysisPanel({
  symbol,
  name,
}: {
  symbol: string;
  name: string;
}) {
  const [term, setTerm] = useState<Term>("court");
  const [stored, setStored] = useState<AnalysisOk | null>(null);
  const mutation = useMutation({
    mutationFn: (force: boolean) => analyzeAsset({ data: { symbol, force, term } }),
    onSuccess: (result) => {
      if (result.ok) {
        writeSession(result);
        setStored(result);
      }
    },
  });

  useEffect(() => {
    setStored(readSession(symbol, term));
    mutation.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [symbol, term]);

  const result = mutation.data?.ok ? mutation.data : stored;
  const error = mutation.data && !mutation.data.ok ? mutation.data.error : mutation.error ? "Analyse impossible." : null;
  const score = result?.sentimentScore ?? 0;
  const hint = TERMS.find((item) => item.id === term)?.hint ?? "prochains jours";

  return (
    <section className="rounded-2xl bg-panel p-4 shadow-card sm:p-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Lecture Grok</h2>
          <p className="mt-1 text-sm text-muted">Cours et actualités de {name}, sur l'horizon choisi.</p>
        </div>
        <button
          type="button"
          disabled={mutation.isPending}
          onClick={() => mutation.mutate(Boolean(result))}
          className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-brass px-4 text-sm font-medium text-ink disabled:opacity-60"
        >
          {mutation.isPending ? <RefreshCw className="size-4 animate-spin" /> : <Search className="size-4" />}
          {result ? "Actualiser l'analyse" : "Analyser avec Grok"}
        </button>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-1 rounded-xl bg-ink p-1" role="tablist" aria-label="Horizon">
        {TERMS.map((item) => (
          <button
            key={item.id}
            type="button"
            role="tab"
            aria-selected={term === item.id}
            onClick={() => setTerm(item.id)}
            className={`h-10 rounded-lg text-sm ${term === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`}
          >
            {item.label}
          </button>
        ))}
      </div>
      <p className="mt-2 text-xs text-muted">Horizon : {hint}. Le sentiment et la confiance portent sur les news de cette fenêtre.</p>

      {mutation.isPending ? (
        <p className="mt-4 text-sm text-muted">Lecture du cours, des actualités web et des échanges sur X…</p>
      ) : null}

      {error ? (
        <p className="mt-4 text-sm text-down" role="alert">
          {error}
        </p>
      ) : null}

      {!result && !mutation.isPending && !error ? (
        <p className="mt-4 text-sm text-pretty text-muted">
          L'analyse ne se lance pas toute seule. Elle croise le cours et les news, puis donne le sentiment et la
          confiance sur l'horizon choisi.
        </p>
      ) : null}

      {result ? (
        <div className="mt-4 space-y-4">
          <p className="text-lg text-pretty text-fg">{result.outlook}</p>
          <p className="text-xs text-muted">
            {result.cached ? "Lecture conservée" : "Lecture fraîche"} · {formatClock(result.generatedAt)} · {DISCLAIMER}
          </p>

          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-xl bg-panel-2 p-3">
              <p className="text-xs text-muted">Confiance · {hint}</p>
              <p className="mt-1 font-mono text-2xl tabular-nums text-brass">{result.confidence} %</p>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-ink">
                <div className="h-full bg-brass" style={{ width: `${result.confidence}%` }} />
              </div>
            </div>
            <div className="rounded-xl bg-panel-2 p-3">
              <p className="text-xs text-muted">Sentiment des news</p>
              <p className="mt-1 font-mono text-2xl tabular-nums">
                {score > 0 ? "+" : ""}
                {score}
              </p>
              <p className="text-sm">{SENTIMENT_LABEL[result.sentiment]}</p>
              <div className="relative mt-2 h-1.5 rounded-full bg-ink">
                <div
                  className={`absolute top-0 h-full ${score >= 0 ? "left-1/2 bg-up" : "bg-down"}`}
                  style={
                    score >= 0
                      ? { width: `${score / 2}%` }
                      : { width: `${Math.abs(score) / 2}%`, right: "50%" }
                  }
                />
              </div>
            </div>
            <div className="rounded-xl bg-panel-2 p-3">
              <p className="text-xs text-muted">Niveau de risque</p>
              <p
                className={`mt-1 text-2xl ${
                  result.risk === "eleve" ? "text-down" : result.risk === "faible" ? "text-up" : "text-brass"
                }`}
              >
                {RISK_LABEL[result.risk]}
              </p>
              <p className="text-sm text-pretty text-muted">{result.riskNote}</p>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl bg-up-soft p-3">
              <p className="flex items-center gap-2 text-sm font-medium text-up">
                <TrendingUp className="size-4" />
                Arguments haussiers
              </p>
              <ul className="mt-2 space-y-2 text-sm">
                {result.bullish.length === 0 ? <li className="text-muted">Pas d'argument net.</li> : null}
                {result.bullish.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div className="rounded-xl bg-down-soft p-3">
              <p className="flex items-center gap-2 text-sm font-medium text-down">
                <TrendingDown className="size-4" />
                Arguments baissiers
              </p>
              <ul className="mt-2 space-y-2 text-sm">
                {result.bearish.length === 0 ? <li className="text-muted">Pas d'argument net.</li> : null}
                {result.bearish.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </div>

          {result.summary ? (
            <div>
              <h3 className="text-xs font-medium tracking-widest text-muted uppercase">Résumé</h3>
              <p className="mt-2 text-sm text-pretty">{result.summary}</p>
            </div>
          ) : null}

          <div>
            <h3 className="text-xs font-medium tracking-widest text-muted uppercase">Sources utilisées</h3>
            <ul className="mt-2 divide-y divide-line">
              {result.sources.length === 0 ? <li className="py-2 text-sm text-muted">Aucune source citée.</li> : null}
              {result.sources.map((source) => (
                <li key={source.url} className="py-2">
                  <a
                    href={source.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="group flex items-start justify-between gap-3"
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm group-hover:text-brass">{source.title}</span>
                      <span className="text-xs text-muted">
                        {source.publisher} · {KIND_LABEL[source.kind]}
                      </span>
                    </span>
                    <ArrowUpRight className="mt-0.5 size-4 shrink-0 text-muted" />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      ) : null}
    </section>
  );
}

export function Desk({
  symbol,
  filter,
  onSymbol,
  onFilter,
}: {
  symbol: string;
  filter: Filter;
  onSymbol: (symbol: string) => void;
  onFilter: (filter: Filter) => void;
}) {
  const [mounted, setMounted] = useState(false);
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [range, setRange] = useState<RangeKey>("1d");
  const [mode, setMode] = useState<ChartMode>("line");
  const firstSymbol = useRef(true);
  const items = useWatchlist((state) => state.items);
  const toggle = useWatchlist((state) => state.toggle);
  const watchSet = useMemo(() => new Set(items.map((item) => item.symbol)), [items]);

  useEffect(() => {
    setMounted(true);
    void useWatchlist.persist.rehydrate();
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(query.trim()), 280);
    return () => window.clearTimeout(timer);
  }, [query]);

  useEffect(() => {
    if (firstSymbol.current) {
      firstSymbol.current = false;
      return;
    }
    if (window.innerWidth >= 1024) return;
    document.getElementById("actif")?.scrollIntoView({ block: "start" });
  }, [symbol]);

  const overview = useQuery({
    queryKey: ["overview"],
    enabled: mounted,
    queryFn: () => getOverview(),
    refetchInterval: 15_000,
    refetchIntervalInBackground: true,
  });

  const known = new Set((overview.data?.quotes ?? []).map((quote) => quote.symbol));
  const missing = items.map((item) => item.symbol).filter((item) => overview.isSuccess && !known.has(item));
  const extras = useQuery({
    queryKey: ["quotes", missing],
    enabled: mounted && missing.length > 0,
    queryFn: () => getQuotes({ data: { symbols: missing } }),
  });

  const quoteMap = useMemo(() => {
    const map = new Map<string, Snapshot>();
    for (const quote of overview.data?.quotes ?? []) map.set(quote.symbol, quote);
    for (const quote of extras.data?.quotes ?? []) map.set(quote.symbol, quote);
    return map;
  }, [overview.data, extras.data]);

  const asset = useQuery({
    queryKey: ["asset", symbol],
    enabled: mounted,
    queryFn: () => getAsset({ data: { symbol } }),
    refetchInterval: 15_000,
    refetchIntervalInBackground: true,
  });

  const chart = useQuery({
    queryKey: ["chart", symbol, range],
    enabled: mounted,
    queryFn: () => getChart({ data: { symbol, range } }),
  });

  const search = useQuery({
    queryKey: ["search", debounced],
    enabled: mounted && debounced.length > 0,
    queryFn: () => searchAssets({ data: { q: debounced } }),
  });

  const visibleWatch = items.filter((item) => filter === "all" || item.kind === filter);
  const rest = (overview.data?.quotes ?? []).filter(
    (quote) => (filter === "all" || quote.kind === filter) && !watchSet.has(quote.symbol),
  );

  function selectSymbol(next: string) {
    onSymbol(next);
    setSearchOpen(false);
    setQuery("");
  }

  function submitSearch() {
    const alias = CRYPTO_ALIASES[query.trim().toUpperCase()];
    if (alias) {
      selectSymbol(alias.symbol);
      return;
    }
    const first = search.data?.results[0];
    if (first) {
      selectSymbol(first.symbol);
      return;
    }
    const direct = cleanSymbol(query);
    if (direct) selectSymbol(direct);
  }

  function watchFrom(item: WatchItem) {
    toggle(item);
  }

  const detail = asset.data;
  const tone = detail ? toneOf(detail.changePercent) : "flat";

  const renderList = (layout: "chip" | "row") => (
    <div className={layout === "chip" ? "flex gap-2 overflow-x-auto pb-1" : "space-y-2"}>
      {visibleWatch.length > 0 && layout === "row" ? (
        <p className="px-1 text-xs font-medium tracking-widest text-muted uppercase">Favoris</p>
      ) : null}
      {visibleWatch.map((item) => {
        const quote = quoteMap.get(item.symbol);
        return (
          <QuoteRow
            key={item.symbol}
            layout={layout}
            active={item.symbol === symbol}
            watched
            quote={quote ?? { ...item, pending: true }}
            onSelect={() => selectSymbol(item.symbol)}
            onToggle={() => watchFrom({ symbol: item.symbol, name: item.name, kind: item.kind })}
          />
        );
      })}
      {rest.length > 0 && layout === "row" ? (
        <p className="px-1 pt-3 text-xs font-medium tracking-widest text-muted uppercase">Univers</p>
      ) : null}
      {rest.map((quote) => (
        <QuoteRow
          key={quote.symbol}
          layout={layout}
          active={quote.symbol === symbol}
          watched={false}
          quote={quote}
          onSelect={() => selectSymbol(quote.symbol)}
          onToggle={() =>
            watchFrom({ symbol: quote.symbol, name: quote.name, kind: quote.kind as Kind })
          }
        />
      ))}
    </div>
  );

  return (
    <MarketShell>
      <main className="mx-auto grid max-w-6xl gap-5 px-4 py-4 pb-24 lg:grid-cols-[320px_minmax(0,1fr)] lg:px-6">
        <div className="min-w-0 space-y-4 lg:sticky lg:top-28 lg:max-h-[calc(100vh-8rem)] lg:overflow-y-auto">
          <div className="relative">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
            <input
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setSearchOpen(true);
              }}
              onFocus={() => setSearchOpen(true)}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  event.preventDefault();
                  submitSearch();
                }
                if (event.key === "Escape") setSearchOpen(false);
              }}
              placeholder="Ticker — AAPL, MC.PA, BTC, ETH"
              aria-label="Rechercher un actif"
              className="h-11 w-full rounded-xl bg-panel pr-3 pl-10 text-base text-fg shadow-card outline-none placeholder:text-muted focus:ring-1 focus:ring-brass lg:text-sm"
            />
            {searchOpen && debounced.length > 0 ? (
              <div className="absolute z-30 mt-2 w-full overflow-hidden rounded-xl bg-panel shadow-card">
                {search.isFetching ? <p className="px-3 py-3 text-sm text-muted">Recherche…</p> : null}
                {!search.isFetching && (search.data?.results.length ?? 0) === 0 ? (
                  <p className="px-3 py-3 text-sm text-muted">Aucun actif pour cette recherche.</p>
                ) : null}
                <ul>
                  {search.data?.results.map((hit) => (
                    <li key={hit.symbol} className="flex items-center">
                      <button
                        type="button"
                        onMouseDown={(event) => event.preventDefault()}
                        onClick={() => selectSymbol(hit.symbol)}
                        className="flex min-w-0 flex-1 items-center justify-between gap-3 px-3 py-3 text-left hover:bg-panel-2"
                      >
                        <span className="min-w-0">
                          <span className="block truncate text-sm">{hit.name}</span>
                          <span className="font-mono text-xs text-muted">{hit.symbol}</span>
                        </span>
                        <span className="shrink-0 text-xs text-brass">{hit.badge}</span>
                      </button>
                      <button
                        type="button"
                        onMouseDown={(event) => event.preventDefault()}
                        onClick={() =>
                          watchFrom({ symbol: hit.symbol, name: hit.name, kind: hit.kind })
                        }
                        aria-pressed={watchSet.has(hit.symbol)}
                        aria-label={
                          watchSet.has(hit.symbol)
                            ? `Retirer ${hit.name} des favoris`
                            : `Ajouter ${hit.name} aux favoris`
                        }
                        className="grid size-11 shrink-0 place-items-center"
                      >
                        <Star
                          className={`size-4 ${watchSet.has(hit.symbol) ? "fill-brass text-brass" : "text-muted"}`}
                        />
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>

          <div className="grid grid-cols-3 gap-1 rounded-xl bg-panel p-1 shadow-card" role="tablist" aria-label="Univers">
            {FILTERS.map((item) => (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={filter === item.id}
                onClick={() => onFilter(item.id)}
                className={`h-10 rounded-lg text-sm ${
                  filter === item.id ? "bg-brass font-medium text-ink" : "text-muted"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="lg:hidden">
            {overview.isPending ? <p className="text-sm text-muted">Chargement des cours…</p> : null}
            {overview.isError ? (
              <button type="button" onClick={() => overview.refetch()} className="text-sm text-brass">
                Réessayer le chargement des cours
              </button>
            ) : null}
            {renderList("chip")}
          </div>

          <div className="hidden lg:block">
            {overview.isPending ? <p className="text-sm text-muted">Chargement des cours…</p> : null}
            {overview.isError ? (
              <button type="button" onClick={() => overview.refetch()} className="text-sm text-brass">
                Réessayer le chargement des cours
              </button>
            ) : null}
            {renderList("row")}
            {!overview.isPending && visibleWatch.length === 0 && rest.length === 0 ? (
              <p className="text-sm text-muted">Aucun actif dans cette catégorie.</p>
            ) : null}
          </div>
        </div>

        <div id="actif" className="min-w-0 scroll-mt-28 space-y-4">
          {asset.isPending ? (
            <section className="rounded-2xl bg-panel p-5 shadow-card">
              <p className="text-sm text-muted">Chargement du cours…</p>
            </section>
          ) : null}
          {asset.isError ? (
            <section className="rounded-2xl bg-panel p-5 shadow-card">
              <p className="text-sm text-down">Impossible de charger {symbol}.</p>
              <button type="button" onClick={() => asset.refetch()} className="mt-3 h-11 text-sm text-brass">
                Réessayer
              </button>
            </section>
          ) : null}

          {detail ? (
            <section className="rounded-2xl bg-panel p-4 shadow-card sm:p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-xs tracking-widest text-brass uppercase">
                    {detail.badge} · {formatPlace(detail.exchange, detail.kind)}
                  </p>
                  <h1 className="mt-1 truncate text-2xl font-medium">{detail.name}</h1>
                  <p className="font-mono text-xs text-muted">{detail.symbol}</p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    watchFrom({ symbol: detail.symbol, name: detail.name, kind: detail.kind })
                  }
                  aria-pressed={watchSet.has(detail.symbol)}
                  aria-label={
                    watchSet.has(detail.symbol)
                      ? `Retirer ${detail.name} des favoris`
                      : `Ajouter ${detail.name} aux favoris`
                  }
                  className="grid size-11 shrink-0 place-items-center rounded-xl bg-panel-2"
                >
                  <Star
                    className={`size-4 ${watchSet.has(detail.symbol) ? "fill-brass text-brass" : "text-muted"}`}
                  />
                </button>
              </div>

              <div className="mt-4 flex flex-wrap items-end gap-3">
                <p className="font-mono text-4xl tabular-nums tracking-tight">
                  {formatPrice(detail.price, detail.currency)}
                </p>
                <p className={`inline-flex items-center gap-2 rounded-full px-3 py-1 font-mono text-sm tabular-nums ${toneClass(tone, true)}`}>
                  {tone === "up" ? <TrendingUp className="size-4" /> : tone === "down" ? <TrendingDown className="size-4" /> : null}
                  {formatSignedPrice(detail.changeAbs, detail.currency)}
                  <span>{formatPct(detail.changePercent)}</span>
                </p>
              </div>

              <dl className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div>
                  <dt className="text-xs text-muted">Plus haut</dt>
                  <dd className="font-mono text-sm tabular-nums">
                    {detail.dayHigh != null ? formatPrice(detail.dayHigh, detail.currency) : "—"}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-muted">Plus bas</dt>
                  <dd className="font-mono text-sm tabular-nums">
                    {detail.dayLow != null ? formatPrice(detail.dayLow, detail.currency) : "—"}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-muted">Volume</dt>
                  <dd className="font-mono text-sm tabular-nums">
                    {detail.volume != null ? formatVolume(detail.volume) : "—"}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-muted">Clôture préc.</dt>
                  <dd className="font-mono text-sm tabular-nums">
                    {detail.previousClose != null ? formatPrice(detail.previousClose, detail.currency) : "—"}
                  </dd>
                </div>
              </dl>
              {detail.week52High != null && detail.week52Low != null ? (
                <p className="mt-3 text-xs text-muted">
                  52 sem. {formatPrice(detail.week52Low, detail.currency)} – {formatPrice(detail.week52High, detail.currency)}
                </p>
              ) : null}

              <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
                <div className="flex gap-1 rounded-lg bg-panel-2 p-1">
                  {RANGES.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setRange(item.id)}
                      className={`h-9 rounded-md px-3 text-sm ${range === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
                <div className="flex gap-1 rounded-lg bg-panel-2 p-1">
                  <button
                    type="button"
                    aria-pressed={mode === "line"}
                    onClick={() => setMode("line")}
                    className={`inline-flex h-9 items-center gap-1 rounded-md px-2.5 text-sm ${mode === "line" ? "bg-brass font-medium text-ink" : "text-muted"}`}
                  >
                    <ChartLine className="size-4" />
                    Ligne
                  </button>
                  <button
                    type="button"
                    aria-pressed={mode === "candle"}
                    onClick={() => setMode("candle")}
                    className={`inline-flex h-9 items-center gap-1 rounded-md px-2.5 text-sm ${mode === "candle" ? "bg-brass font-medium text-ink" : "text-muted"}`}
                  >
                    <ChartCandlestick className="size-4" />
                    Bougies
                  </button>
                </div>
              </div>
              <p className="mt-2 text-xs text-muted">Heures de Paris · source cours Yahoo Finance</p>
              {chart.isLoading ? <p className="mt-6 text-sm text-muted">Chargement du graphique…</p> : null}
              {chart.isError ? (
                <button type="button" onClick={() => chart.refetch()} className="mt-4 text-sm text-brass">
                  Réessayer le graphique
                </button>
              ) : null}
              {chart.data ? (
                <PriceChart candles={chart.data.candles} mode={mode} range={range} currency={detail.currency} />
              ) : null}
            </section>
          ) : null}

          {detail ? (
            <section className="rounded-2xl bg-panel p-4 shadow-card sm:p-5">
              <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Actualités</h2>
            {detail && detail.news.length === 0 ? (
              <p className="mt-3 text-sm text-muted">Aucune actualité récente trouvée pour cet actif.</p>
            ) : null}
            <ul className="mt-2 divide-y divide-line">
              {detail?.news.map((item) => (
                <li key={item.id} className="py-3">
                  <a href={item.url} target="_blank" rel="noreferrer noopener" className="group block">
                    <span className="flex items-start justify-between gap-3">
                      <span className="text-sm text-pretty group-hover:text-brass">{item.title}</span>
                      <ArrowUpRight className="mt-0.5 size-4 shrink-0 text-muted" />
                    </span>
                    <span className="mt-1 block text-xs text-muted">
                      {item.publisher} · {formatWhen(item.publishedAt)}
                    </span>
                  </a>
                </li>
              ))}
            </ul>
            </section>
          ) : null}

          <AnalysisPanel key={symbol} symbol={symbol} name={detail?.name ?? symbol} />
        </div>
      </main>
    </MarketShell>
  );
}
