import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Kind } from "@/lib/universe";

export type WatchItem = {
  symbol: string;
  name: string;
  kind: Kind;
};

type WatchState = {
  items: WatchItem[];
  has: (symbol: string) => boolean;
  toggle: (item: WatchItem) => void;
};

const DEFAULTS: WatchItem[] = [
  { symbol: "NVDA", name: "NVIDIA", kind: "stock" },
  { symbol: "AAPL", name: "Apple", kind: "stock" },
  { symbol: "MC.PA", name: "LVMH", kind: "stock" },
  { symbol: "BTC-USD", name: "Bitcoin", kind: "crypto" },
];

export const useWatchlist = create<WatchState>()(
  persist(
    (set, get) => ({
      items: DEFAULTS,
      has: (symbol) => get().items.some((item) => item.symbol === symbol),
      toggle: (item) => {
        const exists = get().items.some((entry) => entry.symbol === item.symbol);
        set({
          items: exists
            ? get().items.filter((entry) => entry.symbol !== item.symbol)
            : [item, ...get().items].slice(0, 30),
        });
      },
    }),
    {
      name: "vesper-watchlist",
      skipHydration: true,
      partialize: (state) => ({ items: state.items }),
    },
  ),
);
