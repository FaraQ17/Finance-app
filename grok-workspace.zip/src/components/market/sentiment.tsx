import { useMutation } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RefreshCw, Star } from "lucide-react";
import { MarketShell } from "@/components/market/shell";
import { formatPct, toneOf } from "@/lib/format";
import { rankSentiment } from "@/lib/market-api";
import type { SentimentRow, Term } from "@/lib/universe";
import { useWatchlist } from "@/lib/watchlist";

const TERMS: { id: Term; label: string; hint: string }[] = [
  { id: "court", label: "Court", hint: "prochains jours" },
  { id: "moyen", label: "Moyen", hint: "1 à 3 mois" },
  { id: "long", label: "Long", hint: "6 à 18 mois" },
];

const SCOPES = [
  { id: "mix" as const, label: "Mixte" },
  { id: "stock" as const, label: "Actions" },
  { id: "crypto" as const, label: "Crypto" },
  { id: "favoris" as const, label: "Favoris" },
];

function toneClass(change: number): string {
  const tone = toneOf(change);
  if (tone === "up") return "text-up";
  if (tone === "down") return "text-down";
  return "text-muted";
}

function scoreClass(score: number): string {
  if (score >= 15) return "text-up";
  if (score <= -15) return "text-down";
  return "text-muted";
}

export function SentimentBoard() {
  const [mounted, setMounted] = useState(false);
  const [term, setTerm] = useState<Term>("court");
  const [scope, setScope] = useState<(typeof SCOPES)[number]["id"]>("mix");
  const favorites = useWatchlist((state) => state.items);
  const toggle = useWatchlist((state) => state.toggle);

  useEffect(() => {
    setMounted(true);
    void useWatchlist.persist.rehydrate();
  }, []);

  const rank = useMutation({
    mutationFn: (force: boolean) =>
      rankSentiment({
        data: {
          term,
          scope,
          force,
          favorites: favorites.map((item) => ({ symbol: item.symbol, name: item.name, kind: item.kind })),
        },
      }),
  });

  useEffect(() => {
    rank.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [term, scope]);

  const board = rank.data && "ok" in rank.data && rank.data.ok ? rank.data.board : null;
  const error = rank.data && "ok" in rank.data && !rank.data.ok ? rank.data.error : null;
  const hint = TERMS.find((item) => item.id === term)?.hint ?? "prochains jours";
  const watchSet = new Set(mounted ? favorites.map((item) => item.symbol) : []);

  return (
    <MarketShell>
      <main className="mx-auto max-w-3xl space-y-4 px-4 py-4 pb-24 lg:px-6">
        <div>
          <h1 className="text-2xl font-medium">Sentiment des news</h1>
          <p className="mt-1 text-sm text-pretty text-muted">
            Les 20 lectures les plus haussières et les mieux étayées. Le rang croise le sentiment des news et la
            confiance, sur {hint}.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-1 rounded-xl bg-panel p-1 shadow-card" role="tablist" aria-label="Horizon">
          {TERMS.map((item) => (
            <button
              key={item.id}
              type="button"
              role="tab"
              aria-selected={term === item.id}
              onClick={() => setTerm(item.id)}
              className={`h-10 rounded-lg text-sm ${term === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`}
            >
              {item.label}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-4 gap-1 rounded-xl bg-panel p-1 shadow-card" role="tablist" aria-label="Univers">
          {SCOPES.map((item) => (
            <button
              key={item.id}
              type="button"
              role="tab"
              aria-selected={scope === item.id}
              onClick={() => setScope(item.id)}
              className={`h-10 rounded-lg text-sm ${scope === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <button
          type="button"
          disabled={rank.isPending || (scope === "favoris" && favorites.length === 0)}
          onClick={() => rank.mutate(Boolean(board))}
          className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-brass px-4 text-sm font-medium text-ink disabled:opacity-60"
        >
          {rank.isPending ? <RefreshCw className="size-4 animate-spin" /> : null}
          {board ? "Actualiser le classement" : "Classer le sentiment"}
        </button>
        <p className="text-xs text-pretty text-muted">
          Rien ne part tout seul. Grok lit le cours du jour et un titre d'actualité par valeur, puis note le sentiment
          et la confiance. Ce n'est pas un conseil.
        </p>
        {scope === "favoris" && mounted && favorites.length === 0 ? (
          <p className="text-sm text-muted">Ajoutez des favoris pour classer seulement vos titres.</p>
        ) : null}
        {rank.isPending ? <p className="text-sm text-muted">Lecture des cours et des titres…</p> : null}
        {error ? (
          <p className="text-sm text-down" role="alert">
            {error}
          </p>
        ) : null}

        {board ? (
          <>
            <p className="text-xs text-muted">
              {board.rows.length} retenus sur {board.scanned} lus
              {rank.data && "cached" in rank.data && rank.data.cached ? " · lecture conservée" : ""}
            </p>
            <ol className="overflow-hidden rounded-2xl bg-panel shadow-card">
              {board.rows.map((row, index) => (
                <SentimentItem
                  key={row.symbol}
                  row={row}
                  index={index}
                  watched={watchSet.has(row.symbol)}
                  onToggle={() => toggle({ symbol: row.symbol, name: row.name, kind: row.kind })}
                />
              ))}
            </ol>
          </>
        ) : null}
      </main>
    </MarketShell>
  );
}

function SentimentItem({
  row,
  index,
  watched,
  onToggle,
}: {
  row: SentimentRow;
  index: number;
  watched: boolean;
  onToggle: () => void;
}) {
  return (
    <li className="flex items-start border-b border-line last:border-b-0">
      <div className="min-w-0 flex-1 px-4 py-3">
        <div className="flex items-baseline justify-between gap-3">
          <Link to="/" search={{ s: row.symbol }} className="min-w-0 truncate text-sm">
            <span className="mr-2 font-mono text-xs text-muted">{index + 1}</span>
            {row.name}
          </Link>
          <span className={`shrink-0 font-mono text-sm tabular-nums ${scoreClass(row.sentimentScore)}`}>
            {row.sentimentScore > 0 ? "+" : ""}
            {row.sentimentScore}
          </span>
        </div>
        <p className="mt-1 font-mono text-xs text-muted">
          {row.symbol.replace("-USD", "")} · confiance {row.confidence} % · jour {formatPct(row.changePercent)}
        </p>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-ink">
          <div className="h-full bg-brass" style={{ width: `${row.confidence}%` }} />
        </div>
        {row.note ? <p className="mt-2 text-sm text-pretty">{row.note}</p> : null}
        {row.headline ? <p className="mt-1 text-xs text-pretty text-muted">{row.headline}</p> : null}
        <p className={`mt-1 text-xs ${toneClass(row.changePercent)}`}>
          {row.kind === "crypto" ? "Crypto" : "Action"}
        </p>
      </div>
      <button
        type="button"
        onClick={onToggle}
        aria-pressed={watched}
        aria-label={watched ? `Retirer ${row.name} des favoris` : `Ajouter ${row.name} aux favoris`}
        className="mt-2 grid size-11 shrink-0 place-items-center"
      >
        <Star className={`size-4 ${watched ? "fill-brass text-brass" : "text-muted"}`} />
      </button>
    </li>
  );
}
