import { createServerFn } from "@tanstack/react-start";
import {
  BOARD_CRYPTOS,
  BOARD_STOCKS,
  BOT_UNIVERSE,
  CRYPTO_ALIASES,
  UNIVERSE,
  cleanSymbol,
  universeBySymbol,
  marketOf,
  type AnalysisOk,
  type AnalysisResult,
  type AssetDetail,
  type BotQuote,
  type Candle,
  type Horizon,
  type Kind,
  type NewsItem,
  type RangeKey,
  type SearchHit,
  type Snapshot,
  type SourceKind,
  type SourceRef,
  type Term,
  type TrendBoard,
  type TrendRead,
  type TrendRow,
  type SentimentBoard,
  type SentimentRow,
} from "@/lib/universe";

const UA = "Mozilla/5.0 (compatible; VesperDesk/1.0; +https://grok.com)";

type CacheEntry = { exp: number; value: unknown };
const memory = new Map<string, CacheEntry>();
const inflight = new Map<string, Promise<AnalysisResult>>();
const trendInflight = new Map<string, Promise<TrendRead>>();
const sentimentInflight = new Map<
  string,
  Promise<{ ok: true; board: SentimentBoard; cached: boolean } | { ok: false; error: string }>
>();

let aiWindowStart = Date.now();
let aiCalls = 0;

function remember<T>(key: string, ttlMs: number, value: T): T {
  memory.set(key, { exp: Date.now() + ttlMs, value });
  return value;
}

function recall<T>(key: string): T | null {
  const hit = memory.get(key);
  if (!hit) return null;
  if (hit.exp < Date.now()) {
    memory.delete(key);
    return null;
  }
  return hit.value as T;
}

async function yahooJson(url: string): Promise<unknown> {
  const response = await fetch(url, {
    headers: { Accept: "application/json", "User-Agent": UA },
    signal: AbortSignal.timeout(12_000),
  });
  if (!response.ok) throw new Error("Cours momentanément indisponible");
  return response.json();
}

function num(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function str(value: unknown): string {
  return typeof value === "string" ? value : "";
}

type ParsedChart = {
  name: string;
  currency: string;
  exchange: string;
  instrument: string;
  price: number;
  previousClose: number | null;
  dayHigh: number | null;
  dayLow: number | null;
  volume: number | null;
  week52High: number | null;
  week52Low: number | null;
  candles: Candle[];
};

function parseChart(payload: unknown): ParsedChart {
  const root = payload as {
    chart?: {
      result?: Array<{
        meta?: Record<string, unknown>;
        timestamp?: number[];
        indicators?: { quote?: Array<Record<string, Array<number | null>>> };
      }> | null;
    };
  };
  const result = root.chart?.result?.[0];
  const meta = result?.meta;
  if (!result || !meta) throw new Error("Ticker introuvable");
  const price = num(meta.regularMarketPrice);
  if (price == null) throw new Error("Cours indisponible pour ce ticker");
  const previous = num(meta.chartPreviousClose) ?? num(meta.previousClose);
  const quote = result.indicators?.quote?.[0] ?? {};
  const timestamps = result.timestamp ?? [];
  const candles: Candle[] = [];
  for (let i = 0; i < timestamps.length; i += 1) {
    const t = timestamps[i];
    const o = quote.open?.[i];
    const h = quote.high?.[i];
    const l = quote.low?.[i];
    const c = quote.close?.[i];
    const v = quote.volume?.[i];
    if (t == null || o == null || h == null || l == null || c == null) continue;
    if (![o, h, l, c].every((n) => typeof n === "number" && Number.isFinite(n))) continue;
    candles.push({
      t,
      o,
      h,
      l,
      c,
      v: typeof v === "number" && Number.isFinite(v) ? v : 0,
    });
  }
  return {
    name: str(meta.longName) || str(meta.shortName) || str(meta.symbol),
    currency: str(meta.currency) || "USD",
    exchange: str(meta.fullExchangeName) || str(meta.exchangeName),
    instrument: str(meta.instrumentType),
    price,
    previousClose: previous,
    dayHigh: num(meta.regularMarketDayHigh),
    dayLow: num(meta.regularMarketDayLow),
    volume: num(meta.regularMarketVolume),
    week52High: num(meta.fiftyTwoWeekHigh),
    week52Low: num(meta.fiftyTwoWeekLow),
    candles,
  };
}

function kindOf(instrument: string): Kind {
  return instrument === "CRYPTOCURRENCY" ? "crypto" : "stock";
}

function badgeOf(instrument: string, kind: Kind): string {
  if (kind === "crypto") return "Crypto";
  if (instrument === "ETF") return "ETF";
  return "Action";
}

function changeFrom(price: number, previous: number | null, fallbackPct: number | null): {
  changeAbs: number;
  changePercent: number;
} {
  if (previous != null && previous !== 0) {
    const changeAbs = price - previous;
    return { changeAbs, changePercent: (changeAbs / previous) * 100 };
  }
  return { changeAbs: 0, changePercent: fallbackPct ?? 0 };
}

function sparkOf(candles: Candle[]): number[] {
  const closes = candles.map((candle) => candle.c);
  if (closes.length <= 24) return closes;
  const out: number[] = [];
  for (let i = 0; i < 24; i += 1) {
    out.push(closes[Math.round((i * (closes.length - 1)) / 23)] ?? closes[closes.length - 1] ?? 0);
  }
  return out;
}

async function loadChart(symbol: string, query: string): Promise<ParsedChart> {
  const key = `chart:${symbol}:${query}`;
  const cached = recall<ParsedChart>(key);
  if (cached) return cached;
  const payload = await yahooJson(
    `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?${query}`,
  );
  return remember(key, 12_000, parseChart(payload));
}

function snapshotFrom(symbol: string, preferredName: string | undefined, chart: ParsedChart): Snapshot {
  const kind = kindOf(chart.instrument);
  const { changeAbs, changePercent } = changeFrom(chart.price, chart.previousClose, null);
  return {
    symbol,
    name: preferredName || chart.name || symbol,
    kind,
    badge: badgeOf(chart.instrument, kind),
    currency: chart.currency,
    exchange: chart.exchange,
    price: chart.price,
    changePercent,
    changeAbs,
    spark: sparkOf(chart.candles),
  };
}

function rangeQuery(range: RangeKey): string {
  if (range === "1d") return "interval=5m&range=1d&includePrePost=false";
  const now = Math.floor(Date.now() / 1000 / 300) * 300;
  if (range === "7d") return `period1=${now - 7 * 86_400}&period2=${now}&interval=1h`;
  return `period1=${now - 30 * 86_400}&period2=${now}&interval=1d`;
}

async function mapPool<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let index = 0;
  async function worker() {
    while (index < items.length) {
      const current = index;
      index += 1;
      out[current] = await fn(items[current] as T);
    }
  }
  const workers = Math.min(limit, items.length);
  await Promise.all(Array.from({ length: workers }, () => worker()));
  return out;
}

function safeHttp(url: string): string | null {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return null;
    return parsed.toString();
  } catch {
    return null;
  }
}

function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

async function loadNews(query: string, symbol: string): Promise<NewsItem[]> {
  const key = `news:${symbol}:${query}`;
  const cached = recall<NewsItem[]>(key);
  if (cached) return cached;
  const payload = (await yahooJson(
    `https://query2.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(query)}&quotesCount=0&newsCount=12`,
  )) as { news?: Array<Record<string, unknown>> };
  const base = symbol.replace(/-USD$/i, "");
  const mapped: NewsItem[] = [];
  const related: NewsItem[] = [];
  for (const item of payload.news ?? []) {
    const url = safeHttp(str(item.link));
    const title = str(item.title).trim();
    if (!url || !title) continue;
    const tickers = Array.isArray(item.relatedTickers) ? item.relatedTickers.map((ticker) => String(ticker)) : [];
    const entry: NewsItem = {
      id: str(item.uuid) || url,
      title: title.slice(0, 180),
      publisher: str(item.publisher) || hostOf(url),
      url,
      publishedAt: num(item.providerPublishTime) ?? 0,
    };
    mapped.push(entry);
    const hits = tickers.some((ticker) => ticker === symbol || ticker.replace(/-USD$/i, "") === base);
    if (tickers.length === 0 || hits) related.push(entry);
  }
  const news = (related.length >= 3 ? related : mapped).slice(0, 6);
  return remember(key, 120_000, news);
}

export const getOverview = createServerFn({ method: "GET" }).handler(async () => {
  const cached = recall<Snapshot[]>("overview");
  if (cached) return { quotes: cached };
  const rows = await mapPool(UNIVERSE, 6, async (item) => {
    try {
      const chart = await loadChart(item.symbol, "interval=15m&range=1d&includePrePost=false");
      return snapshotFrom(item.symbol, item.name, chart);
    } catch {
      return null;
    }
  });
  const quotes = rows.filter((row): row is Snapshot => row !== null);
  if (quotes.length === 0) throw new Error("Les cours sont momentanément indisponibles");
  return { quotes: remember("overview", 15_000, quotes) };
});

export const getQuotes = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const raw = (input as { symbols?: unknown }).symbols;
    const symbols = Array.isArray(raw)
      ? [...new Set(raw.map((item) => cleanSymbol(String(item))).filter((item): item is string => !!item))].slice(
          0,
          30,
        )
      : [];
    return { symbols };
  })
  .handler(async ({ data }) => {
    const rows = await mapPool(data.symbols, 4, async (symbol) => {
      try {
        const known = universeBySymbol(symbol);
        const chart = await loadChart(symbol, "interval=15m&range=1d&includePrePost=false");
        return snapshotFrom(symbol, known?.name, chart);
      } catch {
        return null;
      }
    });
    return { quotes: rows.filter((row): row is Snapshot => row !== null) };
  });

export const getLiveMarks = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const raw = (input as { symbols?: unknown }).symbols;
    const symbols = Array.isArray(raw)
      ? [...new Set(raw.map((item) => cleanSymbol(String(item))).filter((item): item is string => !!item))].slice(0, 24)
      : [];
    return { symbols };
  })
  .handler(async ({ data }) => {
    const rows = await mapPool(data.symbols, 4, async (symbol) => {
      try {
        const chart = await loadChart(symbol, "interval=1m&range=1d&includePrePost=true");
        const fx = await usdMultiplier(chart.currency || "USD");
        if (fx == null || !(chart.price > 0)) return null;
        return { symbol, price: chart.price * fx };
      } catch {
        return null;
      }
    });
    return { marks: rows.filter((row): row is { symbol: string; price: number } => row !== null) };
  });

async function loadAsset(symbol: string): Promise<AssetDetail> {
  const known = universeBySymbol(symbol);
  const chart = await loadChart(symbol, "interval=15m&range=1d&includePrePost=false");
  const kind = kindOf(chart.instrument);
  const { changeAbs, changePercent } = changeFrom(chart.price, chart.previousClose, null);
  const newsQuery = kind === "crypto" ? (known?.name ?? chart.name).replace(/ USD$/i, "") : symbol;
  let news: NewsItem[] = [];
  try {
    news = await loadNews(newsQuery, symbol);
  } catch {
    news = [];
  }
  return {
    symbol,
    name: known?.name || chart.name || symbol,
    kind,
    badge: badgeOf(chart.instrument, kind),
    currency: chart.currency,
    exchange: chart.exchange,
    price: chart.price,
    changePercent,
    changeAbs,
    dayHigh: chart.dayHigh,
    dayLow: chart.dayLow,
    volume: chart.volume,
    previousClose: chart.previousClose,
    week52High: chart.week52High,
    week52Low: chart.week52Low,
    news,
  };
}

export const getAsset = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const symbol = cleanSymbol(str((input as { symbol?: unknown }).symbol));
    if (!symbol) throw new Error("Ticker invalide");
    return { symbol };
  })
  .handler(async ({ data }) => loadAsset(data.symbol));

export const getChart = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const symbol = cleanSymbol(str((input as { symbol?: unknown }).symbol));
    const rangeRaw = str((input as { range?: unknown }).range);
    const range: RangeKey = rangeRaw === "7d" || rangeRaw === "30d" ? rangeRaw : "1d";
    if (!symbol) throw new Error("Ticker invalide");
    return { symbol, range };
  })
  .handler(async ({ data }) => {
    const chart = await loadChart(data.symbol, rangeQuery(data.range));
    return { symbol: data.symbol, range: data.range, candles: chart.candles };
  });

export const getOrderChart = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const symbol = cleanSymbol(str((input as { symbol?: unknown }).symbol));
    const spanRaw = str((input as { span?: unknown }).span);
    const span = spanRaw === "min" || spanRaw === "d" || spanRaw === "m" ? spanRaw : "h";
    if (!symbol) throw new Error("Ticker invalide");
    return { symbol, span };
  })
  .handler(async ({ data }) => {
    const now = Math.floor(Date.now() / 1000 / 60) * 60;
    const query =
      data.span === "min"
        ? `period1=${now - 24 * 3600}&period2=${now}&interval=1m&includePrePost=false`
        : data.span === "h"
          ? `period1=${now - 5 * 86_400}&period2=${now}&interval=1h&includePrePost=false`
          : data.span === "d"
            ? `period1=${now - 180 * 86_400}&period2=${now}&interval=1d`
            : `period1=${now - 5 * 365 * 86_400}&period2=${now}&interval=1wk`;
    const chart = await loadChart(data.symbol, query);
    return { symbol: data.symbol, span: data.span, currency: chart.currency, candles: chart.candles };
  });

export const getSinceChart = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const symbol = cleanSymbol(str((input as { symbol?: unknown }).symbol));
    const since = Number((input as { since?: unknown }).since);
    if (!symbol) throw new Error("Ticker invalide");
    if (!Number.isFinite(since)) throw new Error("Date invalide");
    return { symbol, since };
  })
  .handler(async ({ data }) => {
    const now = Math.floor(Date.now() / 1000);
    const start = Math.min(Math.floor(data.since / 1000), now - 3600);
    const span = Math.max(now - start, 3600);
    const interval = span < 3 * 86_400 ? "5m" : span < 40 * 86_400 ? "1h" : "1d";
    const chart = await loadChart(
      data.symbol,
      `period1=${start}&period2=${now}&interval=${interval}&includePrePost=false`,
    );
    return {
      symbol: data.symbol,
      currency: chart.currency,
      candles: chart.candles.filter((candle) => candle.t >= start - 60),
    };
  });

export const searchAssets = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const q = str((input as { q?: unknown }).q).trim().slice(0, 40);
    return { q };
  })
  .handler(async ({ data }) => {
    if (data.q.length < 1) return { results: [] as SearchHit[] };
    const key = `search:${data.q.toLowerCase()}`;
    const cached = recall<SearchHit[]>(key);
    if (cached) return { results: cached };
    const payload = (await yahooJson(
      `https://query2.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(data.q)}&quotesCount=8&newsCount=0`,
    )) as { quotes?: Array<Record<string, unknown>> };
    const results: SearchHit[] = [];
    const seen = new Set<string>();
    const alias = CRYPTO_ALIASES[data.q.toUpperCase()];
    if (alias) {
      seen.add(alias.symbol);
      results.push({
        symbol: alias.symbol,
        name: alias.name,
        kind: "crypto",
        badge: "Crypto",
        exchange: "CCC",
      });
    }
    for (const quote of payload.quotes ?? []) {
      const quoteType = str(quote.quoteType);
      if (quoteType !== "EQUITY" && quoteType !== "ETF" && quoteType !== "CRYPTOCURRENCY") continue;
      const symbol = cleanSymbol(str(quote.symbol));
      if (!symbol || seen.has(symbol)) continue;
      seen.add(symbol);
      const kind: Kind = quoteType === "CRYPTOCURRENCY" ? "crypto" : "stock";
      results.push({
        symbol,
        name: str(quote.shortname) || str(quote.longname) || symbol,
        kind,
        badge: badgeOf(quoteType, kind),
        exchange: str(quote.exchDisp),
      });
      if (results.length >= 8) break;
    }
    return { results: remember(key, 60_000, results) };
  });

function clamp(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, value));
}

function asStrings(value: unknown, limit: number): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => (typeof item === "string" ? item.trim().slice(0, 220) : ""))
    .filter(Boolean)
    .slice(0, limit);
}

function biasOf(value: unknown): AnalysisOk["bias"] {
  const text = str(value)
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "");
  if (text.includes("baiss")) return "baissiere";
  if (text.includes("hauss")) return "haussiere";
  return "neutre";
}

function riskOf(value: unknown): AnalysisOk["risk"] {
  const text = str(value)
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "");
  if (text.includes("elev") || text.includes("haut")) return "eleve";
  if (text.includes("faibl") || text.includes("bas")) return "faible";
  return "modere";
}

function sentimentOf(value: unknown, score: number): AnalysisOk["sentiment"] {
  const text = str(value)
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "");
  if (text.startsWith("pos")) return "positif";
  if (text.startsWith("neg")) return "negatif";
  if (text.startsWith("neu")) return "neutre";
  if (score > 15) return "positif";
  if (score < -15) return "negatif";
  return "neutre";
}

function sourceKind(url: string, hinted: unknown): SourceKind {
  const hint = str(hinted).toLowerCase();
  if (hint === "x" || hint === "twitter") return "x";
  if (hint === "marche" || hint === "marché") return "marche";
  const host = hostOf(url);
  if (host === "x.com" || host.endsWith(".x.com") || host === "twitter.com" || host.endsWith(".twitter.com")) {
    return "x";
  }
  return "web";
}

function readModel(payload: unknown): { text: string; citations: SourceRef[] } {
  const root = payload as {
    output?: Array<{
      type?: string;
      content?: Array<{
        type?: string;
        text?: string;
        annotations?: Array<{ type?: string; url?: string; title?: string }>;
      }>;
    }>;
  };
  let text = "";
  const citations: SourceRef[] = [];
  const seen = new Set<string>();
  for (const item of root.output ?? []) {
    if (item.type !== "message") continue;
    for (const part of item.content ?? []) {
      if (part.type === "output_text" && part.text) text += part.text;
      for (const ann of part.annotations ?? []) {
        if (ann.type !== "url_citation") continue;
        const url = safeHttp(str(ann.url));
        if (!url || seen.has(url)) continue;
        seen.add(url);
        const title = str(ann.title).trim();
        citations.push({
          title: title && !title.startsWith("http") ? title.slice(0, 160) : hostOf(url),
          url,
          publisher: hostOf(url),
          kind: sourceKind(url, ""),
        });
      }
    }
  }
  return { text, citations };
}

function buildAnalysis(
  symbol: string,
  raw: unknown,
  citations: SourceRef[],
  headlines: NewsItem[],
  cached: boolean,
  term: Term,
): AnalysisOk {
  const data = raw as Record<string, unknown>;
  const sentimentScore = Math.round(clamp(num(data.sentimentScore) ?? 0, -100, 100));
  const confidence = Math.round(clamp(num(data.confidence) ?? 50, 0, 100));
  const bias = biasOf(data.bias);
  const label = bias === "haussiere" ? "haussière" : bias === "baissiere" ? "baissière" : "neutre";
  const span = term === "court" ? "les prochains jours" : term === "moyen" ? "un à trois mois" : "six à dix-huit mois";
  const canned = `Tendance plutôt ${label} à ${confidence} % de confiance sur ${span}, selon les news et le cours.`;
  const outlook = str(data.outlook).trim();
  const sources: SourceRef[] = [];
  const seen = new Set<string>();
  const push = (source: SourceRef) => {
    if (!source.url || seen.has(source.url)) return;
    seen.add(source.url);
    sources.push(source);
  };
  if (Array.isArray(data.sources)) {
    for (const item of data.sources) {
      if (!item || typeof item !== "object") continue;
      const record = item as Record<string, unknown>;
      const url = safeHttp(str(record.url));
      if (!url) continue;
      const title = str(record.title).trim().slice(0, 160) || hostOf(url);
      push({
        title,
        url,
        publisher: str(record.publisher).trim().slice(0, 80) || hostOf(url),
        kind: sourceKind(url, record.kind),
      });
    }
  }
  for (const citation of citations) push(citation);
  for (const item of headlines) {
    push({ title: item.title, url: item.url, publisher: item.publisher, kind: "marche" });
    if (sources.length >= 6) break;
  }
  return {
    symbol,
    summary: str(data.summary).trim().slice(0, 700),
    sentiment: sentimentOf(data.sentiment, sentimentScore),
    sentimentScore,
    bullish: asStrings(data.bullish, 4),
    bearish: asStrings(data.bearish, 4),
    risk: riskOf(data.risk),
    riskNote: str(data.riskNote).trim().slice(0, 240),
    confidence,
    bias,
    outlook: outlook.length >= 20 ? outlook.slice(0, 320) : canned,
    sources: sources.slice(0, 6),
    term,
    generatedAt: new Date().toISOString(),
    cached,
  };
}

function extractJson(text: string): unknown {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("Réponse illisible");
  return JSON.parse(text.slice(start, end + 1));
}

async function callGrok(
  prompt: string,
  withTools: boolean,
  maxTokens = 1400,
): Promise<{ text: string; citations: SourceRef[] }> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) throw new Error("NO_KEY");
  const from = new Date(Date.now() - 12 * 86_400_000).toISOString().slice(0, 10);
  const body: Record<string, unknown> = {
    model: "grok-4.5",
    store: false,
    temperature: 0.2,
    reasoning: { effort: "low" },
    max_output_tokens: maxTokens,
    input: [
      {
        role: "system",
        content:
          "Tu es l'analyste du desk Vesper. Tu écris en français, de façon précise et prudente. Tu ne donnes jamais d'ordre d'achat ou de vente. Tu réponds uniquement par un objet JSON valide, sans markdown.",
      },
      { role: "user", content: prompt },
    ],
  };
  if (withTools) {
    body.tools = [{ type: "web_search" }, { type: "x_search", from_date: from }];
    body.max_tool_calls = 2;
  }
  const response = await fetch("https://api.x.ai/v1/responses", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(55_000),
  });
  if (!response.ok) {
    throw new Error(`Analyse indisponible (${response.status})`);
  }
  return readModel(await response.json());
}

function promptFor(detail: AssetDetail, withTools: boolean, term: Term): string {
  const headlines = detail.news
    .slice(0, 6)
    .map((item) => `- ${item.title} (${item.publisher})`)
    .join("\n");
  const today = new Intl.DateTimeFormat("fr-FR", { dateStyle: "long" }).format(new Date());
  const span =
    term === "court"
      ? "court terme (prochains jours)"
      : term === "moyen"
        ? "moyen terme (1 à 3 mois)"
        : "long terme (6 à 18 mois)";
  return [
    `Actif: ${detail.name} (${detail.symbol}), type ${detail.kind === "crypto" ? "crypto" : "action"}.`,
    `Date: ${today}. Horizon demandé: ${span}.`,
    `Cours: ${detail.price} ${detail.currency}. Variation du jour: ${detail.changePercent.toFixed(2)} %.`,
    "Croise toujours le cours et les news. Ne contredis pas ces chiffres et n'invente aucun cours ni aucun titre.",
    headlines ? `Titres déjà collectés:\n${headlines}` : "Peu de titres locaux.",
    withTools
      ? "Fais au plus une recherche web et une recherche sur X pour les faits récents, puis réponds."
      : "Appuie-toi uniquement sur ce contexte, sans outil.",
    "Le sentiment décrit les news sur cet horizon. La confiance dit à quel point les news étayent vraiment cette lecture.",
    `JSON exact:
{"summary":"3 phrases max","sentiment":"positif|neutre|negatif","sentimentScore":0,"bullish":["",""],"bearish":["",""],"risk":"faible|modere|eleve","riskNote":"","confidence":0,"bias":"haussiere|baissiere|neutre","outlook":"Tendance plutôt … à NN % de confiance sur cet horizon, selon les news et le cours.","sources":[{"title":"","url":"https://","publisher":"","kind":"web|x"}]}`,
    "sentimentScore de -100 à 100. confidence de 0 à 100. 2 à 3 arguments de chaque côté. 2 à 4 sources avec de vraies URL. Si une info vient de X, mets kind=x et une URL x.com.",
  ].join("\n");
}

function takeAiSlot(): boolean {
  const now = Date.now();
  if (now - aiWindowStart > 3_600_000) {
    aiWindowStart = now;
    aiCalls = 0;
  }
  if (aiCalls >= 10) return false;
  aiCalls += 1;
  return true;
}

async function runAnalysis(symbol: string, force: boolean, term: Term): Promise<AnalysisResult> {
  const cacheKey = `ai:${symbol}:${term}`;
  if (!force) {
    const cached = recall<AnalysisOk>(cacheKey);
    if (cached) return { ok: true, ...cached, cached: true };
  }
  if (!process.env.XAI_API_KEY) {
    return { ok: false, error: "L'analyse IA n'est pas disponible dans cet environnement." };
  }
  if (!takeAiSlot()) {
    return {
      ok: false,
      error: "Trop d'analyses sur une courte période. Réessayez un peu plus tard, ou rouvrez un actif déjà lu.",
    };
  }
  let detail: AssetDetail;
  try {
    detail = await loadAsset(symbol);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Actif introuvable";
    return { ok: false, error: message };
  }
  try {
    const first = await callGrok(promptFor(detail, true, term), true);
    const analysis = buildAnalysis(symbol, extractJson(first.text), first.citations, detail.news, false, term);
    remember(cacheKey, 30 * 60_000, analysis);
    return { ok: true, ...analysis };
  } catch {
    try {
      const second = await callGrok(promptFor(detail, false, term), false);
      const analysis = buildAnalysis(symbol, extractJson(second.text), second.citations, detail.news, false, term);
      remember(cacheKey, 30 * 60_000, analysis);
      return { ok: true, ...analysis };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Analyse impossible";
      if (message === "NO_KEY") {
        return { ok: false, error: "L'analyse IA n'est pas disponible dans cet environnement." };
      }
      return { ok: false, error: "L'analyse n'a pas abouti. Réessayez dans un instant." };
    }
  }
}

function parseTerm(value: unknown): Term {
  return value === "moyen" || value === "long" ? value : "court";
}

export const analyzeAsset = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const symbol = cleanSymbol(str((input as { symbol?: unknown }).symbol));
    if (!symbol) throw new Error("Ticker invalide");
    const force = Boolean((input as { force?: unknown }).force);
    return { symbol, force, term: parseTerm((input as { term?: unknown }).term) };
  })
  .handler(async ({ data }): Promise<AnalysisResult> => {
    const key = `${data.symbol}:${data.term}`;
    const existing = inflight.get(key);
    if (existing && !data.force) return existing;
    const job = runAnalysis(data.symbol, data.force, data.term).finally(() => {
      inflight.delete(key);
    });
    inflight.set(key, job);
    return job;
  });

type Perf = {
  symbol: string;
  name: string;
  currency: string;
  price: number;
  r1: number;
  r5: number | null;
  r10: number | null;
};

function returnOver(closes: number[], sessions: number): number | null {
  if (closes.length <= sessions) return null;
  const last = closes[closes.length - 1];
  const base = closes[closes.length - 1 - sessions];
  if (last == null || base == null || base === 0) return null;
  return ((last - base) / base) * 100;
}

async function loadPerfs(kind: Kind): Promise<Perf[]> {
  const key = `perfs:${kind}`;
  const cached = recall<Perf[]>(key);
  if (cached) return cached;
  const list = kind === "stock" ? BOARD_STOCKS : BOARD_CRYPTOS;
  const rows = await mapPool(list, 8, async (item) => {
    try {
      const chart = await loadChart(item.symbol, "interval=1d&range=1mo");
      const closes = chart.candles.map((candle) => candle.c);
      const r1 = returnOver(closes, 1);
      if (r1 == null) return null;
      const price = closes[closes.length - 1] ?? chart.price;
      return {
        symbol: item.symbol,
        name: item.name,
        currency: chart.currency,
        price,
        r1,
        r5: returnOver(closes, 5),
        r10: returnOver(closes, 10),
      } satisfies Perf;
    } catch {
      return null;
    }
  });
  const perfs = rows.filter((row): row is Perf => row !== null);
  if (perfs.length < 8) throw new Error("Classement momentanément indisponible");
  return remember(key, 180_000, perfs);
}

function scoreTitles(titles: string[]): number {
  const scored = titles.map((title) => newsSentiment(title)).filter((value) => value !== 0);
  if (scored.length === 0) return 0;
  const averageScore = scored.reduce((sum, value) => sum + value, 0) / scored.length;
  const high = Math.max(...scored);
  const low = Math.min(...scored);
  const conflict = high >= 28 && low <= -34 ? 0.45 : 1;
  const thin = scored.length === 1 ? 0.65 : 1;
  return Math.max(-100, Math.min(100, Math.round(averageScore * conflict * thin)));
}

async function hasFreshEightK(symbol: string): Promise<boolean> {
  const key = `sec8k:${symbol}`;
  const cached = recall<boolean>(key);
  if (cached != null) return cached;
  const base = symbol.replace(/-USD$/i, "");
  try {
    const response = await fetch(
      `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&ticker=${encodeURIComponent(base)}&type=8-K&count=3&output=atom`,
      {
        headers: {
          "User-Agent": "VesperPaperBot/1.0 (paper-trading)",
          Accept: "application/atom+xml",
        },
        signal: AbortSignal.timeout(8000),
      },
    );
    if (!response.ok) return remember(key, 30 * 60_000, false);
    const xml = await response.text();
    const dates = [...xml.matchAll(/<updated>([^<]+)<\/updated>/g)]
      .map((match) => Date.parse(match[1] ?? ""))
      .filter((value) => Number.isFinite(value));
    const newest = dates.sort((a, b) => b - a)[0];
    return remember(key, 30 * 60_000, newest != null && Date.now() - newest < 5 * 86_400_000);
  } catch {
    return remember(key, 10 * 60_000, false);
  }
}

async function botNews(
  symbol: string,
  name: string,
  kind: Kind,
): Promise<{ headline: string | null; sentiment: number }> {
  const key = `bot-news:${symbol}`;
  const cached = recall<{ headline: string | null; sentiment: number }>(key);
  if (cached) return cached;
  const titles: string[] = [];
  let headline: string | null = null;
  try {
    const news = await loadNews(kind === "crypto" ? name : symbol, symbol);
    const fresh = news.filter((item) => !item.publishedAt || item.publishedAt * 1000 > Date.now() - 4 * 86_400_000);
    const picked = (fresh.length > 0 ? fresh : []).slice(0, 4);
    for (const item of picked) titles.push(item.title);
    headline = picked[0]?.title ?? null;
  } catch {
    headline = null;
  }
  if (kind === "stock" && !symbol.includes(".") && (await hasFreshEightK(symbol))) {
    headline = headline ? `${headline} · dépôt SEC 8-K` : `Dépôt SEC 8-K — ${name}`;
  }
  return remember(key, 10 * 60_000, { headline, sentiment: scoreTitles(titles) });
}

async function headlineFor(
  symbol: string,
  name: string,
  kind: Kind,
): Promise<{ headline: string | null; headlineUrl: string | null; publisher: string | null }> {
  const key = `hl:${symbol}`;
  const cached = recall<{ headline: string | null; headlineUrl: string | null; publisher: string | null }>(key);
  if (cached) return cached;
  const query = kind === "crypto" ? name : symbol;
  let headline: string | null = null;
  let headlineUrl: string | null = null;
  let publisher: string | null = null;
  try {
    const news = await loadNews(query, symbol);
    const first = news[0];
    if (first) {
      headline = first.title;
      headlineUrl = first.url;
      publisher = first.publisher;
    }
  } catch {
    headline = null;
  }
  return remember(key, 10 * 60_000, { headline, headlineUrl, publisher });
}

async function buildBoard(kind: Kind, horizon: Horizon): Promise<TrendBoard> {
  const perfs = await loadPerfs(kind);
  const field = horizon === 1 ? "r1" : horizon === 5 ? "r5" : "r10";
  const ranked = perfs
    .filter((row) => row[field] != null)
    .sort((a, b) => (b[field] ?? 0) - (a[field] ?? 0));
  const bestPerf = ranked.slice(0, 10);
  const seen = new Set(bestPerf.map((row) => row.symbol));
  const worstPerf = [...ranked].reverse().filter((row) => !seen.has(row.symbol)).slice(0, 10);
  const picked = [...bestPerf, ...worstPerf];
  const headlines = await mapPool(picked, 6, (row) => headlineFor(row.symbol, row.name, kind));
  const toRow = (row: Perf, index: number): TrendRow => {
    const news = headlines[index];
    return {
      symbol: row.symbol,
      name: row.name,
      currency: row.currency,
      price: row.price,
      changePercent: row[field] ?? 0,
      headline: news?.headline ?? null,
      headlineUrl: news?.headlineUrl ?? null,
      publisher: news?.publisher ?? null,
    };
  };
  return {
    kind,
    horizon,
    best: bestPerf.map((row, index) => toRow(row, index)),
    worst: worstPerf.map((row, index) => toRow(row, bestPerf.length + index)),
    scanned: perfs.length,
  };
}

function parseHorizon(value: unknown): Horizon {
  return value === 5 || value === "5" || value === 10 || value === "10" ? (value === 10 || value === "10" ? 10 : 5) : 1;
}

export const getTrends = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const kind = (input as { kind?: unknown }).kind === "crypto" ? "crypto" : "stock";
    return { kind: kind as Kind, horizon: parseHorizon((input as { horizon?: unknown }).horizon) };
  })
  .handler(async ({ data }) => buildBoard(data.kind, data.horizon));

function linesOf(rows: TrendRow[]): string {
  return rows
    .map((row) => {
      const pct = `${row.changePercent >= 0 ? "+" : ""}${row.changePercent.toFixed(2)}%`;
      const news = row.headline ? ` — ${row.headline} (${row.publisher ?? "source"})` : " — pas de titre récent";
      return `${row.name} (${row.symbol}) ${pct}${news}`;
    })
    .join("\n");
}

export const readTrendBoard = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const kind = (input as { kind?: unknown }).kind === "crypto" ? "crypto" : "stock";
    const force = Boolean((input as { force?: unknown }).force);
    return { kind: kind as Kind, horizon: parseHorizon((input as { horizon?: unknown }).horizon), force };
  })
  .handler(async ({ data }): Promise<TrendRead> => {
    const key = `trend-ai:${data.kind}:${data.horizon}`;
    if (!data.force) {
      const cached = recall<Extract<TrendRead, { ok: true }>>(key);
      if (cached) return { ...cached, cached: true };
      const pending = trendInflight.get(key);
      if (pending) return pending;
    }
    const job = (async (): Promise<TrendRead> => {
      if (!process.env.XAI_API_KEY) {
        return { ok: false, error: "L'analyse IA n'est pas disponible dans cet environnement." };
      }
      if (!takeAiSlot()) {
        return { ok: false, error: "Trop d'analyses sur une courte période. Réessayez un peu plus tard." };
      }
      try {
        const board = await buildBoard(data.kind, data.horizon);
        const label = data.horizon === 1 ? "1 jour" : data.horizon === 5 ? "5 jours" : "10 jours";
        const universe = data.kind === "crypto" ? "cryptos majeures" : "grandes actions";
        const prompt = [
          `Classement ${universe} sur ${label}. N'invente aucun pourcentage ni aucun titre absent de la liste.`,
          "Relie les mouvements aux titres d'actualité fournis. Si un titre ne colle pas au mouvement, dis-le.",
          "Pas d'ordre d'achat ou de vente.",
          `Meilleures:\n${linesOf(board.best)}`,
          `Moins bonnes:\n${linesOf(board.worst)}`,
          `JSON exact: {"lead":"2 phrases","winnersNote":"pourquoi le haut du tableau","losersNote":"pourquoi le bas du tableau"}`,
        ].join("\n");
        const reply = await callGrok(prompt, false);
        const raw = extractJson(reply.text) as Record<string, unknown>;
        const result: Extract<TrendRead, { ok: true }> = {
          ok: true,
          lead: str(raw.lead).trim().slice(0, 500),
          winnersNote: str(raw.winnersNote).trim().slice(0, 500),
          losersNote: str(raw.losersNote).trim().slice(0, 500),
          cached: false,
        };
        if (!result.lead) return { ok: false, error: "Lecture vide. Réessayez." };
        remember(key, 20 * 60_000, result);
        return result;
      } catch (error) {
        const message = error instanceof Error ? error.message : "Lecture impossible";
        if (message === "NO_KEY") {
          return { ok: false, error: "L'analyse IA n'est pas disponible dans cet environnement." };
        }
        return { ok: false, error: "La lecture n'a pas abouti. Réessayez dans un instant." };
      }
    })().finally(() => {
      trendInflight.delete(key);
    });
    trendInflight.set(key, job);
    return job;
  });

const STOCK_SIGNALS = [
  "NVDA", "AAPL", "MSFT", "AMZN", "GOOGL", "META", "TSLA", "AVGO", "AMD", "JPM", "LLY", "XOM",
  "ASML", "MC.PA", "AIR.PA", "TTE.PA", "OR.PA", "SAN.PA", "SAP.DE", "NESN.SW", "NOVN.SW", "BNP.PA", "RMS.PA", "SU.PA",
];
const CRYPTO_SIGNALS = BOARD_CRYPTOS.map((item) => item.symbol).slice(0, 24);

type Scope = SentimentBoard["scope"];

function profileOf(symbol: string, fallbackName?: string, fallbackKind?: Kind): { name: string; kind: Kind } {
  const known = [...UNIVERSE, ...BOARD_STOCKS, ...BOARD_CRYPTOS].find((item) => item.symbol === symbol);
  if (known) return { name: known.name, kind: known.kind };
  return {
    name: fallbackName?.trim() || symbol,
    kind: fallbackKind ?? (symbol.endsWith("-USD") ? "crypto" : "stock"),
  };
}

function poolFor(scope: Scope, favorites: { symbol: string; name: string; kind: Kind }[]): { symbol: string; name: string; kind: Kind }[] {
  if (scope === "favoris") return favorites.slice(0, 20);
  if (scope === "crypto") return CRYPTO_SIGNALS.map((symbol) => ({ symbol, ...profileOf(symbol) }));
  if (scope === "stock") return STOCK_SIGNALS.map((symbol) => ({ symbol, ...profileOf(symbol) }));
  const stocks = STOCK_SIGNALS.slice(0, 12).map((symbol) => ({ symbol, ...profileOf(symbol) }));
  const cryptos = CRYPTO_SIGNALS.slice(0, 12).map((symbol) => ({ symbol, ...profileOf(symbol) }));
  return [...stocks, ...cryptos];
}

export const rankSentiment = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const scopeRaw = (input as { scope?: unknown }).scope;
    const scope: Scope =
      scopeRaw === "stock" || scopeRaw === "crypto" || scopeRaw === "favoris" || scopeRaw === "mix" ? scopeRaw : "mix";
    const force = Boolean((input as { force?: unknown }).force);
    const raw = (input as { favorites?: unknown }).favorites;
    const favorites = Array.isArray(raw)
      ? raw
          .map((item) => {
            if (!item || typeof item !== "object") return null;
            const record = item as { symbol?: unknown; name?: unknown; kind?: unknown };
            const symbol = cleanSymbol(str(record.symbol));
            if (!symbol) return null;
            const kind: Kind = record.kind === "crypto" ? "crypto" : "stock";
            return { symbol, name: str(record.name).slice(0, 80) || symbol, kind };
          })
          .filter((item): item is { symbol: string; name: string; kind: Kind } => item !== null)
          .slice(0, 20)
      : [];
    return { term: parseTerm((input as { term?: unknown }).term), scope, force, favorites };
  })
  .handler(async ({ data }) => {
    const favKey = data.favorites.map((item) => item.symbol).join(",");
    const key = `sentiment:${data.term}:${data.scope}:${favKey}`;
    if (!data.force) {
      const cached = recall<SentimentBoard>(key);
      if (cached) return { ok: true as const, board: cached, cached: true as const };
      const pending = sentimentInflight.get(key);
      if (pending) return pending;
    }
    const job = (async () => {
      const pool = poolFor(data.scope, data.favorites);
      if (pool.length === 0) {
        return { ok: false as const, error: "Ajoutez des favoris pour classer leur sentiment." };
      }
      if (!process.env.XAI_API_KEY) {
        return { ok: false as const, error: "L'analyse IA n'est pas disponible dans cet environnement." };
      }
      if (!takeAiSlot()) {
        return { ok: false as const, error: "Trop d'analyses sur une courte période. Réessayez un peu plus tard." };
      }
      try {
        const briefs = await mapPool(pool, 6, async (item) => {
          try {
            const chart = await loadChart(item.symbol, "interval=1d&range=5d");
            const closes = chart.candles.map((candle) => candle.c);
            const price = closes[closes.length - 1] ?? chart.price;
            const changePercent = returnOver(closes, 1) ?? 0;
            const news = await headlineFor(item.symbol, item.name, item.kind);
            return {
              ...item,
              currency: chart.currency,
              price,
              changePercent,
              headline: news.headline,
            };
          } catch {
            return null;
          }
        });
        const ready = briefs.filter((row): row is NonNullable<(typeof briefs)[number]> => row !== null);
        if (ready.length < 4) return { ok: false as const, error: "Pas assez de cours pour classer le sentiment." };
        const span =
          data.term === "court"
            ? "court terme (prochains jours)"
            : data.term === "moyen"
              ? "moyen terme (1 à 3 mois)"
              : "long terme (6 à 18 mois)";
        const lines = ready
          .map((row) => {
            const pct = `${row.changePercent >= 0 ? "+" : ""}${row.changePercent.toFixed(2)}%`;
            const news = row.headline ? row.headline : "pas de titre récent";
            return `${row.symbol} | ${row.name} | ${row.kind === "crypto" ? "crypto" : "action"} | jour ${pct} | ${news}`;
          })
          .join("\n");
        const prompt = [
          `Note chaque actif pour un horizon ${span}.`,
          "Croise le mouvement du jour et le titre de news. N'invente aucun titre absent de la ligne.",
          "sentimentScore de -100 à 100 = sentiment des news sur cet horizon.",
          "confidence de 0 à 100 = confiance que les news étayent vraiment cette lecture. Baisse-la si le titre est hors sujet ou absent.",
          "note: une phrase courte, sans conseil d'achat ou de vente.",
          lines,
          `JSON exact: {"rows":[{"symbol":"","sentimentScore":0,"confidence":0,"note":""}]}`,
          "Une entrée par symbole de la liste, pas plus.",
        ].join("\n");
        const reply = await callGrok(prompt, false, 2600);
        const raw = extractJson(reply.text) as { rows?: unknown };
        const scored = Array.isArray(raw.rows) ? raw.rows : [];
        const bySymbol = new Map<string, { sentimentScore: number; confidence: number; note: string }>();
        for (const item of scored) {
          if (!item || typeof item !== "object") continue;
          const record = item as Record<string, unknown>;
          const symbol = cleanSymbol(str(record.symbol));
          if (!symbol) continue;
          bySymbol.set(symbol, {
            sentimentScore: Math.round(clamp(num(record.sentimentScore) ?? 0, -100, 100)),
            confidence: Math.round(clamp(num(record.confidence) ?? 0, 0, 100)),
            note: str(record.note).trim().slice(0, 180),
          });
        }
        const rows: SentimentRow[] = ready
          .filter((row) => bySymbol.has(row.symbol))
          .map((row) => {
            const score = bySymbol.get(row.symbol)!;
            return {
              symbol: row.symbol,
              name: row.name,
              kind: row.kind,
              currency: row.currency,
              price: row.price,
              changePercent: row.changePercent,
              sentiment: sentimentOf(null, score.sentimentScore),
              sentimentScore: score.sentimentScore,
              confidence: score.confidence,
              note: score.note,
              headline: row.headline,
            };
          })
          .sort((a, b) => b.sentimentScore * (b.confidence / 100) - a.sentimentScore * (a.confidence / 100))
          .slice(0, 20);
        if (rows.length < 4) return { ok: false as const, error: "Le classement est incomplet. Réessayez." };
        const board: SentimentBoard = { term: data.term, scope: data.scope, rows, scanned: ready.length };
        remember(key, 25 * 60_000, board);
        return { ok: true as const, board, cached: false as const };
      } catch (error) {
        const message = error instanceof Error ? error.message : "Classement impossible";
        if (message === "NO_KEY") {
          return { ok: false as const, error: "L'analyse IA n'est pas disponible dans cet environnement." };
        }
        return { ok: false as const, error: "Le classement n'a pas abouti. Réessayez dans un instant." };
      }
    })().finally(() => {
      sentimentInflight.delete(key);
    });
    sentimentInflight.set(key, job);
    return job;
  });

function average(values: number[]): number | null {
  if (values.length === 0) return null;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function sma(values: number[], period: number): number | null {
  if (values.length < period) return null;
  return average(values.slice(-period));
}

function rsiOf(values: number[], period = 14): number | null {
  if (values.length < period + 1) return null;
  let gain = 0;
  let loss = 0;
  for (let i = values.length - period; i < values.length; i += 1) {
    const delta = values[i]! - values[i - 1]!;
    if (delta >= 0) gain += delta;
    else loss -= delta;
  }
  if (loss === 0) return 100;
  const relative = gain / loss;
  return 100 - 100 / (1 + relative);
}

function volatilityOf(values: number[]): number | null {
  if (values.length < 12) return null;
  const returns: number[] = [];
  const window = values.slice(-15);
  for (let i = 1; i < window.length; i += 1) {
    const prev = window[i - 1]!;
    if (prev === 0) continue;
    returns.push(((window[i]! - prev) / prev) * 100);
  }
  const mid = average(returns);
  if (mid == null || returns.length < 8) return null;
  const variance = average(returns.map((value) => (value - mid) ** 2));
  return variance == null ? null : Math.sqrt(variance);
}

function newsSentiment(title: string | null): number {
  if (!title) return 0;
  const text = title.toLowerCase();
  const positive = ["surge", "soar", "jump", "beat", "upgrade", "rally", "record", "growth", "approval", "gain", "rise", "strong", "boost", "expands", "wins"];
  const negative = ["fall", "drop", "miss", "downgrade", "lawsuit", "crash", "plunge", "cut", "warning", "weak", "selloff", "fraud", "slump", "loss", "decline", "sink"];
  let score = 0;
  for (const word of positive) if (text.includes(word)) score += 28;
  for (const word of negative) if (text.includes(word)) score -= 34;
  return Math.max(-100, Math.min(100, score));
}

async function usdMultiplier(currency: string): Promise<number | null> {
  if (currency === "USD") return 1;
  const key = `fx:${currency}`;
  const cached = recall<number>(key);
  if (cached) return cached;
  try {
    const direct = currency === "EUR" || currency === "GBP" || currency === "AUD" || currency === "NZD";
    const pence = currency === "GBp" || currency === "GBX";
    const pair = pence ? "GBPUSD=X" : direct ? `${currency}USD=X` : `${currency}=X`;
    const chart = await loadChart(pair, "interval=1d&range=5d");
    if (!(chart.price > 0)) return null;
    const rate = pence ? chart.price / 100 : direct ? chart.price : 1 / chart.price;
    return remember(key, 10 * 60_000, rate);
  } catch {
    return null;
  }
}

async function quoteFor(symbol: string, name: string, kind: Kind): Promise<BotQuote> {
  const chart = await loadChart(symbol, "interval=1d&range=6mo");
  const closes = chart.candles.map((candle) => candle.c).filter((value) => Number.isFinite(value));
  const price = closes[closes.length - 1] ?? chart.price;
  const changePercent = returnOver(closes, 1) ?? 0;
  const sma20 = sma(closes, 20);
  const sma50 = sma(closes, 50);
  const trend: BotQuote["trend"] =
    sma20 != null && sma50 != null && price > sma20 && sma20 > sma50
      ? "haussiere"
      : sma20 != null && sma50 != null && price < sma20 && sma20 < sma50
        ? "baissiere"
        : "neutre";
  const recent = chart.candles.slice(-20);
  const support = recent.length ? Math.min(...recent.map((candle) => candle.l)) : null;
  const resistance = recent.length ? Math.max(...recent.map((candle) => candle.h)) : null;
  const volumes = chart.candles.map((candle) => candle.v).filter((value) => Number.isFinite(value) && value > 0);
  const latestVolume = volumes.length > 1 ? volumes[volumes.length - 2] : volumes[volumes.length - 1];
  const baseVolume = average(volumes.length > 2 ? volumes.slice(-22, -2) : volumes.slice(0, -1));
  const fx = await usdMultiplier(chart.currency || "USD");
  if (fx == null) throw new Error("fx");
  const toUsd = (value: number | null) => (value == null ? null : value * fx);
  const native = closes[closes.length - 1] ?? chart.price;
  const usdPrice = native * fx;
  const sma20Usd = toUsd(sma20);
  const sma50Usd = toUsd(sma50);
  const supportUsd = toUsd(support);
  const resistanceUsd = toUsd(resistance);
  const news = await botNews(symbol, name, kind);
  return {
    symbol,
    name: name || chart.name || symbol,
    kind,
    price: usdPrice,
    changePercent,
    rsi: rsiOf(closes),
    sma20: sma20Usd,
    sma50: sma50Usd,
    volumeRatio: latestVolume != null && baseVolume ? latestVolume / baseVolume : null,
    support: supportUsd,
    resistance: resistanceUsd,
    volatility: volatilityOf(closes),
    trend,
    sentiment: news.sentiment,
    headline: news.headline,
    market: marketOf(symbol),
    currency: chart.currency || "USD",
  };
}

const botQuoteBook = new Map<string, { quote: BotQuote; at: number }>();

export async function loadBotQuotes(
  extra: { symbol: string; name: string; kind: Kind }[] = [],
  onProgress?: (done: number, total: number) => void,
): Promise<BotQuote[]> {
  const wanted = new Map<string, { symbol: string; name: string; kind: Kind }>();
  for (const item of [...BOT_UNIVERSE, ...extra]) {
    if (item.symbol) wanted.set(item.symbol, item);
  }
  const list = [...wanted.values()];
  const missing = list.filter((item) => !botQuoteBook.has(item.symbol));
  const oldest = [...botQuoteBook.entries()]
    .filter(([symbol]) => wanted.has(symbol))
    .sort((a, b) => a[1].at - b[1].at)
    .map(([symbol]) => wanted.get(symbol)!)
    .filter((item) => !missing.some((row) => row.symbol === item.symbol));
  const batch =
    botQuoteBook.size === 0
      ? (["États-Unis", "Europe", "Japon", "Hong Kong", "Canada", "Crypto"]
          .map((market) => list.find((item) => marketOf(item.symbol) === market))
          .filter((item): item is (typeof list)[number] => item != null))
      : [...missing, ...oldest].slice(0, 6);
  const ready = () => list.filter((item) => botQuoteBook.has(item.symbol)).length;
  onProgress?.(ready(), list.length);
  if (batch.length > 0) {
    await mapPool(batch, 3, async (item) => {
      try {
        const quote = await quoteFor(item.symbol, item.name, item.kind);
        if (quote) botQuoteBook.set(quote.symbol, { quote, at: Date.now() });
      } catch {
        // Un titre en échec ne bloque pas le reste du passage.
      }
      onProgress?.(ready(), list.length);
      return null;
    });
  }
  const quotes = list.map((item) => botQuoteBook.get(item.symbol)?.quote).filter((quote): quote is BotQuote => quote != null);
  if (quotes.length < 6) throw new Error("Marché du bot momentanément indisponible");
  return quotes;
}

export const getBotMarket = createServerFn({ method: "GET" }).handler(async () => {
  const quotes = await loadBotQuotes();
  return { quotes };
});

function smaSeries(values: number[], period: number): (number | null)[] {
  return values.map((_, index) => (index + 1 >= period ? average(values.slice(index + 1 - period, index + 1)) : null));
}

function rsiSeries(values: number[], period = 14): (number | null)[] {
  return values.map((_, index) => (index >= period ? rsiOf(values.slice(0, index + 1), period) : null));
}

export type AnalysisPoint = {
  t: number;
  price: number;
  sma20: number | null;
  sma50: number | null;
  rsi: number | null;
};

export const inspectForBot = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const symbol = cleanSymbol(str((input as { symbol?: unknown }).symbol));
    if (!symbol) throw new Error("Ticker invalide");
    return { symbol };
  })
  .handler(async ({ data }) => {
    const alias = CRYPTO_ALIASES[data.symbol.toUpperCase()];
    const symbol = alias?.symbol ?? data.symbol;
    const known = universeBySymbol(symbol);
    const kind: Kind = known?.kind ?? (symbol.endsWith("-USD") ? "crypto" : "stock");
    const name = known?.name ?? alias?.name ?? symbol;
    const quote = await quoteFor(symbol, name, kind);
    const chart = await loadChart(symbol, "interval=1d&range=6mo");
    const rows = chart.candles.filter((candle) => Number.isFinite(candle.c));
    const closes = rows.map((candle) => candle.c);
    const sma20 = smaSeries(closes, 20);
    const sma50 = smaSeries(closes, 50);
    const rsi = rsiSeries(closes);
    const start = Math.max(0, rows.length - 90);
    const series: AnalysisPoint[] = rows.slice(start).map((candle, offset) => {
      const index = start + offset;
      return {
        t: candle.t * 1000,
        price: candle.c,
        sma20: sma20[index] ?? null,
        sma50: sma50[index] ?? null,
        rsi: rsi[index] ?? null,
      };
    });
    return { quote, series };
  });



