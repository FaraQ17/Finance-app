export type Kind = "stock" | "crypto";
export type Filter = "all" | "stock" | "crypto";
export type RangeKey = "1d" | "7d" | "30d";
export type ChartMode = "line" | "candle";
export type SourceKind = "web" | "x" | "marche";

export type UniverseItem = {
  symbol: string;
  name: string;
  kind: Kind;
};

export function marketOf(symbol: string): string {
  if (symbol.endsWith("-USD")) return "Crypto";
  if (/\.(PA|DE|AS|MI|MC|L|SW)$/.test(symbol)) return "Europe";
  if (symbol.endsWith(".T")) return "Japon";
  if (symbol.endsWith(".HK")) return "Hong Kong";
  if (symbol.endsWith(".TO")) return "Canada";
  return "États-Unis";
}

export const BOT_UNIVERSE: UniverseItem[] = [
  { symbol: "AAPL", name: "Apple", kind: "stock" },
  { symbol: "MSFT", name: "Microsoft", kind: "stock" },
  { symbol: "NVDA", name: "NVIDIA", kind: "stock" },
  { symbol: "AMZN", name: "Amazon", kind: "stock" },
  { symbol: "GOOGL", name: "Alphabet", kind: "stock" },
  { symbol: "META", name: "Meta", kind: "stock" },
  { symbol: "AVGO", name: "Broadcom", kind: "stock" },
  { symbol: "LLY", name: "Eli Lilly", kind: "stock" },
  { symbol: "JPM", name: "JPMorgan", kind: "stock" },
  { symbol: "V", name: "Visa", kind: "stock" },
  { symbol: "COST", name: "Costco", kind: "stock" },
  { symbol: "WMT", name: "Walmart", kind: "stock" },
  { symbol: "JNJ", name: "Johnson & Johnson", kind: "stock" },
  { symbol: "UNH", name: "UnitedHealth", kind: "stock" },
  { symbol: "XOM", name: "Exxon", kind: "stock" },
  { symbol: "PG", name: "Procter & Gamble", kind: "stock" },
  { symbol: "KO", name: "Coca-Cola", kind: "stock" },
  { symbol: "PEP", name: "PepsiCo", kind: "stock" },
  { symbol: "HD", name: "Home Depot", kind: "stock" },
  { symbol: "MC.PA", name: "LVMH", kind: "stock" },
  { symbol: "AIR.PA", name: "Airbus", kind: "stock" },
  { symbol: "OR.PA", name: "L'Oréal", kind: "stock" },
  { symbol: "TTE.PA", name: "TotalEnergies", kind: "stock" },
  { symbol: "SAP.DE", name: "SAP", kind: "stock" },
  { symbol: "SIE.DE", name: "Siemens", kind: "stock" },
  { symbol: "ASML.AS", name: "ASML", kind: "stock" },
  { symbol: "AZN.L", name: "AstraZeneca", kind: "stock" },
  { symbol: "SHEL.L", name: "Shell", kind: "stock" },
  { symbol: "NESN.SW", name: "Nestlé", kind: "stock" },
  { symbol: "NOVN.SW", name: "Novartis", kind: "stock" },
  { symbol: "ROG.SW", name: "Roche", kind: "stock" },
  { symbol: "7203.T", name: "Toyota", kind: "stock" },
  { symbol: "6758.T", name: "Sony", kind: "stock" },
  { symbol: "9984.T", name: "SoftBank", kind: "stock" },
  { symbol: "8035.T", name: "Tokyo Electron", kind: "stock" },
  { symbol: "6861.T", name: "Keyence", kind: "stock" },
  { symbol: "0700.HK", name: "Tencent", kind: "stock" },
  { symbol: "RY.TO", name: "Banque Royale du Canada", kind: "stock" },
  { symbol: "BTC-USD", name: "Bitcoin", kind: "crypto" },
  { symbol: "ETH-USD", name: "Ethereum", kind: "crypto" },
  { symbol: "SOL-USD", name: "Solana", kind: "crypto" },
];

export type BotQuote = {
  symbol: string;
  name: string;
  kind: Kind;
  price: number;
  changePercent: number;
  rsi: number | null;
  sma20: number | null;
  sma50: number | null;
  volumeRatio: number | null;
  support: number | null;
  resistance: number | null;
  volatility: number | null;
  trend: "haussiere" | "baissiere" | "neutre";
  sentiment: number;
  headline: string | null;
  market: string;
  currency: string;
};

export const UNIVERSE: UniverseItem[] = [
  { symbol: "AAPL", name: "Apple", kind: "stock" },
  { symbol: "NVDA", name: "NVIDIA", kind: "stock" },
  { symbol: "MSFT", name: "Microsoft", kind: "stock" },
  { symbol: "TSLA", name: "Tesla", kind: "stock" },
  { symbol: "AMZN", name: "Amazon", kind: "stock" },
  { symbol: "GOOGL", name: "Alphabet", kind: "stock" },
  { symbol: "META", name: "Meta", kind: "stock" },
  { symbol: "MC.PA", name: "LVMH", kind: "stock" },
  { symbol: "AIR.PA", name: "Airbus", kind: "stock" },
  { symbol: "TTE.PA", name: "TotalEnergies", kind: "stock" },
  { symbol: "OR.PA", name: "L'Oréal", kind: "stock" },
  { symbol: "SAN.PA", name: "Sanofi", kind: "stock" },
  { symbol: "BTC-USD", name: "Bitcoin", kind: "crypto" },
  { symbol: "ETH-USD", name: "Ethereum", kind: "crypto" },
  { symbol: "SOL-USD", name: "Solana", kind: "crypto" },
  { symbol: "XRP-USD", name: "XRP", kind: "crypto" },
  { symbol: "BNB-USD", name: "BNB", kind: "crypto" },
  { symbol: "DOGE-USD", name: "Dogecoin", kind: "crypto" },
];

export const BOARD_STOCKS: UniverseItem[] = [
  { symbol: "AAPL", name: "Apple", kind: "stock" },
  { symbol: "MSFT", name: "Microsoft", kind: "stock" },
  { symbol: "NVDA", name: "NVIDIA", kind: "stock" },
  { symbol: "AMZN", name: "Amazon", kind: "stock" },
  { symbol: "GOOGL", name: "Alphabet", kind: "stock" },
  { symbol: "META", name: "Meta", kind: "stock" },
  { symbol: "TSLA", name: "Tesla", kind: "stock" },
  { symbol: "AVGO", name: "Broadcom", kind: "stock" },
  { symbol: "JPM", name: "JPMorgan", kind: "stock" },
  { symbol: "V", name: "Visa", kind: "stock" },
  { symbol: "UNH", name: "UnitedHealth", kind: "stock" },
  { symbol: "XOM", name: "Exxon", kind: "stock" },
  { symbol: "LLY", name: "Eli Lilly", kind: "stock" },
  { symbol: "JNJ", name: "Johnson & Johnson", kind: "stock" },
  { symbol: "WMT", name: "Walmart", kind: "stock" },
  { symbol: "MA", name: "Mastercard", kind: "stock" },
  { symbol: "HD", name: "Home Depot", kind: "stock" },
  { symbol: "COST", name: "Costco", kind: "stock" },
  { symbol: "NFLX", name: "Netflix", kind: "stock" },
  { symbol: "AMD", name: "AMD", kind: "stock" },
  { symbol: "CRM", name: "Salesforce", kind: "stock" },
  { symbol: "ORCL", name: "Oracle", kind: "stock" },
  { symbol: "BAC", name: "Bank of America", kind: "stock" },
  { symbol: "KO", name: "Coca-Cola", kind: "stock" },
  { symbol: "DIS", name: "Disney", kind: "stock" },
  { symbol: "INTC", name: "Intel", kind: "stock" },
  { symbol: "QCOM", name: "Qualcomm", kind: "stock" },
  { symbol: "AMAT", name: "Applied Materials", kind: "stock" },
  { symbol: "PLTR", name: "Palantir", kind: "stock" },
  { symbol: "ASML", name: "ASML", kind: "stock" },
  { symbol: "MC.PA", name: "LVMH", kind: "stock" },
  { symbol: "AIR.PA", name: "Airbus", kind: "stock" },
  { symbol: "TTE.PA", name: "TotalEnergies", kind: "stock" },
  { symbol: "OR.PA", name: "L'Oréal", kind: "stock" },
  { symbol: "SAN.PA", name: "Sanofi", kind: "stock" },
  { symbol: "AI.PA", name: "Air Liquide", kind: "stock" },
  { symbol: "BNP.PA", name: "BNP Paribas", kind: "stock" },
  { symbol: "RMS.PA", name: "Hermès", kind: "stock" },
  { symbol: "SU.PA", name: "Schneider", kind: "stock" },
  { symbol: "SAP.DE", name: "SAP", kind: "stock" },
  { symbol: "SIE.DE", name: "Siemens", kind: "stock" },
  { symbol: "NESN.SW", name: "Nestlé", kind: "stock" },
  { symbol: "NOVN.SW", name: "Novartis", kind: "stock" },
];

export const BOARD_CRYPTOS: UniverseItem[] = [
  { symbol: "BTC-USD", name: "Bitcoin", kind: "crypto" },
  { symbol: "ETH-USD", name: "Ethereum", kind: "crypto" },
  { symbol: "SOL-USD", name: "Solana", kind: "crypto" },
  { symbol: "XRP-USD", name: "XRP", kind: "crypto" },
  { symbol: "BNB-USD", name: "BNB", kind: "crypto" },
  { symbol: "DOGE-USD", name: "Dogecoin", kind: "crypto" },
  { symbol: "ADA-USD", name: "Cardano", kind: "crypto" },
  { symbol: "AVAX-USD", name: "Avalanche", kind: "crypto" },
  { symbol: "LINK-USD", name: "Chainlink", kind: "crypto" },
  { symbol: "TON-USD", name: "Toncoin", kind: "crypto" },
  { symbol: "LTC-USD", name: "Litecoin", kind: "crypto" },
  { symbol: "TRX-USD", name: "TRON", kind: "crypto" },
  { symbol: "DOT-USD", name: "Polkadot", kind: "crypto" },
  { symbol: "NEAR-USD", name: "NEAR", kind: "crypto" },
  { symbol: "ATOM-USD", name: "Cosmos", kind: "crypto" },
  { symbol: "SHIB-USD", name: "Shiba Inu", kind: "crypto" },
  { symbol: "BCH-USD", name: "Bitcoin Cash", kind: "crypto" },
  { symbol: "FIL-USD", name: "Filecoin", kind: "crypto" },
  { symbol: "ICP-USD", name: "Internet Computer", kind: "crypto" },
  { symbol: "INJ-USD", name: "Injective", kind: "crypto" },
  { symbol: "AAVE-USD", name: "Aave", kind: "crypto" },
  { symbol: "HBAR-USD", name: "Hedera", kind: "crypto" },
  { symbol: "XLM-USD", name: "Stellar", kind: "crypto" },
  { symbol: "ARB-USD", name: "Arbitrum", kind: "crypto" },
  { symbol: "OP-USD", name: "Optimism", kind: "crypto" },
];

export type Horizon = 1 | 5 | 10;

export type Term = "court" | "moyen" | "long";

export type SentimentRow = {
  symbol: string;
  name: string;
  kind: Kind;
  currency: string;
  price: number;
  changePercent: number;
  sentiment: "positif" | "neutre" | "negatif";
  sentimentScore: number;
  confidence: number;
  note: string;
  headline: string | null;
};

export type SentimentBoard = {
  term: Term;
  scope: "stock" | "crypto" | "mix" | "favoris";
  rows: SentimentRow[];
  scanned: number;
};

export type TrendRow = {
  symbol: string;
  name: string;
  currency: string;
  price: number;
  changePercent: number;
  headline: string | null;
  headlineUrl: string | null;
  publisher: string | null;
};

export type TrendBoard = {
  kind: Kind;
  horizon: Horizon;
  best: TrendRow[];
  worst: TrendRow[];
  scanned: number;
};

export type TrendRead =
  | { ok: true; lead: string; winnersNote: string; losersNote: string; cached: boolean }
  | { ok: false; error: string };

export const CRYPTO_ALIASES: Record<string, { symbol: string; name: string }> = {
  BTC: { symbol: "BTC-USD", name: "Bitcoin" },
  BITCOIN: { symbol: "BTC-USD", name: "Bitcoin" },
  ETH: { symbol: "ETH-USD", name: "Ethereum" },
  ETHEREUM: { symbol: "ETH-USD", name: "Ethereum" },
  SOL: { symbol: "SOL-USD", name: "Solana" },
  SOLANA: { symbol: "SOL-USD", name: "Solana" },
  XRP: { symbol: "XRP-USD", name: "XRP" },
  DOGE: { symbol: "DOGE-USD", name: "Dogecoin" },
  DOGECOIN: { symbol: "DOGE-USD", name: "Dogecoin" },
  ADA: { symbol: "ADA-USD", name: "Cardano" },
  CARDANO: { symbol: "ADA-USD", name: "Cardano" },
  AVAX: { symbol: "AVAX-USD", name: "Avalanche" },
  BNB: { symbol: "BNB-USD", name: "BNB" },
  DOT: { symbol: "DOT-USD", name: "Polkadot" },
  LINK: { symbol: "LINK-USD", name: "Chainlink" },
  TON: { symbol: "TON-USD", name: "Toncoin" },
  LTC: { symbol: "LTC-USD", name: "Litecoin" },
  SUI: { symbol: "SUI-USD", name: "Sui" },
  TRX: { symbol: "TRX-USD", name: "TRON" },
  NEAR: { symbol: "NEAR-USD", name: "NEAR" },
  APT: { symbol: "APT-USD", name: "Aptos" },
};

export type Candle = {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
};

export type Snapshot = {
  symbol: string;
  name: string;
  kind: Kind;
  badge: string;
  currency: string;
  exchange: string;
  price: number;
  changePercent: number;
  changeAbs: number;
  spark: number[];
};

export type NewsItem = {
  id: string;
  title: string;
  publisher: string;
  url: string;
  publishedAt: number;
};

export type AssetDetail = {
  symbol: string;
  name: string;
  kind: Kind;
  badge: string;
  currency: string;
  exchange: string;
  price: number;
  changePercent: number;
  changeAbs: number;
  dayHigh: number | null;
  dayLow: number | null;
  volume: number | null;
  previousClose: number | null;
  week52High: number | null;
  week52Low: number | null;
  news: NewsItem[];
};

export type SearchHit = {
  symbol: string;
  name: string;
  kind: Kind;
  badge: string;
  exchange: string;
};

export type SourceRef = {
  title: string;
  url: string;
  publisher: string;
  kind: SourceKind;
};

export type AnalysisOk = {
  symbol: string;
  summary: string;
  sentiment: "positif" | "neutre" | "negatif";
  sentimentScore: number;
  bullish: string[];
  bearish: string[];
  risk: "faible" | "modere" | "eleve";
  riskNote: string;
  confidence: number;
  bias: "haussiere" | "baissiere" | "neutre";
  outlook: string;
  sources: SourceRef[];
  term: Term;
  generatedAt: string;
  cached: boolean;
};

export type AnalysisResult = ({ ok: true } & AnalysisOk) | { ok: false; error: string };

export const DISCLAIMER =
  "Ceci n'est pas un conseil en investissement. Analyse générée par IA à titre informatif uniquement.";

export function cleanSymbol(input: string): string | null {
  const symbol = input.trim().toUpperCase().replace(/\s+/g, "");
  if (!/^[A-Z0-9][A-Z0-9.\-]{0,14}$/.test(symbol)) return null;
  return symbol;
}

export function universeBySymbol(symbol: string): UniverseItem | undefined {
  return UNIVERSE.find((item) => item.symbol === symbol);
}
