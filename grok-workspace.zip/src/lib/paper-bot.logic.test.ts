import assert from "node:assert/strict";
import test from "node:test";
import { freshPaper, step, accountDestroyed, type PaperState } from "./paper-bot.ts";
import type { BotQuote } from "./universe.ts";

function quote(patch: Partial<BotQuote> = {}): BotQuote {
  return {
    symbol: "AAPL",
    name: "Apple",
    kind: "stock",
    price: 100,
    changePercent: 0.4,
    rsi: 55,
    sma20: 98,
    sma50: 90,
    volumeRatio: 1,
    support: 94,
    resistance: 110,
    volatility: 1.2,
    trend: "haussiere",
    sentiment: 0,
    headline: null,
    market: "États-Unis",
    currency: "USD",
    ...patch,
  };
}

function holding(patch: Partial<PaperState> = {}): PaperState {
  return {
    ...freshPaper(1_000),
    paused: false,
    activated: true,
    cash: 900,
    marks: { AAPL: 100 },
    positions: [
      {
        symbol: "AAPL",
        name: "Apple",
        kind: "stock",
        qty: 1,
        entry: 100,
        stop: 96,
        target: 107,
        openedAt: 1_000,
        actor: "bot",
        side: "long",
      },
    ],
    ...patch,
  };
}

test("un cours aberrant ne déclenche ni stop ni mise à jour", () => {
  const next = step(holding(), [quote({ price: 1000 })], 5_000);
  assert.equal(next.positions.length, 1);
  assert.equal(next.marks.AAPL, 100);
});

test("le stop de la ligne vend", () => {
  const next = step(holding(), [quote({ price: 95, trend: "baissiere" })], 5_000);
  assert.equal(next.positions.length, 0);
  assert.equal(next.trades[0]?.side, "vente");
  assert.match(next.trades[0]?.reason ?? "", /Stop-loss/);
});

test("l'objectif enregistré vend, pas le réglage courant", () => {
  const state = holding();
  state.risk = { ...state.risk, targetPct: 20 };
  const next = step(state, [quote({ price: 108 })], 5_000);
  assert.equal(next.positions.length, 0);
  assert.match(next.trades[0]?.reason ?? "", /Objectif/);
});

test("une news négative hors sujet ne ferme pas la ligne", () => {
  const next = step(
    holding(),
    [quote({ price: 100, trend: "neutre", sentiment: -70, headline: "Markets fall on rates" })],
    5_000,
  );
  assert.equal(next.positions.length, 1);
});

test("une news négative sur le titre peut fermer la ligne", () => {
  const next = step(
    holding(),
    [quote({ price: 100, trend: "neutre", sentiment: -70, headline: "Apple faces lawsuit and a downgrade" })],
    5_000,
  );
  assert.equal(next.positions.length, 0);
  assert.match(next.trades[0]?.reason ?? "", /Actualité/);
});

test("un short gagne si le cours baisse jusqu'à l'objectif", () => {
  const state = holding();
  state.positions[0] = { ...state.positions[0]!, side: "short", stop: 104, target: 90 };
  const next = step(state, [quote({ price: 90, trend: "baissiere", rsi: 40 })], 5_000);
  assert.equal(next.positions.length, 0);
  assert.ok((next.trades[0]?.pnl ?? 0) > 0);
});

test("un short est coupé si le cours touche le stop au-dessus", () => {
  const state = holding();
  state.positions[0] = { ...state.positions[0]!, side: "short", stop: 104, target: 90 };
  const next = step(state, [quote({ price: 105, trend: "haussiere", rsi: 60 })], 5_000);
  assert.equal(next.positions.length, 0);
  assert.ok((next.trades[0]?.pnl ?? 0) < 0);
});

test("au plafond, le bot vend la plus petite ligne américaine pour une place non couverte", () => {
  const state = holding();
  state.cash = 20;
  state.risk = { ...state.risk, profile: "eleve", stockSlots: 1, maxInvestedPct: 40, stockSizePct: 12, targetPct: 8 };
  state.marks = { AAPL: 102 };
  const europe = quote({
    symbol: "MC.PA",
    name: "LVMH",
    market: "Europe",
    currency: "EUR",
    price: 100,
    rsi: 45,
    sma20: 98,
    sma50: 90,
    volatility: 1,
    sentiment: 20,
    trend: "haussiere",
    changePercent: 0.4,
    volumeRatio: 1,
  });
  const next = step(state, [quote({ price: 102 }), europe], 5_000);
  assert.equal(next.positions.some((position) => position.symbol === "AAPL"), false);
  assert.equal(next.positions.some((position) => position.symbol === "MC.PA"), true);
});

test("un compte vide ne remplace pas un compte qui a des lignes", () => {
  const rich = holding();
  rich.cash = 20_000;
  rich.added = 100_000;
  const empty = freshPaper();
  assert.equal(accountDestroyed(rich, empty), true);
  assert.equal(accountDestroyed(rich, { ...empty, trades: rich.trades, cash: 20_000 }), false);
  assert.equal(accountDestroyed(empty, empty), false);
});
