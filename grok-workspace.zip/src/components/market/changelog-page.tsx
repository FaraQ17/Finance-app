import { MarketShell } from "@/components/market/shell";
import { CHANGELOG } from "@/lib/changelog";

export function ChangelogPage() {
  return (
    <MarketShell>
      <main className="mx-auto max-w-6xl px-4 py-6">
        <h1 className="text-2xl font-medium">Suivi</h1>
        <p className="mt-1 text-sm text-pretty text-muted">
          Historique des mises à jour et des améliorations de l'application, de la plus récente à la plus ancienne.
        </p>
        <ol className="mt-6 space-y-4">
          {CHANGELOG.map((change) => (
            <li key={`${change.date}-${change.title}`} className="rounded-2xl bg-panel p-4 shadow-card">
              <p className="font-mono text-xs text-brass">{change.date}</p>
              <h2 className="mt-1 text-lg font-medium">{change.title}</h2>
              <ul className="mt-2 space-y-1">
                {change.points.map((point) => (
                  <li key={point} className="text-sm text-pretty text-muted">
                    {point}
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ol>
      </main>
    </MarketShell>
  );
}
