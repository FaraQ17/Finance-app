import { useMemo, useState } from "react";
import { formatAxisPrice, formatAxisTime, formatPrice } from "@/lib/format";
import type { Candle, RangeKey } from "@/lib/universe";

function aggregate(candles: Candle[], max: number): Candle[] {
  if (candles.length <= max) return candles;
  const size = Math.ceil(candles.length / max);
  const out: Candle[] = [];
  for (let i = 0; i < candles.length; i += size) {
    const slice = candles.slice(i, i + size);
    const last = slice[slice.length - 1];
    const first = slice[0];
    if (!first || !last) continue;
    out.push({
      t: first.t,
      o: first.o,
      h: Math.max(...slice.map((candle) => candle.h)),
      l: Math.min(...slice.map((candle) => candle.l)),
      c: last.c,
      v: slice.reduce((sum, candle) => sum + candle.v, 0),
    });
  }
  return out;
}
const VB_W = 640;
const VB_H = 280;
const PAD_L = 8;
const PAD_R = 72;
const PAD_T = 14;
const PAD_B = 26;

export function PriceChart({
  candles,
  mode,
  range,
  currency,
}: {
  candles: Candle[];
  mode: "line" | "candle";
  range: RangeKey;
  currency: string;
}) {
  const points = useMemo(() => aggregate(candles, mode === "candle" ? 42 : 72), [candles, mode]);
  const [hover, setHover] = useState<number | null>(null);

  const model = useMemo(() => {
    if (points.length === 0) return null;
    let min = Math.min(...points.map((candle) => candle.l));
    let max = Math.max(...points.map((candle) => candle.h));
    if (min === max) {
      min -= Math.abs(min) * 0.01 || 1;
      max += Math.abs(max) * 0.01 || 1;
    }
    const pad = (max - min) * 0.1;
    min -= pad;
    max += pad;
    const innerW = VB_W - PAD_L - PAD_R;
    const innerH = VB_H - PAD_T - PAD_B;
    const y = (price: number) => PAD_T + ((max - price) / (max - min)) * innerH;
    const x = (index: number) =>
      PAD_L + (points.length === 1 ? innerW / 2 : (index / (points.length - 1)) * innerW);
    const volMax = Math.max(...points.map((candle) => candle.v), 1);
    const rising = (points[points.length - 1]?.c ?? 0) >= (points[0]?.c ?? 0);
    const line = points
      .map((candle, index) => `${index === 0 ? "M" : "L"}${x(index).toFixed(2)} ${y(candle.c).toFixed(2)}`)
      .join(" ");
    const area = `${line} L${x(points.length - 1).toFixed(2)} ${(PAD_T + innerH).toFixed(2)} L${x(0).toFixed(2)} ${(PAD_T + innerH).toFixed(2)} Z`;
    const ticks = [0, 0.5, 1].map((t) => max - t * (max - min));
    const slot = innerW / Math.max(points.length, 1);
    return { min, max, y, x, volMax, rising, line, area, ticks, slot, innerH };
  }, [points]);

  if (!model) {
    return (
      <p className="grid h-56 place-items-center text-sm text-muted lg:h-72">
        Pas assez de points pour cette période.
      </p>
    );
  }

  const active = hover != null ? points[hover] : null;
  const tone = model.rising ? "text-up" : "text-down";
  const labels = [0, Math.floor((points.length - 1) / 2), points.length - 1];

  function locate(clientX: number, width: number) {
    const rel = (clientX / width) * VB_W;
    let nearest = 0;
    let best = Number.POSITIVE_INFINITY;
    for (let i = 0; i < points.length; i += 1) {
      const dist = Math.abs(model!.x(i) - rel);
      if (dist < best) {
        best = dist;
        nearest = i;
      }
    }
    setHover(nearest);
  }

  return (
    <div className="relative">
      {active ? (
        <div className="pointer-events-none absolute top-2 left-2 z-10 rounded-lg bg-ink px-2 py-1 font-mono text-xs text-fg shadow-card">
          <p>
            {formatAxisTime(active.t, range)} · {formatPrice(active.c, currency)}
          </p>
          <p className="text-muted">
            O {formatPrice(active.o, currency)} · H {formatPrice(active.h, currency)} · min {formatPrice(active.l, currency)}
          </p>
        </div>
      ) : null}
      <svg
        viewBox={`0 0 ${VB_W} ${VB_H}`}
        className="h-56 w-full overflow-hidden lg:h-72"
        role="img"
        aria-label={`Graphique ${range}, dernier cours ${formatPrice(points[points.length - 1]?.c ?? 0, currency)}`}
        onPointerLeave={() => setHover(null)}
        onPointerMove={(event) => {
          const rect = event.currentTarget.getBoundingClientRect();
          locate(event.clientX - rect.left, rect.width);
        }}
      >
        {model.ticks.map((tick) => (
          <g key={tick}>
            <line
              x1={PAD_L}
              x2={VB_W - PAD_R}
              y1={model.y(tick)}
              y2={model.y(tick)}
              className="stroke-line"
              strokeWidth="1"
            />
            <text
              x={VB_W - 4}
              y={model.y(tick) + 4}
              textAnchor="end"
              className="fill-muted"
              fontSize="11"
              fontFamily="IBM Plex Mono, ui-monospace, monospace"
            >
              {formatAxisPrice(tick, currency)}
            </text>
          </g>
        ))}
        {points.map((candle, index) => {
          const base = PAD_T + model.innerH;
          const height = Math.max(1, (candle.v / model.volMax) * 22);
          return (
            <rect
              key={`v-${candle.t}`}
              x={model.x(index) - Math.max(1, model.slot * 0.3)}
              y={base - height}
              width={Math.max(1.2, model.slot * 0.55)}
              height={height}
              className="fill-line"
            />
          );
        })}
        {mode === "line" ? (
          <>
            <path d={model.area} className={model.rising ? "fill-up/15" : "fill-down/15"} />
            <path d={model.line} fill="none" className={tone} stroke="currentColor" strokeWidth="2" />
          </>
        ) : (
          points.map((candle, index) => {
            const up = candle.c >= candle.o;
            const bodyTop = model.y(Math.max(candle.o, candle.c));
            const bodyBot = model.y(Math.min(candle.o, candle.c));
            const bodyH = Math.max(1.2, bodyBot - bodyTop);
            const width = Math.max(2.2, Math.min(10, model.slot * 0.62));
            return (
              <g key={candle.t} className={up ? "text-up" : "text-down"}>
                <line
                  x1={model.x(index)}
                  x2={model.x(index)}
                  y1={model.y(candle.h)}
                  y2={model.y(candle.l)}
                  stroke="currentColor"
                  strokeWidth="1.2"
                />
                <rect
                  x={model.x(index) - width / 2}
                  y={bodyTop}
                  width={width}
                  height={bodyH}
                  fill="currentColor"
                />
              </g>
            );
          })
        )}
        {hover != null ? (
          <line
            x1={model.x(hover)}
            x2={model.x(hover)}
            y1={PAD_T}
            y2={PAD_T + model.innerH}
            className="stroke-brass"
            strokeWidth="1"
          />
        ) : null}
        {labels.map((index) => (
          <text
            key={`t-${index}`}
            x={model.x(index)}
            y={VB_H - 6}
            textAnchor={index === 0 ? "start" : index === candles.length - 1 ? "end" : "middle"}
            className="fill-muted"
            fontSize="11"
            fontFamily="IBM Plex Mono, ui-monospace, monospace"
          >
            {formatAxisTime(candles[index]?.t ?? 0, range)}
          </text>
        ))}
      </svg>
    </div>
  );
}
