import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/watchlist-CxDpRLcD.js
var DEFAULTS = [
	{
		symbol: "NVDA",
		name: "NVIDIA",
		kind: "stock"
	},
	{
		symbol: "AAPL",
		name: "Apple",
		kind: "stock"
	},
	{
		symbol: "MC.PA",
		name: "LVMH",
		kind: "stock"
	},
	{
		symbol: "BTC-USD",
		name: "Bitcoin",
		kind: "crypto"
	}
];
var useWatchlist = create()(persist((set, get) => ({
	items: DEFAULTS,
	has: (symbol) => get().items.some((item) => item.symbol === symbol),
	toggle: (item) => {
		set({ items: get().items.some((entry) => entry.symbol === item.symbol) ? get().items.filter((entry) => entry.symbol !== item.symbol) : [item, ...get().items].slice(0, 30) });
	}
}), {
	name: "vesper-watchlist",
	skipHydration: true,
	partialize: (state) => ({ items: state.items })
}));
//#endregion
export { useWatchlist as t };
