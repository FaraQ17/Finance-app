import { createFileRoute } from "@tanstack/react-router";
import { SentimentBoard } from "@/components/market/sentiment";

export const Route = createFileRoute("/sentiment")({
  component: SentimentBoard,
});
