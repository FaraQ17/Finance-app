//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DEeAwNpo.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/bot",
			"/favoris",
			"/sentiment",
			"/tendances"
		],
		preloads: ["/assets/index-XLZ2Sl78.js", "/assets/universe-CY2j3i7a.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-XLZ2Sl78.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Dw_vUarO.js",
			"/assets/format-BM5ww2ay.js",
			"/assets/arrow-up-right-Bc7XnJHt.js",
			"/assets/refresh-cw-CPfSVTQs.js",
			"/assets/watchlist-B7v2KLVX.js",
			"/assets/useMutation-zGkRjn0B.js"
		]
	},
	"/bot": {
		filePath: "/workspace/src/routes/bot.tsx",
		children: void 0,
		preloads: [
			"/assets/bot-qQWS_Jb7.js",
			"/assets/format-BM5ww2ay.js",
			"/assets/refresh-cw-CPfSVTQs.js"
		]
	},
	"/favoris": {
		filePath: "/workspace/src/routes/favoris.tsx",
		children: void 0,
		preloads: [
			"/assets/favoris-DmweoIjT.js",
			"/assets/format-BM5ww2ay.js",
			"/assets/watchlist-B7v2KLVX.js"
		]
	},
	"/sentiment": {
		filePath: "/workspace/src/routes/sentiment.tsx",
		children: void 0,
		preloads: [
			"/assets/sentiment-BDh54dg1.js",
			"/assets/format-BM5ww2ay.js",
			"/assets/refresh-cw-CPfSVTQs.js",
			"/assets/watchlist-B7v2KLVX.js",
			"/assets/useMutation-zGkRjn0B.js"
		]
	},
	"/tendances": {
		filePath: "/workspace/src/routes/tendances.tsx",
		children: void 0,
		preloads: [
			"/assets/tendances-BIICoqon.js",
			"/assets/format-BM5ww2ay.js",
			"/assets/arrow-up-right-Bc7XnJHt.js",
			"/assets/refresh-cw-CPfSVTQs.js",
			"/assets/watchlist-B7v2KLVX.js",
			"/assets/useMutation-zGkRjn0B.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
