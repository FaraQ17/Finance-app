import { useMutation, useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowUpRight, RefreshCw, Star } from "lucide-react";
import { MarketShell } from "@/components/market/shell";
import { formatPct, formatPrice, toneOf } from "@/lib/format";
import { getTrends, readTrendBoard } from "@/lib/market-api";
import type { Horizon, Kind, TrendRow } from "@/lib/universe";
import { useWatchlist } from "@/lib/watchlist";

const KINDS: { id: Kind; label: string }[] = [
  { id: "stock", label: "Actions" },
  { id: "crypto", label: "Crypto" },
];

const HORIZONS: { id: Horizon; label: string }[] = [
  { id: 1, label: "1 j" },
  { id: 5, label: "5 j" },
  { id: 10, label: "10 j" },
];

function toneClass(change: number): string {
  const tone = toneOf(change);
  if (tone === "up") return "text-up";
  if (tone === "down") return "text-down";
  return "text-muted";
}

function RankList({
  title,
  rows,
  down,
  watched,
  onToggle,
}: {
  title: string;
  rows: TrendRow[];
  down?: boolean;
  watched: (symbol: string) => boolean;
  onToggle: (row: TrendRow) => void;
}) {
  return (
    <section className="rounded-2xl bg-panel p-4 shadow-card sm:p-5">
      <h2 className={`text-xs font-medium tracking-widest uppercase ${down ? "text-down" : "text-up"}`}>{title}</h2>
      <ol className="mt-2">
        {rows.map((row, index) => (
          <li key={row.symbol} className="border-b border-line py-3 last:border-b-0">
            <div className="flex gap-2">
              <span className="w-5 pt-0.5 font-mono text-xs text-muted">{index + 1}</span>
              <div className="min-w-0 flex-1">
                <Link to="/" search={{ s: row.symbol }} className="flex items-baseline justify-between gap-3">
                  <span className="truncate text-sm">{row.name}</span>
                  <span className={`shrink-0 font-mono text-sm tabular-nums ${toneClass(row.changePercent)}`}>
                    {formatPct(row.changePercent)}
                  </span>
                </Link>
                <p className="font-mono text-xs text-muted">
                  {row.symbol.replace("-USD", "")} · {formatPrice(row.price, row.currency)}
                </p>
                {row.headline && row.headlineUrl ? (
                  <a
                    href={row.headlineUrl}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="mt-1 flex items-start gap-1 text-xs text-pretty text-muted hover:text-brass"
                  >
                    <span className="min-w-0">{row.headline}</span>
                    <ArrowUpRight className="mt-0.5 size-3 shrink-0" />
                  </a>
                ) : (
                  <p className="mt-1 text-xs text-muted">Pas de titre récent rattaché.</p>
                )}
              </div>
              <button
                type="button"
                onClick={() => onToggle(row)}
                aria-pressed={watched(row.symbol)}
                aria-label={watched(row.symbol) ? `Retirer ${row.name} des favoris` : `Ajouter ${row.name} aux favoris`}
                className="grid size-11 shrink-0 place-items-center"
              >
                <Star className={`size-4 ${watched(row.symbol) ? "fill-brass text-brass" : "text-muted"}`} />
              </button>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}

export function Trends({
  kind,
  horizon,
  onKind,
  onHorizon,
}: {
  kind: Kind;
  horizon: Horizon;
  onKind: (kind: Kind) => void;
  onHorizon: (horizon: Horizon) => void;
}) {
  const [mounted, setMounted] = useState(false);
  const favorites = useWatchlist((state) => state.items);
  const toggle = useWatchlist((state) => state.toggle);
  useEffect(() => {
    setMounted(true);
    void useWatchlist.persist.rehydrate();
  }, []);
  const watchSet = new Set(mounted ? favorites.map((item) => item.symbol) : []);

  const board = useQuery({
    queryKey: ["trends", kind, horizon],
    enabled: mounted,
    queryFn: () => getTrends({ data: { kind, horizon } }),
    staleTime: 60_000,
  });

  const read = useMutation({
    mutationFn: (force: boolean) => readTrendBoard({ data: { kind, horizon, force } }),
  });

  useEffect(() => {
    read.reset();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, horizon]);

  const note =
    kind === "stock"
      ? "Classement parmi les grandes valeurs liquides (États-Unis et Europe). 5 j et 10 j = séances de bourse."
      : "Classement parmi les cryptos majeures. 5 j et 10 j = jours calendaires.";

  return (
    <MarketShell>
      <main className="mx-auto max-w-6xl space-y-4 px-4 py-4 pb-24 lg:px-6">
        <div>
          <h1 className="text-2xl font-medium">Tendances</h1>
          <p className="mt-1 text-sm text-pretty text-muted">{note}</p>
        </div>

        <div className="flex flex-wrap gap-2">
          <div className="grid grid-cols-2 gap-1 rounded-xl bg-panel p-1 shadow-card" role="tablist" aria-label="Univers">
            {KINDS.map((item) => (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={kind === item.id}
                onClick={() => onKind(item.id)}
                className={`h-10 rounded-lg px-4 text-sm ${kind === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`}
              >
                {item.label}
              </button>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-1 rounded-xl bg-panel p-1 shadow-card" role="tablist" aria-label="Horizon">
            {HORIZONS.map((item) => (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={horizon === item.id}
                onClick={() => onHorizon(item.id)}
                className={`h-10 rounded-lg px-3 text-sm ${horizon === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        {board.isPending ? <p className="text-sm text-muted">Classement et titres d'actualité…</p> : null}
        {board.isError ? (
          <button type="button" onClick={() => board.refetch()} className="h-11 text-sm text-brass">
            Réessayer le classement
          </button>
        ) : null}

        {board.data ? (
          <>
            <p className="text-xs text-muted">{board.data.scanned} actifs comparés · toucher un nom ouvre le desk</p>
            <div className="grid gap-4 lg:grid-cols-2">
              <RankList
                title="10 meilleures"
                rows={board.data.best}
                watched={(symbol) => watchSet.has(symbol)}
                onToggle={(row) => toggle({ symbol: row.symbol, name: row.name, kind })}
              />
              <RankList
                title="10 moins bonnes"
                rows={board.data.worst}
                down
                watched={(symbol) => watchSet.has(symbol)}
                onToggle={(row) => toggle({ symbol: row.symbol, name: row.name, kind })}
              />
            </div>

            <section className="rounded-2xl bg-panel p-4 shadow-card sm:p-5">
              <div className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <h2 className="text-xs font-medium tracking-widest text-muted uppercase">Par rapport à l'actualité</h2>
                  <p className="mt-1 text-sm text-muted">Grok relie ce classement aux titres affichés. Rien ne part tout seul.</p>
                </div>
                <button
                  type="button"
                  disabled={read.isPending}
                  onClick={() => read.mutate(Boolean(read.data?.ok))}
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-brass px-4 text-sm font-medium text-ink disabled:opacity-60"
                >
                  {read.isPending ? <RefreshCw className="size-4 animate-spin" /> : null}
                  {read.data?.ok ? "Actualiser la lecture" : "Relier à l'actualité"}
                </button>
              </div>
              {read.isPending ? <p className="mt-3 text-sm text-muted">Lecture des titres du classement…</p> : null}
              {read.data && !read.data.ok ? (
                <p className="mt-3 text-sm text-down" role="alert">
                  {read.data.error}
                </p>
              ) : null}
              {read.data?.ok ? (
                <div className="mt-4 space-y-3 text-sm text-pretty">
                  <p>{read.data.lead}</p>
                  <div className="rounded-xl bg-up-soft p-3">
                    <p className="text-xs font-medium tracking-widest text-up uppercase">Haut du tableau</p>
                    <p className="mt-1">{read.data.winnersNote}</p>
                  </div>
                  <div className="rounded-xl bg-down-soft p-3">
                    <p className="text-xs font-medium tracking-widest text-down uppercase">Bas du tableau</p>
                    <p className="mt-1">{read.data.losersNote}</p>
                  </div>
                  {read.data.cached ? <p className="text-xs text-muted">Lecture conservée.</p> : null}
                </div>
              ) : null}
            </section>
          </>
        ) : null}
      </main>
    </MarketShell>
  );
}
