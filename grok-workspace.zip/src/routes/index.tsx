import { createFileRoute } from "@tanstack/react-router";
import { Desk } from "@/components/market/desk";
import { cleanSymbol, type Filter } from "@/lib/universe";

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>) => {
    const next: { s?: string; f?: Filter } = {};
    if (search.f === "stock" || search.f === "crypto" || search.f === "all") next.f = search.f;
    if (typeof search.s === "string") {
      const symbol = cleanSymbol(search.s);
      if (symbol) next.s = symbol;
    }
    return next;
  },
  component: Home,
});

function Home() {
  const search = Route.useSearch();
  const symbol = search.s ?? "NVDA";
  const filter: Filter = search.f ?? "all";
  const navigate = Route.useNavigate();
  return (
    <Desk
      symbol={symbol}
      filter={filter}
      onSymbol={(next) => {
        void navigate({ search: { s: next, f: filter }, resetScroll: false });
      }}
      onFilter={(next) => {
        void navigate({ search: { s: symbol, f: next }, resetScroll: false });
      }}
    />
  );
}
