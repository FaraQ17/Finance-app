//#region node_modules/.nitro/vite/services/ssr/assets/universe-7NGhBY7T.js
var BOT_UNIVERSE = [
	{
		symbol: "AAPL",
		name: "Apple",
		kind: "stock"
	},
	{
		symbol: "MSFT",
		name: "Microsoft",
		kind: "stock"
	},
	{
		symbol: "JNJ",
		name: "Johnson & Johnson",
		kind: "stock"
	},
	{
		symbol: "KO",
		name: "Coca-Cola",
		kind: "stock"
	},
	{
		symbol: "WMT",
		name: "Walmart",
		kind: "stock"
	},
	{
		symbol: "JPM",
		name: "JPMorgan",
		kind: "stock"
	},
	{
		symbol: "V",
		name: "Visa",
		kind: "stock"
	},
	{
		symbol: "COST",
		name: "Costco",
		kind: "stock"
	},
	{
		symbol: "HD",
		name: "Home Depot",
		kind: "stock"
	},
	{
		symbol: "XOM",
		name: "Exxon",
		kind: "stock"
	},
	{
		symbol: "PG",
		name: "Procter & Gamble",
		kind: "stock"
	},
	{
		symbol: "PEP",
		name: "PepsiCo",
		kind: "stock"
	},
	{
		symbol: "BTC-USD",
		name: "Bitcoin",
		kind: "crypto"
	},
	{
		symbol: "ETH-USD",
		name: "Ethereum",
		kind: "crypto"
	}
];
var UNIVERSE = [
	{
		symbol: "AAPL",
		name: "Apple",
		kind: "stock"
	},
	{
		symbol: "NVDA",
		name: "NVIDIA",
		kind: "stock"
	},
	{
		symbol: "MSFT",
		name: "Microsoft",
		kind: "stock"
	},
	{
		symbol: "TSLA",
		name: "Tesla",
		kind: "stock"
	},
	{
		symbol: "AMZN",
		name: "Amazon",
		kind: "stock"
	},
	{
		symbol: "GOOGL",
		name: "Alphabet",
		kind: "stock"
	},
	{
		symbol: "META",
		name: "Meta",
		kind: "stock"
	},
	{
		symbol: "MC.PA",
		name: "LVMH",
		kind: "stock"
	},
	{
		symbol: "AIR.PA",
		name: "Airbus",
		kind: "stock"
	},
	{
		symbol: "TTE.PA",
		name: "TotalEnergies",
		kind: "stock"
	},
	{
		symbol: "OR.PA",
		name: "L'Oréal",
		kind: "stock"
	},
	{
		symbol: "SAN.PA",
		name: "Sanofi",
		kind: "stock"
	},
	{
		symbol: "BTC-USD",
		name: "Bitcoin",
		kind: "crypto"
	},
	{
		symbol: "ETH-USD",
		name: "Ethereum",
		kind: "crypto"
	},
	{
		symbol: "SOL-USD",
		name: "Solana",
		kind: "crypto"
	},
	{
		symbol: "XRP-USD",
		name: "XRP",
		kind: "crypto"
	},
	{
		symbol: "BNB-USD",
		name: "BNB",
		kind: "crypto"
	},
	{
		symbol: "DOGE-USD",
		name: "Dogecoin",
		kind: "crypto"
	}
];
var BOARD_STOCKS = [
	{
		symbol: "AAPL",
		name: "Apple",
		kind: "stock"
	},
	{
		symbol: "MSFT",
		name: "Microsoft",
		kind: "stock"
	},
	{
		symbol: "NVDA",
		name: "NVIDIA",
		kind: "stock"
	},
	{
		symbol: "AMZN",
		name: "Amazon",
		kind: "stock"
	},
	{
		symbol: "GOOGL",
		name: "Alphabet",
		kind: "stock"
	},
	{
		symbol: "META",
		name: "Meta",
		kind: "stock"
	},
	{
		symbol: "TSLA",
		name: "Tesla",
		kind: "stock"
	},
	{
		symbol: "AVGO",
		name: "Broadcom",
		kind: "stock"
	},
	{
		symbol: "JPM",
		name: "JPMorgan",
		kind: "stock"
	},
	{
		symbol: "V",
		name: "Visa",
		kind: "stock"
	},
	{
		symbol: "UNH",
		name: "UnitedHealth",
		kind: "stock"
	},
	{
		symbol: "XOM",
		name: "Exxon",
		kind: "stock"
	},
	{
		symbol: "LLY",
		name: "Eli Lilly",
		kind: "stock"
	},
	{
		symbol: "JNJ",
		name: "Johnson & Johnson",
		kind: "stock"
	},
	{
		symbol: "WMT",
		name: "Walmart",
		kind: "stock"
	},
	{
		symbol: "MA",
		name: "Mastercard",
		kind: "stock"
	},
	{
		symbol: "HD",
		name: "Home Depot",
		kind: "stock"
	},
	{
		symbol: "COST",
		name: "Costco",
		kind: "stock"
	},
	{
		symbol: "NFLX",
		name: "Netflix",
		kind: "stock"
	},
	{
		symbol: "AMD",
		name: "AMD",
		kind: "stock"
	},
	{
		symbol: "CRM",
		name: "Salesforce",
		kind: "stock"
	},
	{
		symbol: "ORCL",
		name: "Oracle",
		kind: "stock"
	},
	{
		symbol: "BAC",
		name: "Bank of America",
		kind: "stock"
	},
	{
		symbol: "KO",
		name: "Coca-Cola",
		kind: "stock"
	},
	{
		symbol: "DIS",
		name: "Disney",
		kind: "stock"
	},
	{
		symbol: "INTC",
		name: "Intel",
		kind: "stock"
	},
	{
		symbol: "QCOM",
		name: "Qualcomm",
		kind: "stock"
	},
	{
		symbol: "AMAT",
		name: "Applied Materials",
		kind: "stock"
	},
	{
		symbol: "PLTR",
		name: "Palantir",
		kind: "stock"
	},
	{
		symbol: "ASML",
		name: "ASML",
		kind: "stock"
	},
	{
		symbol: "MC.PA",
		name: "LVMH",
		kind: "stock"
	},
	{
		symbol: "AIR.PA",
		name: "Airbus",
		kind: "stock"
	},
	{
		symbol: "TTE.PA",
		name: "TotalEnergies",
		kind: "stock"
	},
	{
		symbol: "OR.PA",
		name: "L'Oréal",
		kind: "stock"
	},
	{
		symbol: "SAN.PA",
		name: "Sanofi",
		kind: "stock"
	},
	{
		symbol: "AI.PA",
		name: "Air Liquide",
		kind: "stock"
	},
	{
		symbol: "BNP.PA",
		name: "BNP Paribas",
		kind: "stock"
	},
	{
		symbol: "RMS.PA",
		name: "Hermès",
		kind: "stock"
	},
	{
		symbol: "SU.PA",
		name: "Schneider",
		kind: "stock"
	},
	{
		symbol: "SAP.DE",
		name: "SAP",
		kind: "stock"
	},
	{
		symbol: "SIE.DE",
		name: "Siemens",
		kind: "stock"
	},
	{
		symbol: "NESN.SW",
		name: "Nestlé",
		kind: "stock"
	},
	{
		symbol: "NOVN.SW",
		name: "Novartis",
		kind: "stock"
	}
];
var BOARD_CRYPTOS = [
	{
		symbol: "BTC-USD",
		name: "Bitcoin",
		kind: "crypto"
	},
	{
		symbol: "ETH-USD",
		name: "Ethereum",
		kind: "crypto"
	},
	{
		symbol: "SOL-USD",
		name: "Solana",
		kind: "crypto"
	},
	{
		symbol: "XRP-USD",
		name: "XRP",
		kind: "crypto"
	},
	{
		symbol: "BNB-USD",
		name: "BNB",
		kind: "crypto"
	},
	{
		symbol: "DOGE-USD",
		name: "Dogecoin",
		kind: "crypto"
	},
	{
		symbol: "ADA-USD",
		name: "Cardano",
		kind: "crypto"
	},
	{
		symbol: "AVAX-USD",
		name: "Avalanche",
		kind: "crypto"
	},
	{
		symbol: "LINK-USD",
		name: "Chainlink",
		kind: "crypto"
	},
	{
		symbol: "TON-USD",
		name: "Toncoin",
		kind: "crypto"
	},
	{
		symbol: "LTC-USD",
		name: "Litecoin",
		kind: "crypto"
	},
	{
		symbol: "TRX-USD",
		name: "TRON",
		kind: "crypto"
	},
	{
		symbol: "DOT-USD",
		name: "Polkadot",
		kind: "crypto"
	},
	{
		symbol: "NEAR-USD",
		name: "NEAR",
		kind: "crypto"
	},
	{
		symbol: "ATOM-USD",
		name: "Cosmos",
		kind: "crypto"
	},
	{
		symbol: "SHIB-USD",
		name: "Shiba Inu",
		kind: "crypto"
	},
	{
		symbol: "BCH-USD",
		name: "Bitcoin Cash",
		kind: "crypto"
	},
	{
		symbol: "FIL-USD",
		name: "Filecoin",
		kind: "crypto"
	},
	{
		symbol: "ICP-USD",
		name: "Internet Computer",
		kind: "crypto"
	},
	{
		symbol: "INJ-USD",
		name: "Injective",
		kind: "crypto"
	},
	{
		symbol: "AAVE-USD",
		name: "Aave",
		kind: "crypto"
	},
	{
		symbol: "HBAR-USD",
		name: "Hedera",
		kind: "crypto"
	},
	{
		symbol: "XLM-USD",
		name: "Stellar",
		kind: "crypto"
	},
	{
		symbol: "ARB-USD",
		name: "Arbitrum",
		kind: "crypto"
	},
	{
		symbol: "OP-USD",
		name: "Optimism",
		kind: "crypto"
	}
];
var CRYPTO_ALIASES = {
	BTC: {
		symbol: "BTC-USD",
		name: "Bitcoin"
	},
	BITCOIN: {
		symbol: "BTC-USD",
		name: "Bitcoin"
	},
	ETH: {
		symbol: "ETH-USD",
		name: "Ethereum"
	},
	ETHEREUM: {
		symbol: "ETH-USD",
		name: "Ethereum"
	},
	SOL: {
		symbol: "SOL-USD",
		name: "Solana"
	},
	SOLANA: {
		symbol: "SOL-USD",
		name: "Solana"
	},
	XRP: {
		symbol: "XRP-USD",
		name: "XRP"
	},
	DOGE: {
		symbol: "DOGE-USD",
		name: "Dogecoin"
	},
	DOGECOIN: {
		symbol: "DOGE-USD",
		name: "Dogecoin"
	},
	ADA: {
		symbol: "ADA-USD",
		name: "Cardano"
	},
	CARDANO: {
		symbol: "ADA-USD",
		name: "Cardano"
	},
	AVAX: {
		symbol: "AVAX-USD",
		name: "Avalanche"
	},
	BNB: {
		symbol: "BNB-USD",
		name: "BNB"
	},
	DOT: {
		symbol: "DOT-USD",
		name: "Polkadot"
	},
	LINK: {
		symbol: "LINK-USD",
		name: "Chainlink"
	},
	TON: {
		symbol: "TON-USD",
		name: "Toncoin"
	},
	LTC: {
		symbol: "LTC-USD",
		name: "Litecoin"
	},
	SUI: {
		symbol: "SUI-USD",
		name: "Sui"
	},
	TRX: {
		symbol: "TRX-USD",
		name: "TRON"
	},
	NEAR: {
		symbol: "NEAR-USD",
		name: "NEAR"
	},
	APT: {
		symbol: "APT-USD",
		name: "Aptos"
	}
};
var DISCLAIMER = "Ceci n'est pas un conseil en investissement. Analyse générée par IA à titre informatif uniquement.";
function cleanSymbol(input) {
	const symbol = input.trim().toUpperCase().replace(/\s+/g, "");
	if (!/^[A-Z0-9][A-Z0-9.\-]{0,14}$/.test(symbol)) return null;
	return symbol;
}
function universeBySymbol(symbol) {
	return UNIVERSE.find((item) => item.symbol === symbol);
}
//#endregion
export { DISCLAIMER as a, universeBySymbol as c, CRYPTO_ALIASES as i, BOARD_STOCKS as n, UNIVERSE as o, BOT_UNIVERSE as r, cleanSymbol as s, BOARD_CRYPTOS as t };
