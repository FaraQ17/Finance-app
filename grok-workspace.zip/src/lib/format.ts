import type { Kind } from "@/lib/universe";

export function formatAxisPrice(value: number, currency: string): string {
  const abs = Math.abs(value);
  const suffix = currency === "EUR" ? "€" : currency === "GBP" || currency === "GBp" ? "£" : "$";
  if (abs >= 10_000) {
    const compact = new Intl.NumberFormat("fr-FR", {
      notation: "compact",
      maximumFractionDigits: 1,
    }).format(value);
    return `${compact} ${suffix}`;
  }
  if (abs >= 100) {
    return `${new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 }).format(value)} ${suffix}`;
  }
  return formatPrice(value, currency);
}

export function formatPrice(value: number, currency: string): string {
  const abs = Math.abs(value);
  const digits = abs >= 1 ? 2 : abs >= 0.01 ? 4 : abs >= 0.0001 ? 6 : 8;
  const formatted = new Intl.NumberFormat("fr-FR", {
    minimumFractionDigits: Math.min(2, digits),
    maximumFractionDigits: digits,
  }).format(value);
  if (currency === "EUR") return `${formatted} €`;
  if (currency === "GBP" || currency === "GBp") return `${formatted} £`;
  if (currency === "USD" || currency === "") return `${formatted} $`;
  return `${formatted} ${currency}`;
}

export function formatPct(value: number): string {
  const sign = value > 0 ? "+" : "";
  const body = new Intl.NumberFormat("fr-FR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
  return `${sign}${body} %`;
}

export function formatSignedPrice(value: number, currency: string): string {
  const sign = value > 0 ? "+" : value < 0 ? "−" : "";
  return `${sign}${formatPrice(Math.abs(value), currency)}`;
}

export function formatVolume(value: number): string {
  return new Intl.NumberFormat("fr-FR", {
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(value);
}

export function formatWhen(unixSec: number): string {
  const diff = Date.now() - unixSec * 1000;
  const min = Math.round(diff / 60_000);
  if (!Number.isFinite(min)) return "";
  if (min < 1) return "à l'instant";
  if (min < 60) return `il y a ${min} min`;
  const hours = Math.round(min / 60);
  if (hours < 24) return `il y a ${hours} h`;
  const days = Math.round(hours / 24);
  if (days < 7) return `il y a ${days} j`;
  return new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "short" }).format(
    new Date(unixSec * 1000),
  );
}

export function formatClock(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit" }).format(date);
}

export function formatAxisTime(unixSec: number, range: "1d" | "7d" | "30d"): string {
  const date = new Date(unixSec * 1000);
  if (range === "1d") {
    return new Intl.DateTimeFormat("fr-FR", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Europe/Paris",
    }).format(date);
  }
  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    timeZone: "Europe/Paris",
  }).format(date);
}

export function formatPlace(exchange: string, kind: Kind): string {
  if (kind === "crypto") return "Cours continu";
  const known: Record<string, string> = {
    NasdaqGS: "Nasdaq",
    NMS: "Nasdaq",
    NYQ: "NYSE",
    NYSE: "NYSE",
    PCX: "NYSE Arca",
    Paris: "Euronext Paris",
    PAR: "Euronext Paris",
  };
  return known[exchange] ?? (exchange || "Marché");
}

export function toneOf(change: number): "up" | "down" | "flat" {
  if (change > 0.004) return "up";
  if (change < -0.004) return "down";
  return "flat";
}
