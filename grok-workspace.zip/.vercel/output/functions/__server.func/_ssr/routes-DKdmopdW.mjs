import { i as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { a as DISCLAIMER, i as CRYPTO_ALIASES, s as cleanSymbol } from "./universe-7NGhBY7T.mjs";
import { E as toneOf, T as searchAssets, _ as getOverview, a as formatAxisPrice, c as formatPct, d as formatSignedPrice, f as formatVolume, g as getChart, l as formatPlace, m as getAsset, o as formatAxisTime, p as formatWhen, r as analyzeAsset, s as formatClock, t as MarketShell, u as formatPrice, v as getQuotes } from "./format-UWdJjcXe.mjs";
import { a as Search, c as ChartCandlestick, i as Star, l as ArrowUpRight, n as TrendingUp, o as RefreshCw, r as TrendingDown, s as ChartLine } from "../_libs/lucide-react.mjs";
import { t as useWatchlist } from "./watchlist-CxDpRLcD.mjs";
import { r as Route$4 } from "./router-Cjz9k9o2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DKdmopdW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function aggregate(candles, max) {
	if (candles.length <= max) return candles;
	const size = Math.ceil(candles.length / max);
	const out = [];
	for (let i = 0; i < candles.length; i += size) {
		const slice = candles.slice(i, i + size);
		const last = slice[slice.length - 1];
		const first = slice[0];
		if (!first || !last) continue;
		out.push({
			t: first.t,
			o: first.o,
			h: Math.max(...slice.map((candle) => candle.h)),
			l: Math.min(...slice.map((candle) => candle.l)),
			c: last.c,
			v: slice.reduce((sum, candle) => sum + candle.v, 0)
		});
	}
	return out;
}
var VB_W = 640;
var VB_H = 280;
var PAD_L = 8;
var PAD_T = 14;
function PriceChart({ candles, mode, range, currency }) {
	const points = (0, import_react.useMemo)(() => aggregate(candles, mode === "candle" ? 42 : 72), [candles, mode]);
	const [hover, setHover] = (0, import_react.useState)(null);
	const model = (0, import_react.useMemo)(() => {
		if (points.length === 0) return null;
		let min = Math.min(...points.map((candle) => candle.l));
		let max = Math.max(...points.map((candle) => candle.h));
		if (min === max) {
			min -= Math.abs(min) * .01 || 1;
			max += Math.abs(max) * .01 || 1;
		}
		const pad = (max - min) * .1;
		min -= pad;
		max += pad;
		const innerW = 560;
		const innerH = 240;
		const y = (price) => PAD_T + (max - price) / (max - min) * innerH;
		const x = (index) => PAD_L + (points.length === 1 ? innerW / 2 : index / (points.length - 1) * innerW);
		const volMax = Math.max(...points.map((candle) => candle.v), 1);
		const rising = (points[points.length - 1]?.c ?? 0) >= (points[0]?.c ?? 0);
		const line = points.map((candle, index) => `${index === 0 ? "M" : "L"}${x(index).toFixed(2)} ${y(candle.c).toFixed(2)}`).join(" ");
		const area = `${line} L${x(points.length - 1).toFixed(2)} ${254 .toFixed(2)} L${x(0).toFixed(2)} ${254 .toFixed(2)} Z`;
		const ticks = [
			0,
			.5,
			1
		].map((t) => max - t * (max - min));
		const slot = innerW / Math.max(points.length, 1);
		return {
			min,
			max,
			y,
			x,
			volMax,
			rising,
			line,
			area,
			ticks,
			slot,
			innerH
		};
	}, [points]);
	if (!model) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "grid h-56 place-items-center text-sm text-muted lg:h-72",
		children: "Pas assez de points pour cette période."
	});
	const active = hover != null ? points[hover] : null;
	const tone = model.rising ? "text-up" : "text-down";
	const labels = [
		0,
		Math.floor((points.length - 1) / 2),
		points.length - 1
	];
	function locate(clientX, width) {
		const rel = clientX / width * VB_W;
		let nearest = 0;
		let best = Number.POSITIVE_INFINITY;
		for (let i = 0; i < points.length; i += 1) {
			const dist = Math.abs(model.x(i) - rel);
			if (dist < best) {
				best = dist;
				nearest = i;
			}
		}
		setHover(nearest);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute top-2 left-2 z-10 rounded-lg bg-ink px-2 py-1 font-mono text-xs text-fg shadow-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				formatAxisTime(active.t, range),
				" · ",
				formatPrice(active.c, currency)
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted",
				children: [
					"O ",
					formatPrice(active.o, currency),
					" · H ",
					formatPrice(active.h, currency),
					" · min ",
					formatPrice(active.l, currency)
				]
			})]
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: `0 0 ${VB_W} ${VB_H}`,
			className: "h-56 w-full overflow-hidden lg:h-72",
			role: "img",
			"aria-label": `Graphique ${range}, dernier cours ${formatPrice(points[points.length - 1]?.c ?? 0, currency)}`,
			onPointerLeave: () => setHover(null),
			onPointerMove: (event) => {
				const rect = event.currentTarget.getBoundingClientRect();
				locate(event.clientX - rect.left, rect.width);
			},
			children: [
				model.ticks.map((tick) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: PAD_L,
					x2: 568,
					y1: model.y(tick),
					y2: model.y(tick),
					className: "stroke-line",
					strokeWidth: "1"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: 636,
					y: model.y(tick) + 4,
					textAnchor: "end",
					className: "fill-muted",
					fontSize: "11",
					fontFamily: "IBM Plex Mono, ui-monospace, monospace",
					children: formatAxisPrice(tick, currency)
				})] }, tick)),
				points.map((candle, index) => {
					const base = PAD_T + model.innerH;
					const height = Math.max(1, candle.v / model.volMax * 22);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: model.x(index) - Math.max(1, model.slot * .3),
						y: base - height,
						width: Math.max(1.2, model.slot * .55),
						height,
						className: "fill-line"
					}, `v-${candle.t}`);
				}),
				mode === "line" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: model.area,
					className: model.rising ? "fill-up/15" : "fill-down/15"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: model.line,
					fill: "none",
					className: tone,
					stroke: "currentColor",
					strokeWidth: "2"
				})] }) : points.map((candle, index) => {
					const up = candle.c >= candle.o;
					const bodyTop = model.y(Math.max(candle.o, candle.c));
					const bodyBot = model.y(Math.min(candle.o, candle.c));
					const bodyH = Math.max(1.2, bodyBot - bodyTop);
					const width = Math.max(2.2, Math.min(10, model.slot * .62));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
						className: up ? "text-up" : "text-down",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: model.x(index),
							x2: model.x(index),
							y1: model.y(candle.h),
							y2: model.y(candle.l),
							stroke: "currentColor",
							strokeWidth: "1.2"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: model.x(index) - width / 2,
							y: bodyTop,
							width,
							height: bodyH,
							fill: "currentColor"
						})]
					}, candle.t);
				}),
				hover != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: model.x(hover),
					x2: model.x(hover),
					y1: PAD_T,
					y2: PAD_T + model.innerH,
					className: "stroke-brass",
					strokeWidth: "1"
				}) : null,
				labels.map((index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: model.x(index),
					y: 274,
					textAnchor: index === 0 ? "start" : index === candles.length - 1 ? "end" : "middle",
					className: "fill-muted",
					fontSize: "11",
					fontFamily: "IBM Plex Mono, ui-monospace, monospace",
					children: formatAxisTime(candles[index]?.t ?? 0, range)
				}, `t-${index}`))
			]
		})]
	});
}
var RANGES = [
	{
		id: "1d",
		label: "1 j"
	},
	{
		id: "7d",
		label: "7 j"
	},
	{
		id: "30d",
		label: "30 j"
	}
];
var FILTERS = [
	{
		id: "all",
		label: "Tout"
	},
	{
		id: "stock",
		label: "Actions"
	},
	{
		id: "crypto",
		label: "Crypto"
	}
];
function toneClass(tone, soft = false) {
	if (tone === "up") return soft ? "bg-up-soft text-up" : "text-up";
	if (tone === "down") return soft ? "bg-down-soft text-down" : "text-down";
	return soft ? "bg-panel-2 text-muted" : "text-muted";
}
function Sparkline({ values, up }) {
	if (values.length < 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-6 w-16" });
	const min = Math.min(...values);
	const span = Math.max(...values) - min || 1;
	const d = values.map((value, index) => {
		const x = index / (values.length - 1) * 64;
		const y = 22 - (value - min) / span * 18;
		return `${index === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
	}).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 64 24",
		className: `h-6 w-16 ${up ? "text-up" : "text-down"}`,
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d,
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.6",
			strokeLinejoin: "round",
			strokeLinecap: "round"
		})
	});
}
function QuoteRow({ quote, active, watched, onSelect, onToggle, layout }) {
	const pending = "pending" in quote;
	const tone = pending ? "flat" : toneOf(quote.changePercent);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-stretch bg-panel shadow-card ${layout === "chip" ? "min-w-44 shrink-0 rounded-xl" : "rounded-xl"} ${active ? "ring-1 ring-brass" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onSelect,
			className: `min-w-0 flex-1 text-left ${layout === "chip" ? "px-3 py-2.5" : "px-3 py-3"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate font-mono text-xs text-brass",
						children: quote.symbol.replace("-USD", "")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: pending ? quote.kind === "crypto" ? "Crypto" : "Action" : quote.badge
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block truncate text-sm",
					children: quote.name
				}),
				pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block text-xs text-muted",
					children: "Cours…"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-1 flex items-end justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-sm tabular-nums",
						children: formatPrice(quote.price, quote.currency)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `font-mono text-xs tabular-nums ${toneClass(tone)}`,
						children: formatPct(quote.changePercent)
					})]
				}),
				!pending && layout === "row" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-2 flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
						values: quote.spark,
						up: tone !== "down"
					})
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onToggle,
			"aria-pressed": watched,
			"aria-label": watched ? `Retirer ${quote.name} des favoris` : `Ajouter ${quote.name} aux favoris`,
			className: "grid w-11 shrink-0 place-items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `size-4 ${watched ? "fill-brass text-brass" : "text-muted"}` })
		})]
	});
}
function readSession(symbol, term) {
	try {
		const raw = sessionStorage.getItem(`vesper-ai:${symbol}:${term}`);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed.savedAt || Date.now() - parsed.savedAt > 18e5) return null;
		if (parsed.symbol !== symbol || (parsed.term ?? "court") !== term) return null;
		return parsed;
	} catch {
		return null;
	}
}
function writeSession(analysis) {
	const term = analysis.term ?? "court";
	sessionStorage.setItem(`vesper-ai:${analysis.symbol}:${term}`, JSON.stringify({
		...analysis,
		term,
		savedAt: Date.now()
	}));
}
var TERMS = [
	{
		id: "court",
		label: "Court",
		hint: "prochains jours"
	},
	{
		id: "moyen",
		label: "Moyen",
		hint: "1 à 3 mois"
	},
	{
		id: "long",
		label: "Long",
		hint: "6 à 18 mois"
	}
];
var SENTIMENT_LABEL = {
	positif: "Positif",
	neutre: "Neutre",
	negatif: "Négatif"
};
var RISK_LABEL = {
	faible: "Faible",
	modere: "Modéré",
	eleve: "Élevé"
};
var KIND_LABEL = {
	web: "Web",
	x: "X",
	marche: "Fil de marché"
};
function AnalysisPanel({ symbol, name }) {
	const [term, setTerm] = (0, import_react.useState)("court");
	const [stored, setStored] = (0, import_react.useState)(null);
	const mutation = useMutation({
		mutationFn: (force) => analyzeAsset({ data: {
			symbol,
			force,
			term
		} }),
		onSuccess: (result) => {
			if (result.ok) {
				writeSession(result);
				setStored(result);
			}
		}
	});
	(0, import_react.useEffect)(() => {
		setStored(readSession(symbol, term));
		mutation.reset();
	}, [symbol, term]);
	const result = mutation.data?.ok ? mutation.data : stored;
	const error = mutation.data && !mutation.data.ok ? mutation.data.error : mutation.error ? "Analyse impossible." : null;
	const score = result?.sentimentScore ?? 0;
	const hint = TERMS.find((item) => item.id === term)?.hint ?? "prochains jours";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl bg-panel p-4 shadow-card sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium tracking-widest text-muted uppercase",
					children: "Lecture Grok"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"Cours et actualités de ",
						name,
						", sur l'horizon choisi."
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: mutation.isPending,
					onClick: () => mutation.mutate(Boolean(result)),
					className: "inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-brass px-4 text-sm font-medium text-ink disabled:opacity-60",
					children: [mutation.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" }), result ? "Actualiser l'analyse" : "Analyser avec Grok"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-3 gap-1 rounded-xl bg-ink p-1",
				role: "tablist",
				"aria-label": "Horizon",
				children: TERMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": term === item.id,
					onClick: () => setTerm(item.id),
					className: `h-10 rounded-lg text-sm ${term === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`,
					children: item.label
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-muted",
				children: [
					"Horizon : ",
					hint,
					". Le sentiment et la confiance portent sur les news de cette fenêtre."
				]
			}),
			mutation.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: "Lecture du cours, des actualités web et des échanges sur X…"
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-down",
				role: "alert",
				children: error
			}) : null,
			!result && !mutation.isPending && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-pretty text-muted",
				children: "L'analyse ne se lance pas toute seule. Elle croise le cours et les news, puis donne le sentiment et la confiance sur l'horizon choisi."
			}) : null,
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg text-pretty text-fg",
						children: result.outlook
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							result.cached ? "Lecture conservée" : "Lecture fraîche",
							" · ",
							formatClock(result.generatedAt),
							" · ",
							DISCLAIMER
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-panel-2 p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted",
										children: ["Confiance · ", hint]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 font-mono text-2xl tabular-nums text-brass",
										children: [result.confidence, " %"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 h-1.5 overflow-hidden rounded-full bg-ink",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-full bg-brass",
											style: { width: `${result.confidence}%` }
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-panel-2 p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: "Sentiment des news"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 font-mono text-2xl tabular-nums",
										children: [score > 0 ? "+" : "", score]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm",
										children: SENTIMENT_LABEL[result.sentiment]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "relative mt-2 h-1.5 rounded-full bg-ink",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `absolute top-0 h-full ${score >= 0 ? "left-1/2 bg-up" : "bg-down"}`,
											style: score >= 0 ? { width: `${score / 2}%` } : {
												width: `${Math.abs(score) / 2}%`,
												right: "50%"
											}
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-panel-2 p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: "Niveau de risque"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `mt-1 text-2xl ${result.risk === "eleve" ? "text-down" : result.risk === "faible" ? "text-up" : "text-brass"}`,
										children: RISK_LABEL[result.risk]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-pretty text-muted",
										children: result.riskNote
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-up-soft p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 text-sm font-medium text-up",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4" }), "Arguments haussiers"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-2 space-y-2 text-sm",
								children: [result.bullish.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "text-muted",
									children: "Pas d'argument net."
								}) : null, result.bullish.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-down-soft p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 text-sm font-medium text-down",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "size-4" }), "Arguments baissiers"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-2 space-y-2 text-sm",
								children: [result.bearish.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "text-muted",
									children: "Pas d'argument net."
								}) : null, result.bearish.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))]
							})]
						})]
					}),
					result.summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xs font-medium tracking-widest text-muted uppercase",
						children: "Résumé"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-pretty",
						children: result.summary
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xs font-medium tracking-widest text-muted uppercase",
						children: "Sources utilisées"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 divide-y divide-line",
						children: [result.sources.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-2 text-sm text-muted",
							children: "Aucune source citée."
						}) : null, result.sources.map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: source.url,
								target: "_blank",
								rel: "noreferrer noopener",
								className: "group flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block truncate text-sm group-hover:text-brass",
										children: source.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted",
										children: [
											source.publisher,
											" · ",
											KIND_LABEL[source.kind]
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "mt-0.5 size-4 shrink-0 text-muted" })]
							})
						}, source.url))]
					})] })
				]
			}) : null
		]
	});
}
function Desk({ symbol, filter, onSymbol, onFilter }) {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const [debounced, setDebounced] = (0, import_react.useState)("");
	const [searchOpen, setSearchOpen] = (0, import_react.useState)(false);
	const [range, setRange] = (0, import_react.useState)("1d");
	const [mode, setMode] = (0, import_react.useState)("line");
	const firstSymbol = (0, import_react.useRef)(true);
	const items = useWatchlist((state) => state.items);
	const toggle = useWatchlist((state) => state.toggle);
	const watchSet = (0, import_react.useMemo)(() => new Set(items.map((item) => item.symbol)), [items]);
	(0, import_react.useEffect)(() => {
		setMounted(true);
		useWatchlist.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		const timer = window.setTimeout(() => setDebounced(query.trim()), 280);
		return () => window.clearTimeout(timer);
	}, [query]);
	(0, import_react.useEffect)(() => {
		if (firstSymbol.current) {
			firstSymbol.current = false;
			return;
		}
		if (window.innerWidth >= 1024) return;
		document.getElementById("actif")?.scrollIntoView({ block: "start" });
	}, [symbol]);
	const overview = useQuery({
		queryKey: ["overview"],
		enabled: mounted,
		queryFn: () => getOverview(),
		refetchInterval: 6e4
	});
	const known = new Set((overview.data?.quotes ?? []).map((quote) => quote.symbol));
	const missing = items.map((item) => item.symbol).filter((item) => overview.isSuccess && !known.has(item));
	const extras = useQuery({
		queryKey: ["quotes", missing],
		enabled: mounted && missing.length > 0,
		queryFn: () => getQuotes({ data: { symbols: missing } })
	});
	const quoteMap = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const quote of overview.data?.quotes ?? []) map.set(quote.symbol, quote);
		for (const quote of extras.data?.quotes ?? []) map.set(quote.symbol, quote);
		return map;
	}, [overview.data, extras.data]);
	const asset = useQuery({
		queryKey: ["asset", symbol],
		enabled: mounted,
		queryFn: () => getAsset({ data: { symbol } }),
		refetchInterval: 6e4
	});
	const chart = useQuery({
		queryKey: [
			"chart",
			symbol,
			range
		],
		enabled: mounted,
		queryFn: () => getChart({ data: {
			symbol,
			range
		} })
	});
	const search = useQuery({
		queryKey: ["search", debounced],
		enabled: mounted && debounced.length > 0,
		queryFn: () => searchAssets({ data: { q: debounced } })
	});
	const visibleWatch = items.filter((item) => filter === "all" || item.kind === filter);
	const rest = (overview.data?.quotes ?? []).filter((quote) => (filter === "all" || quote.kind === filter) && !watchSet.has(quote.symbol));
	function selectSymbol(next) {
		onSymbol(next);
		setSearchOpen(false);
		setQuery("");
	}
	function submitSearch() {
		const alias = CRYPTO_ALIASES[query.trim().toUpperCase()];
		if (alias) {
			selectSymbol(alias.symbol);
			return;
		}
		const first = search.data?.results[0];
		if (first) {
			selectSymbol(first.symbol);
			return;
		}
		const direct = cleanSymbol(query);
		if (direct) selectSymbol(direct);
	}
	function watchFrom(item) {
		toggle(item);
	}
	const detail = asset.data;
	const tone = detail ? toneOf(detail.changePercent) : "flat";
	const renderList = (layout) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: layout === "chip" ? "flex gap-2 overflow-x-auto pb-1" : "space-y-2",
		children: [
			visibleWatch.length > 0 && layout === "row" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 text-xs font-medium tracking-widest text-muted uppercase",
				children: "Favoris"
			}) : null,
			visibleWatch.map((item) => {
				const quote = quoteMap.get(item.symbol);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteRow, {
					layout,
					active: item.symbol === symbol,
					watched: true,
					quote: quote ?? {
						...item,
						pending: true
					},
					onSelect: () => selectSymbol(item.symbol),
					onToggle: () => watchFrom({
						symbol: item.symbol,
						name: item.name,
						kind: item.kind
					})
				}, item.symbol);
			}),
			rest.length > 0 && layout === "row" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 pt-3 text-xs font-medium tracking-widest text-muted uppercase",
				children: "Univers"
			}) : null,
			rest.map((quote) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteRow, {
				layout,
				active: quote.symbol === symbol,
				watched: false,
				quote,
				onSelect: () => selectSymbol(quote.symbol),
				onToggle: () => watchFrom({
					symbol: quote.symbol,
					name: quote.name,
					kind: quote.kind
				})
			}, quote.symbol))
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid max-w-6xl gap-5 px-4 py-4 pb-24 lg:grid-cols-[320px_minmax(0,1fr)] lg:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 space-y-4 lg:sticky lg:top-28 lg:max-h-[calc(100vh-8rem)] lg:overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: query,
							onChange: (event) => {
								setQuery(event.target.value);
								setSearchOpen(true);
							},
							onFocus: () => setSearchOpen(true),
							onKeyDown: (event) => {
								if (event.key === "Enter") {
									event.preventDefault();
									submitSearch();
								}
								if (event.key === "Escape") setSearchOpen(false);
							},
							placeholder: "Ticker — AAPL, MC.PA, BTC, ETH",
							"aria-label": "Rechercher un actif",
							className: "h-11 w-full rounded-xl bg-panel pr-3 pl-10 text-base text-fg shadow-card outline-none placeholder:text-muted focus:ring-1 focus:ring-brass lg:text-sm"
						}),
						searchOpen && debounced.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute z-30 mt-2 w-full overflow-hidden rounded-xl bg-panel shadow-card",
							children: [
								search.isFetching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-3 py-3 text-sm text-muted",
									children: "Recherche…"
								}) : null,
								!search.isFetching && (search.data?.results.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-3 py-3 text-sm text-muted",
									children: "Aucun actif pour cette recherche."
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: search.data?.results.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onMouseDown: (event) => event.preventDefault(),
										onClick: () => selectSymbol(hit.symbol),
										className: "flex min-w-0 flex-1 items-center justify-between gap-3 px-3 py-3 text-left hover:bg-panel-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block truncate text-sm",
												children: hit.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-xs text-muted",
												children: hit.symbol
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "shrink-0 text-xs text-brass",
											children: hit.badge
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onMouseDown: (event) => event.preventDefault(),
										onClick: () => watchFrom({
											symbol: hit.symbol,
											name: hit.name,
											kind: hit.kind
										}),
										"aria-pressed": watchSet.has(hit.symbol),
										"aria-label": watchSet.has(hit.symbol) ? `Retirer ${hit.name} des favoris` : `Ajouter ${hit.name} aux favoris`,
										className: "grid size-11 shrink-0 place-items-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `size-4 ${watchSet.has(hit.symbol) ? "fill-brass text-brass" : "text-muted"}` })
									})]
								}, hit.symbol)) })
							]
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-1 rounded-xl bg-panel p-1 shadow-card",
					role: "tablist",
					"aria-label": "Univers",
					children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						role: "tab",
						"aria-selected": filter === item.id,
						onClick: () => onFilter(item.id),
						className: `h-10 rounded-lg text-sm ${filter === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`,
						children: item.label
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:hidden",
					children: [
						overview.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Chargement des cours…"
						}) : null,
						overview.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => overview.refetch(),
							className: "text-sm text-brass",
							children: "Réessayer le chargement des cours"
						}) : null,
						renderList("chip")
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden lg:block",
					children: [
						overview.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Chargement des cours…"
						}) : null,
						overview.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => overview.refetch(),
							className: "text-sm text-brass",
							children: "Réessayer le chargement des cours"
						}) : null,
						renderList("row"),
						!overview.isPending && visibleWatch.length === 0 && rest.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Aucun actif dans cette catégorie."
						}) : null
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			id: "actif",
			className: "min-w-0 scroll-mt-28 space-y-4",
			children: [
				asset.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "rounded-2xl bg-panel p-5 shadow-card",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Chargement du cours…"
					})
				}) : null,
				asset.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-panel p-5 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-down",
						children: [
							"Impossible de charger ",
							symbol,
							"."
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => asset.refetch(),
						className: "mt-3 h-11 text-sm text-brass",
						children: "Réessayer"
					})]
				}) : null,
				detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-panel p-4 shadow-card sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs tracking-widest text-brass uppercase",
										children: [
											detail.badge,
											" · ",
											formatPlace(detail.exchange, detail.kind)
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "mt-1 truncate text-2xl font-medium",
										children: detail.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs text-muted",
										children: detail.symbol
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => watchFrom({
									symbol: detail.symbol,
									name: detail.name,
									kind: detail.kind
								}),
								"aria-pressed": watchSet.has(detail.symbol),
								"aria-label": watchSet.has(detail.symbol) ? `Retirer ${detail.name} des favoris` : `Ajouter ${detail.name} aux favoris`,
								className: "grid size-11 shrink-0 place-items-center rounded-xl bg-panel-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `size-4 ${watchSet.has(detail.symbol) ? "fill-brass text-brass" : "text-muted"}` })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap items-end gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-4xl tabular-nums tracking-tight",
								children: formatPrice(detail.price, detail.currency)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: `inline-flex items-center gap-2 rounded-full px-3 py-1 font-mono text-sm tabular-nums ${toneClass(tone, true)}`,
								children: [
									tone === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4" }) : tone === "down" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "size-4" }) : null,
									formatSignedPrice(detail.changeAbs, detail.currency),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatPct(detail.changePercent) })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted",
									children: "Plus haut"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-mono text-sm tabular-nums",
									children: detail.dayHigh != null ? formatPrice(detail.dayHigh, detail.currency) : "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted",
									children: "Plus bas"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-mono text-sm tabular-nums",
									children: detail.dayLow != null ? formatPrice(detail.dayLow, detail.currency) : "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted",
									children: "Volume"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-mono text-sm tabular-nums",
									children: detail.volume != null ? formatVolume(detail.volume) : "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted",
									children: "Clôture préc."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "font-mono text-sm tabular-nums",
									children: detail.previousClose != null ? formatPrice(detail.previousClose, detail.currency) : "—"
								})] })
							]
						}),
						detail.week52High != null && detail.week52Low != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-muted",
							children: [
								"52 sem. ",
								formatPrice(detail.week52Low, detail.currency),
								" – ",
								formatPrice(detail.week52High, detail.currency)
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-1 rounded-lg bg-panel-2 p-1",
								children: RANGES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setRange(item.id),
									className: `h-9 rounded-md px-3 text-sm ${range === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`,
									children: item.label
								}, item.id))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1 rounded-lg bg-panel-2 p-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-pressed": mode === "line",
									onClick: () => setMode("line"),
									className: `inline-flex h-9 items-center gap-1 rounded-md px-2.5 text-sm ${mode === "line" ? "bg-brass font-medium text-ink" : "text-muted"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartLine, { className: "size-4" }), "Ligne"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									"aria-pressed": mode === "candle",
									onClick: () => setMode("candle"),
									className: `inline-flex h-9 items-center gap-1 rounded-md px-2.5 text-sm ${mode === "candle" ? "bg-brass font-medium text-ink" : "text-muted"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartCandlestick, { className: "size-4" }), "Bougies"]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: "Heures de Paris · source cours Yahoo Finance"
						}),
						chart.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm text-muted",
							children: "Chargement du graphique…"
						}) : null,
						chart.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => chart.refetch(),
							className: "mt-4 text-sm text-brass",
							children: "Réessayer le graphique"
						}) : null,
						chart.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceChart, {
							candles: chart.data.candles,
							mode,
							range,
							currency: detail.currency
						}) : null
					]
				}) : null,
				detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl bg-panel p-4 shadow-card sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xs font-medium tracking-widest text-muted uppercase",
							children: "Actualités"
						}),
						detail && detail.news.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "Aucune actualité récente trouvée pour cet actif."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 divide-y divide-line",
							children: detail?.news.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: item.url,
									target: "_blank",
									rel: "noreferrer noopener",
									className: "group block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-start justify-between gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm text-pretty group-hover:text-brass",
											children: item.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "mt-0.5 size-4 shrink-0 text-muted" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-1 block text-xs text-muted",
										children: [
											item.publisher,
											" · ",
											formatWhen(item.publishedAt)
										]
									})]
								})
							}, item.id))
						})
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalysisPanel, {
					symbol,
					name: detail?.name ?? symbol
				}, symbol)
			]
		})]
	}) });
}
function Home() {
	const search = Route$4.useSearch();
	const symbol = search.s ?? "NVDA";
	const filter = search.f ?? "all";
	const navigate = Route$4.useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, {
		symbol,
		filter,
		onSymbol: (next) => {
			navigate({
				search: {
					s: next,
					f: filter
				},
				resetScroll: false
			});
		},
		onFilter: (next) => {
			navigate({
				search: {
					s: symbol,
					f: next
				},
				resetScroll: false
			});
		}
	});
}
//#endregion
export { Home as component };
