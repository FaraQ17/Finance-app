#!/bin/sh
set -eu
cd /workspace
node scripts/preview.mjs stop || true

if ! curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/; then
  nohup npm run dev >>/tmp/app-startup.log 2>&1 &
fi

watch_pid=""
if [ -f /tmp/vesper-dev-watch.pid ]; then
  watch_pid=$(cat /tmp/vesper-dev-watch.pid)
fi
if [ -z "$watch_pid" ] || ! kill -0 "$watch_pid" 2>/dev/null; then
  nohup sh /workspace/scripts/dev-watch.sh >>/tmp/app-startup.log 2>&1 &
  echo $! >/tmp/vesper-dev-watch.pid
fi
