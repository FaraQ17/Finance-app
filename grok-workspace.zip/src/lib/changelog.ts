export type Change = {
  date: string;
  title: string;
  points: string[];
};

// Nouvelle entrée en tête à chaque demande.

export const CHANGELOG: Change[] = [
  {
    date: "25 octobre 2026",
    title: "Prêt pour Vercel",
    points: [
      "Le site peut être publié sur Vercel. Les cours, les graphiques et l'analyse passent par le serveur.",
      "Le compte fictif reste dans le navigateur. Sur Vercel, le bot analyse tant que la page est ouverte.",
    ],
  },
  {
    date: "22 octobre 2026",
    title: "Cours en direct",
    points: [
      "Les valeurs, le gain et la perte se mettent à jour seuls tant que la page est ouverte, sans actualiser à la main.",
      "Le bot indique l'heure du dernier cours reçu.",
    ],
  },
  {
    date: "22 octobre 2026",
    title: "L'analyse ne remet plus le compte à zéro",
    points: [
      "Après un import, Analyser ne peut plus remplacer le portefeuille par un compte vide de 1 000 $.",
      "Une analyse déjà en cours ne réécrit pas le fichier si les positions ont été réimportées entre-temps.",
    ],
  },
  {
    date: "21 octobre 2026",
    title: "Avancement de l'analyse",
    points: [
      "Un cercle indique le pourcentage de titres déjà lus pendant l'analyse du bot.",
      "Enregistrer les paramètres de risque ne signale plus une erreur quand ils ont bien été pris en compte.",
    ],
  },
  {
    date: "21 octobre 2026",
    title: "Marché, statut et pourcentage",
    points: [
      "Une ligne ouverte affiche seulement sa place (New York, Paris, Tokyo…) et si ce marché est ouvert, fermé ou en pause.",
      "Le résultat de la ligne montre le gain ou la perte en dollars et en pourcentage en même temps.",
    ],
  },
  {
    date: "21 octobre 2026",
    title: "Suivi des mises à jour",
    points: [
      "Nouvel onglet Suivi : l'historique des améliorations de Vesper, du plus récent au plus ancien.",
      "L'analyse du bot avance par petits groupes de titres, pour ne plus rester bloquée une demi-heure.",
      "Si le plafond est plein et qu'une place hors États-Unis n'a aucune ligne, le bot vend la plus petite action américaine pour l'ouvrir.",
    ],
  },
  {
    date: "21 octobre 2026",
    title: "Places hors États-Unis et analyse par titre",
    points: [
      "Le bot suit aussi l'Europe, le Japon, Hong Kong et le Canada, en plus de Wall Street et des cryptos.",
      "Les cours étrangers sont convertis en dollars avant un ordre.",
      "Chaque passage affiche, titre par titre, la tendance, le RSI, la variation et la décision.",
    ],
  },
  {
    date: "21 octobre 2026",
    title: "Ventes à découvert",
    points: [
      "Le bot et le ticket manuel peuvent ouvrir un short : le gain vient d'une baisse.",
      "Le stop est au-dessus du cours, l'objectif en dessous. Fermer un short, c'est le racheter.",
      "Les longs déjà ouverts ne changent pas. Pas de levier ni de liquidation : le cash est réservé.",
    ],
  },
  {
    date: "21 octobre 2026",
    title: "Trois cadres de risque",
    points: [
      "Faible, moyen et élevé règlent le nombre de lignes, la taille et la largeur des signaux.",
      "Le niveau affiché suit le cadre choisi, plus seulement l'état du portefeuille.",
    ],
  },
  {
    date: "21 octobre 2026",
    title: "Courbe dans « Que ferait le bot »",
    points: [
      "L'analyse d'un titre montre le cours sur 6 mois, les moyennes 20 et 50 jours, et le RSI.",
      "Les chiffres lus par le bot sont affichés à côté : volatilité, volume, support, résistance, sentiment.",
    ],
  },
  {
    date: "21 octobre 2026",
    title: "Décisions plus sûres",
    points: [
      "Une ligne se ferme à son propre objectif, pas au réglage modifié après l'ouverture.",
      "Une news ne fait vendre que si elle parle de ce titre.",
      "Un cours aberrant est ignoré. Le volume comparé est celui de la veille.",
      "Jusqu'à quatre titres Yahoo récents, et un dépôt SEC 8-K s'il est frais.",
    ],
  },
  {
    date: "21 octobre 2026",
    title: "Reprise après fermeture de Safari",
    points: [
      "Rouvrir la page recharge le compte au lieu de garder l'écran de la veille.",
      "Le bot ne tourne que tant que le serveur est allumé. La nuit, il s'arrête avec lui.",
    ],
  },
  {
    date: "20 octobre 2026",
    title: "Bot autonome et compte fictif",
    points: [
      "Compte papier de départ 1 000 $. Aucun ordre réel.",
      "Le bot ne démarre qu'après Activer. Ensuite il continue après un redémarrage.",
      "Positions, journal, courbe du portefeuille, dépôt fictif, export et import du compte.",
      "Ordres manuels en vert, ordres du bot en jaune. Stop et objectif sur la courbe.",
    ],
  },
  {
    date: "20 octobre 2026",
    title: "Desk, tendances, favoris et sentiment",
    points: [
      "Recherche d'une action ou d'une crypto, cours, variation et graphique.",
      "Tendances, liste de favoris, et lecture du sentiment des news.",
      "Avertissement visible : ce n'est pas un conseil en investissement.",
    ],
  },
];
