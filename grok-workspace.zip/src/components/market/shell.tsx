import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getLiveMarks } from "@/lib/market-api";
import { getPaperBook } from "@/lib/paper-api";
import { bootPaper, usePaperStore } from "@/lib/paper-store";
import { DISCLAIMER } from "@/lib/universe";

function NavLink({ to, label }: { to: "/" | "/tendances" | "/favoris" | "/sentiment" | "/bot" | "/suivi"; label: string }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const on = path === to;
  return (
    <Link
      to={to}
      className={`grid h-10 shrink-0 place-items-center rounded-lg px-3 text-sm ${
        on ? "bg-brass font-medium text-ink" : "bg-panel text-muted"
      }`}
    >
      {label}
    </Link>
  );
}

export function MarketShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-line bg-ink/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <div className="min-w-0">
            <p className="font-mono text-sm tracking-widest text-brass">VESPER</p>
            <p className="text-xs text-muted">Desk actions & crypto</p>
          </div>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-4 pb-3" aria-label="Sections">
          <NavLink to="/" label="Desk" />
          <NavLink to="/tendances" label="Tendances" />
          <NavLink to="/favoris" label="Favoris" />
          <NavLink to="/sentiment" label="Sentiment" />
          <NavLink to="/bot" label="Bot" />
          <NavLink to="/suivi" label="Suivi" />
        </nav>
        <p className="border-t border-line bg-panel px-4 py-2 text-xs leading-relaxed text-muted">
          <span className="font-medium text-brass">Information. </span>
          {DISCLAIMER}
        </p>
      </header>
      <BotPulse />
      {children}
    </div>
  );
}

function BotPulse() {
  const [ready, setReady] = useState(false);
  const queryClient = useQueryClient();
  useEffect(() => {
    let cancel = false;
    void (async () => {
      await bootPaper();
      if (!cancel) setReady(true);
    })();
    return () => {
      cancel = true;
    };
  }, []);
  const book = useQuery({
    queryKey: ["paper-book"],
    enabled: ready,
    queryFn: () => getPaperBook(),
    refetchInterval: 8_000,
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });
  useEffect(() => {
    if (!ready) return;
    const refresh = () => {
      void queryClient.invalidateQueries({ queryKey: ["paper-book"] });
    };
    const onVisible = () => {
      if (document.visibilityState === "visible") refresh();
    };
    window.addEventListener("focus", refresh);
    window.addEventListener("pageshow", refresh);
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      window.removeEventListener("focus", refresh);
      window.removeEventListener("pageshow", refresh);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [ready, queryClient]);
  useEffect(() => {
    if (!ready) return;
    let stop = false;
    let busy = false;
    const run = async () => {
      if (stop || busy || document.visibilityState === "hidden") return;
      busy = true;
      try {
        const view = await getPaperBook();
        if (stop) return;
        usePaperStore.getState().adopt(view);
        const symbols = usePaperStore.getState().positions.map((position) => position.symbol);
        if (symbols.length > 0) {
          const live = await getLiveMarks({ data: { symbols } });
          if (!stop) {
            const marks: Record<string, number> = {};
            for (const row of live.marks) marks[row.symbol] = row.price;
            usePaperStore.getState().patchMarks(marks);
          }
        }
        await usePaperStore.getState().nudge();
      } catch {
        // Le prochain passage réessaie.
      } finally {
        busy = false;
      }
    };
    void run();
    const id = window.setInterval(() => void run(), 8_000);
    const onVisible = () => {
      if (document.visibilityState === "visible") void run();
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("pageshow", onVisible);
    return () => {
      stop = true;
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("pageshow", onVisible);
    };
  }, [ready]);
  useEffect(() => {
    if (book.data) usePaperStore.getState().adopt(book.data);
  }, [book.data]);
  return null;
}
