import { useMemo, useState } from "react";
import { formatPrice } from "@/lib/format";

export type ChartSpan = "min" | "h" | "d" | "m" | "y";

function axisLabel(at: number, span: ChartSpan): string {
  const date = new Date(at);
  if (span === "min" || span === "h") return new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit" }).format(date);
  if (span === "d") return new Intl.DateTimeFormat("fr-FR", { day: "numeric", month: "short" }).format(date);
  if (span === "m") return new Intl.DateTimeFormat("fr-FR", { month: "short", year: "2-digit" }).format(date);
  return String(date.getFullYear());
}

export function ValueChart({
  points,
  marker,
  guides = [],
  currency,
  span,
}: {
  points: { t: number; v: number }[];
  marker?: number;
  guides?: { value: number; color: string; label: string }[];
  currency: string;
  span: ChartSpan;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const model = useMemo(() => {
    if (points.length < 2) return null;
    const values = points.map((point) => point.v);
    if (marker != null) values.push(marker);
    for (const guide of guides) if (Number.isFinite(guide.value)) values.push(guide.value);
    let min = Math.min(...values);
    let max = Math.max(...values);
    if (min === max) {
      min -= Math.abs(min) * 0.01 || 1;
      max += Math.abs(max) * 0.01 || 1;
    }
    const pad = (max - min) * 0.12;
    min -= pad;
    max += pad;
    const width = 640;
    const height = 220;
    const left = 8;
    const right = 72;
    const top = 16;
    const bottom = 28;
    const innerW = width - left - right;
    const innerH = height - top - bottom;
    const y = (value: number) => top + ((max - value) / (max - min)) * innerH;
    const x = (index: number) => left + (points.length === 1 ? innerW / 2 : (index / (points.length - 1)) * innerW);
    const line = points
      .map((point, index) => `${index === 0 ? "M" : "L"}${x(index).toFixed(1)} ${y(point.v).toFixed(1)}`)
      .join(" ");
    const area = `${line} L${x(points.length - 1).toFixed(1)} ${(top + innerH).toFixed(1)} L${x(0).toFixed(1)} ${(top + innerH).toFixed(1)} Z`;
    const rising = points[points.length - 1]!.v >= points[0]!.v;
    return { width, height, top, bottom, left, right, innerH, y, x, line, area, rising, min, max };
  }, [points, marker, guides]);

  if (!model) {
    return <p className="grid h-48 place-items-center text-sm text-muted">Pas encore assez de points.</p>;
  }

  const index = hover ?? points.length - 1;
  const current = points[index] ?? points[points.length - 1]!;
  const color = model.rising ? "var(--color-up)" : "var(--color-down)";

  return (
    <div>
      <p className="font-mono text-sm tabular-nums">
        {formatPrice(current.v, currency)}
        <span className="ml-2 text-xs text-muted">{axisLabel(current.t, span)}</span>
      </p>
      <svg
        viewBox={`0 0 ${model.width} ${model.height}`}
        className="mt-2 h-52 w-full touch-none"
        role="img"
        aria-label="Courbe"
        onPointerMove={(event) => {
          const rect = event.currentTarget.getBoundingClientRect();
          const ratio = (event.clientX - rect.left) / rect.width;
          const next = Math.round(Math.min(1, Math.max(0, ratio)) * (points.length - 1));
          setHover(next);
        }}
        onPointerLeave={() => setHover(null)}
      >
        <path d={model.area} fill={color} opacity="0.16" />
        <path d={model.line} fill="none" stroke={color} strokeWidth="2.5" />
        {marker != null ? (
          <line
            x1={model.left}
            x2={model.width - model.right}
            y1={model.y(marker)}
            y2={model.y(marker)}
            stroke="var(--color-brass)"
            strokeDasharray="4 4"
            strokeWidth="1.5"
          />
        ) : null}
        {guides.map((guide) =>
          Number.isFinite(guide.value) ? (
            <g key={guide.label}>
              <line
                x1={model.left}
                x2={model.width - model.right}
                y1={model.y(guide.value)}
                y2={model.y(guide.value)}
                stroke={guide.color}
                strokeDasharray="5 4"
                strokeWidth="1.5"
              />
              <text x={model.width - 4} y={model.y(guide.value) + 4} textAnchor="end" fill={guide.color} fontSize="11">
                {guide.label}
              </text>
            </g>
          ) : null,
        )}
        <text x={model.width - model.right + 8} y={model.y(current.v)} fill="var(--color-muted)" fontSize="12">
          {formatPrice(current.v, currency)}
        </text>
        <text x={model.left} y={model.height - 8} fill="var(--color-muted)" fontSize="12">
          {axisLabel(points[0]!.t, span)}
        </text>
        <text
          x={model.width - model.right}
          y={model.height - 8}
          textAnchor="end"
          fill="var(--color-muted)"
          fontSize="12"
        >
          {axisLabel(points[points.length - 1]!.t, span)}
        </text>
        <circle cx={model.x(index)} cy={model.y(current.v)} r="4" fill={color} />
      </svg>
      {marker != null ? <p className="text-xs text-brass">Trait doré : prix d'achat</p> : null}
      {guides.length > 0 ? <p className="text-xs text-muted">Pointillé rouge : stop · vert : objectif</p> : null}
    </div>
  );
}
