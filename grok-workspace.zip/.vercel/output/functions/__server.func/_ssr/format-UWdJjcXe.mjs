import { i as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as DISCLAIMER, s as cleanSymbol } from "./universe-7NGhBY7T.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-UWdJjcXe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function str(value) {
	return typeof value === "string" ? value : "";
}
var getOverview = createServerFn({ method: "GET" }).handler(createSsrRpc("edc778dcedfd9ea4bd0e18e414a68be2338d42c3064393336d6a69bbfde6d2b1"));
var getQuotes = createServerFn({ method: "POST" }).validator((input) => {
	const raw = input.symbols;
	return { symbols: Array.isArray(raw) ? [...new Set(raw.map((item) => cleanSymbol(String(item))).filter((item) => !!item))].slice(0, 30) : [] };
}).handler(createSsrRpc("cfc7846a37993771363968d82d9b1455ee61371ec4113308f663c30325fd8ddf"));
var getAsset = createServerFn({ method: "POST" }).validator((input) => {
	const symbol = cleanSymbol(str(input.symbol));
	if (!symbol) throw new Error("Ticker invalide");
	return { symbol };
}).handler(createSsrRpc("a5d1c73f1ebbed46d39e04052b4e2bcb016c60729d169ff5718ad57c6b15c54e"));
var getChart = createServerFn({ method: "POST" }).validator((input) => {
	const symbol = cleanSymbol(str(input.symbol));
	const rangeRaw = str(input.range);
	const range = rangeRaw === "7d" || rangeRaw === "30d" ? rangeRaw : "1d";
	if (!symbol) throw new Error("Ticker invalide");
	return {
		symbol,
		range
	};
}).handler(createSsrRpc("0c4db58fb156003b96b8117fa0846ab845716f3ad8ff551332c3e05474d989b8"));
var searchAssets = createServerFn({ method: "POST" }).validator((input) => {
	return { q: str(input.q).trim().slice(0, 40) };
}).handler(createSsrRpc("dcc0b9a339daee0d25883b2b642ba128fe6c619d08774229f2cad11cc68ce5e4"));
function parseTerm(value) {
	return value === "moyen" || value === "long" ? value : "court";
}
var analyzeAsset = createServerFn({ method: "POST" }).validator((input) => {
	const symbol = cleanSymbol(str(input.symbol));
	if (!symbol) throw new Error("Ticker invalide");
	return {
		symbol,
		force: Boolean(input.force),
		term: parseTerm(input.term)
	};
}).handler(createSsrRpc("836371e49d70a30075d8e928b6ae7ddd160ab56510cb8ce53c7fa8f60a0d1ad5"));
function parseHorizon(value) {
	return value === 5 || value === "5" || value === 10 || value === "10" ? value === 10 || value === "10" ? 10 : 5 : 1;
}
var getTrends = createServerFn({ method: "POST" }).validator((input) => {
	return {
		kind: input.kind === "crypto" ? "crypto" : "stock",
		horizon: parseHorizon(input.horizon)
	};
}).handler(createSsrRpc("0da63a37d7597eb7d481041ee44a46a6e000562a2b7e999b4d389eb97edb923c"));
var readTrendBoard = createServerFn({ method: "POST" }).validator((input) => {
	const kind = input.kind === "crypto" ? "crypto" : "stock";
	const force = Boolean(input.force);
	return {
		kind,
		horizon: parseHorizon(input.horizon),
		force
	};
}).handler(createSsrRpc("5b20a4127e43f05b3e3dfe6de6a21644e95d79b26d0a18c4ac7b75422f01a403"));
var rankSentiment = createServerFn({ method: "POST" }).validator((input) => {
	const scopeRaw = input.scope;
	const scope = scopeRaw === "stock" || scopeRaw === "crypto" || scopeRaw === "favoris" || scopeRaw === "mix" ? scopeRaw : "mix";
	const force = Boolean(input.force);
	const raw = input.favorites;
	const favorites = Array.isArray(raw) ? raw.map((item) => {
		if (!item || typeof item !== "object") return null;
		const record = item;
		const symbol = cleanSymbol(str(record.symbol));
		if (!symbol) return null;
		const kind = record.kind === "crypto" ? "crypto" : "stock";
		return {
			symbol,
			name: str(record.name).slice(0, 80) || symbol,
			kind
		};
	}).filter((item) => item !== null).slice(0, 20) : [];
	return {
		term: parseTerm(input.term),
		scope,
		force,
		favorites
	};
}).handler(createSsrRpc("99944acc3c247bd79d522a0418376b78609d7ae202415e89cea06894e7e3cb9a"));
var getBotMarket = createServerFn({ method: "GET" }).handler(createSsrRpc("ed8233aafd63336b62a4b11cb18864ab480349cbca470fc7b5763688e1f43545"));
var PAPER_CAPITAL = 1e3;
var MAX_POSITIONS = 6;
var MAX_INVESTED = .4;
var CASH_FLOOR = .55;
var BUY_GAP_MS = 9e4;
var NOTE_GAP_MS = 9e5;
function freshPaper(now = Date.now()) {
	return {
		cash: PAPER_CAPITAL,
		positions: [],
		trades: [],
		journal: [],
		paused: false,
		armed: false,
		startedAt: now,
		lastDecisionAt: 0,
		lastNoteAt: 0,
		marks: {}
	};
}
function markOf(state, symbol, fallback) {
	return state.marks[symbol] ?? fallback;
}
function positionValue(state, position) {
	return position.qty * markOf(state, position.symbol, position.entry);
}
function investedValue(state) {
	return state.positions.reduce((sum, position) => sum + positionValue(state, position), 0);
}
function equityOf(state) {
	return state.cash + investedValue(state);
}
function riskOf(state) {
	const equity = equityOf(state);
	const invested = equity > 0 ? investedValue(state) / equity : 0;
	const nearStop = state.positions.some((position) => {
		const price = markOf(state, position.symbol, position.entry);
		return price > 0 && (price - position.stop) / price < .012;
	});
	if (nearStop || invested > .4) return {
		level: "eleve",
		note: nearStop ? "Une position est proche de son stop. Le bot peut la couper pour limiter la perte." : "La part investie dépasse le plafond de prudence."
	};
	if (invested > .22 || state.positions.length >= 4) return {
		level: "modere",
		note: "Plusieurs lignes ouvertes, chacune petite. Le cash reste majoritaire."
	};
	return {
		level: "faible",
		note: "Peu de capital engagé. Taille max 6 % par ligne, 40 % au total."
	};
}
function roundQty(value) {
	return Math.floor(value * 1e4) / 1e4;
}
function rsiLabel(value) {
	return value == null ? "RSI indisponible" : `RSI ${Math.round(value)}`;
}
function newsIsAbout(quote) {
	if (!quote.headline) return false;
	const title = quote.headline.toLowerCase();
	const name = quote.name.toLowerCase();
	const symbol = quote.symbol.replace(/-USD$/i, "").toLowerCase();
	return title.includes(name) || title.includes(symbol.toLowerCase());
}
function canBuy(quote, state) {
	if (state.positions.some((position) => position.symbol === quote.symbol)) return false;
	if (quote.trend !== "haussiere") return false;
	if (quote.rsi == null || quote.rsi < 42 || quote.rsi > 72) return false;
	if (quote.sentiment <= -30 && newsIsAbout(quote)) return false;
	if (quote.volatility == null) return false;
	if (quote.kind === "crypto" && quote.volatility > 6) return false;
	if (quote.kind === "stock" && quote.volatility > 3.5) return false;
	if (quote.changePercent > 3 || quote.changePercent < -3) return false;
	if (quote.sma20 != null && quote.price > quote.sma20 * 1.05) return false;
	if (quote.volumeRatio != null && quote.volumeRatio < .2) return false;
	if (quote.kind === "crypto" && state.positions.some((position) => position.kind === "crypto")) return false;
	return true;
}
function buyScore(quote) {
	const rsi = quote.rsi ?? 50;
	const vol = quote.volatility ?? 3;
	return quote.sentiment * .35 + (68 - rsi) * .4 + (quote.kind === "stock" ? 6 : 0) - vol * 3;
}
function step(state, quotes, now) {
	if (quotes.length === 0) return state;
	const marks = { ...state.marks };
	for (const quote of quotes) marks[quote.symbol] = quote.price;
	const bySymbol = new Map(quotes.map((quote) => [quote.symbol, quote]));
	let cash = state.cash;
	let positions = state.positions.map((position) => ({ ...position }));
	const trades = [...state.trades];
	const journal = [...state.journal];
	let lastDecisionAt = state.lastDecisionAt;
	let lastNoteAt = state.lastNoteAt;
	let traded = false;
	const pushNote = (action, text) => {
		journal.unshift({
			id: `${now}-${action}-${journal.length}`,
			at: now,
			action,
			text
		});
	};
	const sell = (position, price, reason) => {
		const pnl = (price - position.entry) * position.qty;
		cash += price * position.qty;
		trades.unshift({
			id: `${now}-vente-${position.symbol}`,
			at: now,
			side: "vente",
			symbol: position.symbol,
			name: position.name,
			qty: position.qty,
			price,
			pnl,
			reason
		});
		pushNote("vente", `Vente simulée de ${position.name}. ${reason}`);
		traded = true;
	};
	if (!state.paused) {
		const kept = [];
		for (const position of positions) {
			const quote = bySymbol.get(position.symbol);
			const price = quote?.price ?? marks[position.symbol] ?? position.entry;
			if (!quote) {
				kept.push(position);
				continue;
			}
			if (price <= position.stop) {
				sell(position, price, `Stop-loss touché à ${price.toFixed(2)} $ (entrée ${position.entry.toFixed(2)} $).`);
				continue;
			}
			if (price >= position.target) {
				sell(position, price, `Objectif atteint à ${price.toFixed(2)} $. Prise de profit pour protéger le gain.`);
				continue;
			}
			if (quote.trend === "baissiere" && quote.rsi != null && quote.rsi < 45) {
				sell(position, price, `Tendance passée baissière, ${rsiLabel(quote.rsi)}. Sortie avant d'élargir la perte.`);
				continue;
			}
			if (quote.sentiment <= -25 && quote.trend !== "haussiere") {
				sell(position, price, `Actualité devenue négative${quote.headline ? ` (« ${quote.headline} »)` : ""}. Sortie de prudence.`);
				continue;
			}
			kept.push(position);
		}
		positions = kept;
		const equity = cash + positions.reduce((sum, position) => sum + position.qty * (marks[position.symbol] ?? position.entry), 0);
		const invested = positions.reduce((sum, position) => sum + position.qty * (marks[position.symbol] ?? position.entry), 0);
		if ((lastDecisionAt === 0 || now - lastDecisionAt >= BUY_GAP_MS) && positions.length < MAX_POSITIONS) {
			const room = equity * MAX_INVESTED - invested;
			const pick = quotes.filter((quote) => canBuy(quote, {
				...state,
				positions
			})).sort((a, b) => buyScore(b) - buyScore(a))[0];
			if (pick && buyScore(pick) >= 4 && room >= 25) {
				const fraction = pick.kind === "crypto" ? .05 : .06;
				const qty = roundQty(Math.min(equity * fraction, room, cash - equity * CASH_FLOOR) / pick.price);
				if (qty > 0 && qty * pick.price >= 25 && qty * pick.price <= cash) {
					const stop = pick.price * (pick.kind === "crypto" ? .95 : .96);
					const target = pick.price * (pick.kind === "crypto" ? 1.08 : 1.07);
					cash -= qty * pick.price;
					positions.unshift({
						symbol: pick.symbol,
						name: pick.name,
						kind: pick.kind,
						qty,
						entry: pick.price,
						stop,
						target,
						openedAt: now
					});
					const weight = Math.round(fraction * 100);
					const reason = `Tendance haussière, ${rsiLabel(pick.rsi)}, news ${pick.sentiment > 15 ? "positives" : "sans alerte négative"}. Taille ${weight} % du capital, stop sous l'entrée, objectif modeste.`;
					trades.unshift({
						id: `${now}-achat-${pick.symbol}`,
						at: now,
						side: "achat",
						symbol: pick.symbol,
						name: pick.name,
						qty,
						price: pick.price,
						pnl: null,
						reason
					});
					pushNote("achat", `Achat simulé de ${pick.name}. ${reason}${pick.headline ? ` Titre retenu : ${pick.headline}` : ""}`);
					traded = true;
					lastDecisionAt = now;
				}
			}
		}
		if (!traded && (lastNoteAt === 0 || now - lastNoteAt >= NOTE_GAP_MS)) {
			const bullish = quotes.filter((quote) => quote.trend === "haussiere").length;
			pushNote("attente", `Surveillance de ${quotes.length} valeurs liquides. ${bullish} en tendance haussière, aucun signal assez propre pour risquer du capital. Cash conservé.`);
			lastNoteAt = now;
		}
	}
	return {
		...state,
		cash,
		positions,
		trades: trades.slice(0, 80),
		journal: journal.slice(0, 40),
		lastDecisionAt,
		lastNoteAt,
		marks
	};
}
var usePaperStore = create()(persist((set, get) => ({
	...freshPaper(),
	pause: (paused) => set({ paused }),
	reset: () => set({
		...freshPaper(Date.now()),
		armed: true
	}),
	arm: () => set({ armed: true }),
	onQuotes: (quotes, now) => set(step(get(), quotes, now))
}), {
	name: "vesper-paper-bot",
	skipHydration: true,
	partialize: (state) => ({
		cash: state.cash,
		positions: state.positions,
		trades: state.trades,
		journal: state.journal,
		paused: state.paused,
		armed: state.armed,
		startedAt: state.startedAt,
		lastDecisionAt: state.lastDecisionAt,
		lastNoteAt: state.lastNoteAt,
		marks: state.marks
	})
}));
function NavLink({ to, label }) {
	const on = useRouterState({ select: (state) => state.location.pathname }) === to;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		className: `grid h-10 shrink-0 place-items-center rounded-lg px-3 text-sm ${on ? "bg-brass font-medium text-ink" : "bg-panel text-muted"}`,
		children: label
	});
}
function MarketShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-ink/95 backdrop-blur",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-sm tracking-widest text-brass",
								children: "VESPER"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Desk actions & crypto"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex gap-1 overflow-x-auto px-4 pb-3",
						"aria-label": "Sections",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
								to: "/",
								label: "Desk"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
								to: "/tendances",
								label: "Tendances"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
								to: "/favoris",
								label: "Favoris"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
								to: "/sentiment",
								label: "Sentiment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
								to: "/bot",
								label: "Bot"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "border-t border-line bg-panel px-4 py-2 text-xs leading-relaxed text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-brass",
							children: "Information. "
						}), DISCLAIMER]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BotPulse, {}),
			children
		]
	});
}
function BotPulse() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const armed = usePaperStore((state) => state.armed);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		(async () => {
			await usePaperStore.persist.rehydrate();
			if (!cancel) setReady(true);
		})();
		return () => {
			cancel = true;
		};
	}, []);
	const market = useQuery({
		queryKey: ["bot-market"],
		enabled: ready && armed,
		queryFn: () => getBotMarket(),
		staleTime: 6e4,
		refetchInterval: armed ? 9e4 : false
	});
	(0, import_react.useEffect)(() => {
		if (!ready || !armed || !market.data) return;
		usePaperStore.getState().onQuotes(market.data.quotes, Date.now());
	}, [
		ready,
		armed,
		market.data
	]);
	return null;
}
function formatAxisPrice(value, currency) {
	const abs = Math.abs(value);
	const suffix = currency === "EUR" ? "€" : currency === "GBP" || currency === "GBp" ? "£" : "$";
	if (abs >= 1e4) return `${new Intl.NumberFormat("fr-FR", {
		notation: "compact",
		maximumFractionDigits: 1
	}).format(value)} ${suffix}`;
	if (abs >= 100) return `${new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 }).format(value)} ${suffix}`;
	return formatPrice(value, currency);
}
function formatPrice(value, currency) {
	const abs = Math.abs(value);
	const digits = abs >= 1 ? 2 : abs >= .01 ? 4 : abs >= 1e-4 ? 6 : 8;
	const formatted = new Intl.NumberFormat("fr-FR", {
		minimumFractionDigits: Math.min(2, digits),
		maximumFractionDigits: digits
	}).format(value);
	if (currency === "EUR") return `${formatted} €`;
	if (currency === "GBP" || currency === "GBp") return `${formatted} £`;
	if (currency === "USD" || currency === "") return `${formatted} $`;
	return `${formatted} ${currency}`;
}
function formatPct(value) {
	return `${value > 0 ? "+" : ""}${new Intl.NumberFormat("fr-FR", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	}).format(value)} %`;
}
function formatSignedPrice(value, currency) {
	return `${value > 0 ? "+" : value < 0 ? "−" : ""}${formatPrice(Math.abs(value), currency)}`;
}
function formatVolume(value) {
	return new Intl.NumberFormat("fr-FR", {
		notation: "compact",
		maximumFractionDigits: 1
	}).format(value);
}
function formatWhen(unixSec) {
	const diff = Date.now() - unixSec * 1e3;
	const min = Math.round(diff / 6e4);
	if (!Number.isFinite(min)) return "";
	if (min < 1) return "à l'instant";
	if (min < 60) return `il y a ${min} min`;
	const hours = Math.round(min / 60);
	if (hours < 24) return `il y a ${hours} h`;
	const days = Math.round(hours / 24);
	if (days < 7) return `il y a ${days} j`;
	return new Intl.DateTimeFormat("fr-FR", {
		day: "numeric",
		month: "short"
	}).format(/* @__PURE__ */ new Date(unixSec * 1e3));
}
function formatClock(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "";
	return new Intl.DateTimeFormat("fr-FR", {
		hour: "2-digit",
		minute: "2-digit"
	}).format(date);
}
function formatAxisTime(unixSec, range) {
	const date = /* @__PURE__ */ new Date(unixSec * 1e3);
	if (range === "1d") return new Intl.DateTimeFormat("fr-FR", {
		hour: "2-digit",
		minute: "2-digit",
		timeZone: "Europe/Paris"
	}).format(date);
	return new Intl.DateTimeFormat("fr-FR", {
		day: "2-digit",
		month: "2-digit",
		timeZone: "Europe/Paris"
	}).format(date);
}
function formatPlace(exchange, kind) {
	if (kind === "crypto") return "Cours continu";
	return {
		NasdaqGS: "Nasdaq",
		NMS: "Nasdaq",
		NYQ: "NYSE",
		NYSE: "NYSE",
		PCX: "NYSE Arca",
		Paris: "Euronext Paris",
		PAR: "Euronext Paris"
	}[exchange] ?? (exchange || "Marché");
}
function toneOf(change) {
	if (change > .004) return "up";
	if (change < -.004) return "down";
	return "flat";
}
//#endregion
export { readTrendBoard as C, usePaperStore as D, toneOf as E, rankSentiment as S, searchAssets as T, getOverview as _, formatAxisPrice as a, investedValue as b, formatPct as c, formatSignedPrice as d, formatVolume as f, getChart as g, getBotMarket as h, equityOf as i, formatPlace as l, getAsset as m, PAPER_CAPITAL as n, formatAxisTime as o, formatWhen as p, analyzeAsset as r, formatClock as s, MarketShell as t, formatPrice as u, getQuotes as v, riskOf as w, positionValue as x, getTrends as y };
