import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { join, dirname } from "node:path";
import { loadBotQuotes } from "@/lib/market-api";
import {
  freshPaper,
  isBlankBook,
  accountDestroyed,
  manualClose,
  manualOpen,
  parseSnapshot,
  pushHistory,
  settingsOf,
  snapshotOf,
  step,
  equityOf,
  type PaperState,
  type RiskSettings,
} from "@/lib/paper-bot";
import type { Kind } from "@/lib/universe";

const hosted = process.env.VERCEL === "1";
const FILE = join(process.cwd(), "data", "paper-bot.json");

export type PaperView = {
  book: PaperState;
  rev: number;
  lastRunAt: number;
  ok: boolean;
  reset?: boolean;
  hosted?: boolean;
};

type ManualOrder = {
  symbol: string;
  name: string;
  kind: Kind;
  price: number;
  amount: number;
  stop: number;
  target: number;
  side?: "long" | "short";
};

export type PaperCommand = (
  | { type: "pause"; paused: boolean; activated?: boolean }
  | { type: "reset" }
  | { type: "deposit"; amount: number }
  | { type: "risk"; risk: RiskSettings }
  | { type: "manualOpen"; order: ManualOrder }
  | { type: "manualClose"; symbol: string; price: number }
  | { type: "replace"; book: unknown }
  | { type: "tick" }
) & { clientBook?: unknown };

type Slot = {
  book: PaperState;
  rev: number;
  lastRunAt: number;
  chain: Promise<void>;
  timer: ReturnType<typeof setInterval> | null;
  loaded: boolean;
  optInChecked: boolean;
  ticking: boolean;
  idle: Promise<void>;
  progress: { done: number; total: number; running: boolean };
};

const root = globalThis as { __vesperBot?: Slot };
const slot: Slot = root.__vesperBot ?? {
  book: freshPaper(),
  rev: 0,
  lastRunAt: 0,
  chain: Promise.resolve(),
  timer: null,
  loaded: false,
  optInChecked: false,
  ticking: false,
  idle: Promise.resolve(),
  progress: { done: 0, total: 0, running: false },
};
root.__vesperBot = slot;
if (!slot.progress) slot.progress = { done: 0, total: 0, running: false };
if (!slot.idle) slot.idle = Promise.resolve();

export function readProgress(): { done: number; total: number; running: boolean } {
  return slot.progress;
}

function view(ok = true, reset = false): PaperView {
  return { book: slot.book, rev: slot.rev, lastRunAt: slot.lastRunAt, ok, reset, hosted };
}

async function readStored(): Promise<{ book: PaperState; lastRunAt: number; rev: number } | null> {
  try {
    const raw = JSON.parse(await readFile(FILE, "utf8")) as { lastRunAt?: unknown; rev?: unknown };
    const book = parseSnapshot(raw);
    if (!book) return null;
    return {
      book,
      lastRunAt: typeof raw.lastRunAt === "number" ? raw.lastRunAt : 0,
      rev: typeof raw.rev === "number" ? raw.rev : 1,
    };
  } catch {
    return null;
  }
}

async function publish(book: PaperState, ran = false, reset = false): Promise<PaperView> {
  if (!hosted && !reset) {
    const stored = await readStored();
    if (stored && accountDestroyed(stored.book, book)) return view(false);
  }
  if (!reset && accountDestroyed(slot.book, book)) return view(false);
  slot.book = book;
  slot.rev += 1;
  if (ran) slot.lastRunAt = Date.now();
  await persist(reset);
  return view(true, reset);
}

async function persist(force = false) {
  if (hosted) return;
  if (!force) {
    const stored = await readStored();
    if (stored && accountDestroyed(stored.book, slot.book)) return;
  }
  const payload = JSON.stringify({ ...snapshotOf(slot.book), lastRunAt: slot.lastRunAt, rev: slot.rev });
  await mkdir(dirname(FILE), { recursive: true });
  const tmp = `${FILE}.tmp`;
  await writeFile(tmp, payload);
  await rename(tmp, FILE);
}

async function load() {
  if (hosted || slot.loaded) return;
  slot.loaded = true;
  const stored = await readStored();
  if (!stored) return;
  slot.book = stored.book;
  slot.lastRunAt = stored.lastRunAt;
  slot.rev = stored.rev;
}

async function heal() {
  if (hosted) return;
  await load();
  const stored = await readStored();
  if (!stored) return;
  if (accountDestroyed(stored.book, slot.book)) {
    slot.book = stored.book;
    slot.lastRunAt = stored.lastRunAt;
    if (stored.rev > slot.rev) slot.rev = stored.rev;
  }
}

function enqueue(task: () => Promise<PaperView> | PaperView): Promise<PaperView> {
  const run = slot.chain.then(async () => {
    await heal();
    return task();
  });
  slot.chain = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

async function tick(): Promise<PaperView> {
  if (slot.ticking) {
    await slot.idle;
    return enqueue(async () => view());
  }
  let release: () => void = () => undefined;
  slot.idle = new Promise<void>((resolve) => {
    release = resolve;
  });
  slot.ticking = true;
  try {
    await enqueue(async () => view());
    const rev = slot.rev;
    let quotes;
    try {
      const extra = slot.book.positions.map((position) => ({
        symbol: position.symbol,
        name: position.name,
        kind: position.kind,
      }));
      quotes = await loadBotQuotes(extra, (done, total) => {
        slot.progress = { done, total, running: true };
      });
    } catch {
      return await enqueue(async () => view(false));
    }
    return await enqueue(async () => {
      if (slot.rev !== rev) return view();
      const next = step(slot.book, quotes, Date.now());
      if (accountDestroyed(slot.book, next)) return view(false);
      return publish(next, true);
    });
  } finally {
    slot.ticking = false;
    slot.progress = { ...slot.progress, running: false };
    release();
  }
}

async function ensureOptIn() {
  if (slot.optInChecked) return;
  slot.optInChecked = true;
  if (slot.book.activated !== true) {
    slot.book = { ...slot.book, paused: true, activated: false };
    slot.rev += 1;
    await persist();
    return;
  }
  if (slot.book.paused) return;
  const now = Date.now();
  slot.book = {
    ...slot.book,
    journal: [
      {
        id: `reprise-${now}`,
        at: now,
        action: "attente" as const,
        text: "L'application a redémarré. Le bot était activé, il continue sans nouvel accord.",
      },
      ...slot.book.journal,
    ].slice(0, 40),
  };
  slot.rev += 1;
  await persist();
}

function takeClient(command: PaperCommand) {
  if (!hosted || command.type === "reset") return;
  const raw = command.type === "replace" ? command.book : command.clientBook;
  const book = parseSnapshot(raw);
  if (!book) return;
  slot.book = book;
  slot.loaded = true;
  slot.optInChecked = true;
}

export function startBotLoop() {
  if (hosted || slot.timer) return;
  slot.timer = setInterval(() => void tick(), 80_000);
  void enqueue(async () => {
    await ensureOptIn();
    const wait = isBlankBook(slot.book) ? 20_000 : 1_000;
    setTimeout(() => void tick(), wait);
    return view();
  });
}

export function readBook(): Promise<PaperView> {
  if (!hosted) startBotLoop();
  return enqueue(async () => {
    if (!hosted) await ensureOptIn();
    return view();
  });
}

export function applyCommand(command: PaperCommand): Promise<PaperView> {
  if (!hosted) startBotLoop();
  takeClient(command);
  if (command.type === "tick") return tick();
  return enqueue(async () => {
    if (command.type === "pause") {
      const activated = command.activated === true || slot.book.activated === true;
      return publish({ ...slot.book, paused: command.paused, activated });
    }
    if (command.type === "reset") return publish({ ...freshPaper(Date.now()), armed: true }, false, true);
    if (command.type === "deposit") {
      const next = Math.round(command.amount);
      if (!Number.isFinite(next) || next < 10 || next > 100_000) return view(false);
      const now = Date.now();
      const book = slot.book;
      const equity = equityOf(book) + next;
      return publish({
        ...book,
        cash: book.cash + next,
        added: (book.added || 0) + next,
        journal: [
          {
            id: `depot-${now}`,
            at: now,
            action: "attente" as const,
            text: `Dépôt fictif de ${next} $. Cet apport n'est pas compté comme un gain.`,
          },
          ...book.journal,
        ].slice(0, 40),
        history: pushHistory(book.history, book.startedAt, now, equity),
      });
    }
    if (command.type === "risk") return publish({ ...slot.book, risk: settingsOf({ risk: command.risk }) });
    if (command.type === "manualOpen") {
      const next = manualOpen(slot.book, command.order);
      if (!next) return view(false);
      return publish(next);
    }
    if (command.type === "manualClose") {
      const next = manualClose(slot.book, command.symbol, command.price);
      if (!next) return view(false);
      return publish(next);
    }
    const book = parseSnapshot(command.book);
    if (!book) return view(false);
    return publish({ ...book, armed: true, risk: settingsOf(book) });
  });
}
