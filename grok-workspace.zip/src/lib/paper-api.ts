import { createServerFn } from "@tanstack/react-start";
import type { PaperCommand, PaperView } from "@/lib/bot-runner";

export const getBotProgress = createServerFn({ method: "GET" }).handler(async () => {
  const { readProgress } = await import("@/lib/bot-runner");
  return readProgress();
});

export const getPaperBook = createServerFn({ method: "GET" }).handler(async (): Promise<PaperView> => {
  const { readBook } = await import("@/lib/bot-runner");
  return readBook();
});

export const paperCommand = createServerFn({ method: "POST" })
  .validator((input: unknown): PaperCommand => {
    if (!input || typeof input !== "object" || typeof (input as { type?: unknown }).type !== "string") {
      throw new Error("Commande invalide");
    }
    return input as PaperCommand;
  })
  .handler(async ({ data }): Promise<PaperView> => {
    const { applyCommand } = await import("@/lib/bot-runner");
    return applyCommand(data);
  });
