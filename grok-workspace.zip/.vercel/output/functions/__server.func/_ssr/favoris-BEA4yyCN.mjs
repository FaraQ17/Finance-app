import { i as __toESM } from "../_runtime.mjs";
import { a as require_react, i as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as toneOf, c as formatPct, t as MarketShell, u as formatPrice, v as getQuotes } from "./format-UWdJjcXe.mjs";
import { i as Star } from "../_libs/lucide-react.mjs";
import { t as useWatchlist } from "./watchlist-CxDpRLcD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/favoris-BEA4yyCN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "all",
		label: "Tous"
	},
	{
		id: "stock",
		label: "Actions"
	},
	{
		id: "crypto",
		label: "Crypto"
	}
];
function toneClass(change) {
	const tone = toneOf(change);
	if (tone === "up") return "text-up";
	if (tone === "down") return "text-down";
	return "text-muted";
}
function Favorites() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const items = useWatchlist((state) => state.items);
	const toggle = useWatchlist((state) => state.toggle);
	(0, import_react.useEffect)(() => {
		setMounted(true);
		useWatchlist.persist.rehydrate();
	}, []);
	const symbols = (0, import_react.useMemo)(() => items.map((item) => item.symbol), [items]);
	const quotes = useQuery({
		queryKey: ["favorites", symbols.join(",")],
		enabled: mounted && symbols.length > 0,
		queryFn: () => getQuotes({ data: { symbols } }),
		staleTime: 3e4,
		refetchInterval: 6e4
	});
	const quoteMap = new Map((quotes.data?.quotes ?? []).map((quote) => [quote.symbol, quote]));
	const visible = mounted ? items.filter((item) => filter === "all" || item.kind === filter) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl space-y-4 px-4 py-4 pb-24 lg:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: "Favoris"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-pretty text-muted",
				children: "L'étoile garde une action ou une crypto ici. Touchez le nom pour ouvrir le desk."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-1 rounded-xl bg-panel p-1 shadow-card",
				role: "tablist",
				"aria-label": "Filtre",
				children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": filter === item.id,
					onClick: () => setFilter(item.id),
					className: `h-10 rounded-lg text-sm ${filter === item.id ? "bg-brass font-medium text-ink" : "text-muted"}`,
					children: item.label
				}, item.id))
			}),
			!mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Chargement des favoris…"
			}) : null,
			mounted && items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-panel p-5 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-pretty text-muted",
					children: "Aucun favori. Sur le desk, les tendances ou une recherche, touchez l'étoile pour retrouver le titre ici."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-3 inline-flex h-11 items-center text-sm text-brass",
					children: "Ouvrir le desk"
				})]
			}) : null,
			mounted && items.length > 0 && visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Aucun favori dans ce filtre."
			}) : null,
			visible.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "overflow-hidden rounded-2xl bg-panel shadow-card",
				children: visible.map((item) => {
					const quote = quoteMap.get(item.symbol);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center border-b border-line last:border-b-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							search: { s: item.symbol },
							className: "min-w-0 flex-1 px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate text-sm",
									children: item.name
								}), quote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `shrink-0 font-mono text-sm tabular-nums ${toneClass(quote.changePercent)}`,
									children: formatPct(quote.changePercent)
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: "Cours…"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 block font-mono text-xs text-muted",
								children: [
									item.symbol.replace("-USD", ""),
									item.kind === "crypto" ? " · Crypto" : " · Action",
									quote ? ` · ${formatPrice(quote.price, quote.currency)}` : ""
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => toggle(item),
							"aria-pressed": true,
							"aria-label": `Retirer ${item.name} des favoris`,
							className: "grid size-11 shrink-0 place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-4 fill-brass text-brass" })
						})]
					}, item.symbol);
				})
			}) : null
		]
	}) });
}
var SplitComponent = Favorites;
//#endregion
export { SplitComponent as component };
